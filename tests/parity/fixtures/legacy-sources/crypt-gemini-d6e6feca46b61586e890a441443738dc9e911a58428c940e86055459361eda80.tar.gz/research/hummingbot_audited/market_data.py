"""Manifest-backed historical market data and target snapshot contracts."""
from __future__ import annotations

import hashlib
import io
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
import re
from types import MappingProxyType
from typing import Any, Mapping, Sequence

import pandas as pd

from research.blend_v2.data import ManifestEntry, SymbolBundle, build_manifest
from research.blend_v2.types import IntegrityError
from research.hummingbot_audited.contracts import AuditedBacktestError, BlockingCode


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_PAIRSPEC_RE = re.compile(r"^[A-Z0-9]+-[A-Z0-9]+$")
_SYMBOL_RE = re.compile(r"^[a-z0-9]+_[a-z0-9]+$")
_YYYYMMDD_RE = re.compile(r"^\d{8}$")
_EPOCH_MS_RE = re.compile(r"^\d{12,13}$")


def pair_to_symbol(trading_pair: str) -> str:
    if not isinstance(trading_pair, str) or not trading_pair.strip():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "trading_pair: expected non-empty BASE-QUOTE or base_quote",
        )
    value = trading_pair.strip()
    if _SYMBOL_RE.fullmatch(value.lower()):
        return value.lower()
    upper = value.upper()
    if _PAIRSPEC_RE.fullmatch(upper):
        base, quote = upper.split("-", 1)
        return f"{base.lower()}_{quote.lower()}"
    raise AuditedBacktestError(
        BlockingCode.INVALID_REQUEST,
        "trading_pair: expected BASE-QUOTE or base_quote",
    )


def _ensure_non_empty_text(value: object, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: must be non-empty text")
    return value


def _ensure_sha256(value: object, name: str) -> str:
    text = _ensure_non_empty_text(value, name)
    if _SHA256_RE.fullmatch(text) is None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be lowercase sha-256 hex",
        )
    return text


def _as_utc_timestamp(value: object, name: str) -> pd.Timestamp:
    if isinstance(value, pd.Timestamp):
        timestamp = value
    else:
        try:
            timestamp = pd.Timestamp(value)
        except (TypeError, ValueError) as exc:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected timestamp") from exc
    if timestamp.tzinfo is None:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: timezone-aware timestamp required")
    return timestamp.tz_convert("UTC")


def _timestamp_to_string(timestamp: pd.Timestamp) -> str:
    return _as_utc_timestamp(timestamp, "timestamp").isoformat(timespec="nanoseconds").replace(
        "+00:00",
        "Z",
    )


def _parse_csv_timestamp(values: pd.Series, path: Path) -> pd.DatetimeIndex:
    strings = values.astype("string").str.strip()
    if strings.isna().any() or (strings == "").any():
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: missing timestamp")

    parsed: list[pd.Timestamp] = []
    for raw in strings.tolist():
        text = str(raw)
        if _YYYYMMDD_RE.fullmatch(text):
            try:
                parsed.append(pd.to_datetime(text, format="%Y%m%d", utc=True))
                continue
            except (ValueError, TypeError, pd.errors.OutOfBoundsDatetime) as exc:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: invalid timestamp") from exc

        if _EPOCH_MS_RE.fullmatch(text):
            try:
                parsed.append(pd.to_datetime(int(text), unit="ms", utc=True))
                continue
            except (OverflowError, ValueError, pd.errors.OutOfBoundsDatetime) as exc:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: invalid timestamp") from exc

        try:
            timestamp = pd.Timestamp(text)
        except (TypeError, ValueError) as exc:
            raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: invalid timestamp") from exc

        if timestamp.tzinfo is None:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{path}: timezone-aware timestamp required",
            )
        parsed.append(timestamp.tz_convert("UTC"))

    index = pd.DatetimeIndex(parsed, tz="UTC")
    if not index.is_unique or not index.is_monotonic_increasing:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: duplicate/nonmonotonic timestamps")
    return index


def _parse_decimal(value: object, path: Path, field: str) -> Decimal:
    try:
        text = str(value).strip()
    except Exception:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: invalid {field}")
    if not text:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: missing {field}")
    try:
        parsed = Decimal(text)
    except InvalidOperation as exc:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: invalid {field}") from exc
    if not parsed.is_finite():
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: non-finite {field}")
    return parsed


def _read_csv(path: Path, data: bytes | None = None) -> pd.DataFrame:
    try:
        return pd.read_csv(io.BytesIO(data) if data is not None else path, dtype="string", keep_default_na=False)
    except Exception as exc:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: cannot read csv") from exc


def _first_column(frame: pd.DataFrame, candidates: Sequence[str], path: Path, context: str) -> str:
    for name in candidates:
        if name in frame.columns:
            return name
    raise AuditedBacktestError(
        BlockingCode.DATA_GAP,
        f"{path}: missing {context} column; expected one of {list(candidates)}",
    )


def _build_indexed_frame(
    path: Path,
    *,
    time_columns: Sequence[str],
    value_columns: Sequence[str],
    data: bytes | None = None,
) -> pd.DataFrame:
    frame = _read_csv(path, data)
    time_column = _first_column(frame, time_columns, path, "timestamp")
    timestamps = _parse_csv_timestamp(frame[time_column], path)

    columns: dict[str, list[Decimal]] = {}
    for column in value_columns:
        if column not in frame.columns:
            raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: missing column {column}")
        values: list[Decimal] = []
        for raw in frame[column]:
            values.append(_parse_decimal(raw, path, column))
        columns[column] = values

    result = pd.DataFrame(columns)
    if len(result) != len(timestamps):
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: timestamp/value row mismatch")
    result.index = timestamps
    result.index.name = "timestamp"
    return result


def _load_ohlc(path: Path, *, daily: bool, data: bytes | None = None) -> pd.DataFrame:
    frame = _build_indexed_frame(
        path,
        time_columns=("open_time", "timestamp", "date"),
        value_columns=("open", "high", "low", "close", *(("volume",) if daily else ())),
        data=data,
    )
    if not frame.index.is_unique or not frame.index.is_monotonic_increasing:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: duplicate/nonmonotonic timestamps")

    for row in frame.itertuples(index=False):
        open_value, high_value, low_value, close_value = row[:4]
        if open_value <= 0 or high_value <= 0 or low_value <= 0 or close_value <= 0:
            raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: OHLC values must be positive")
        if not (high_value >= max(open_value, close_value) and low_value <= min(open_value, close_value) and high_value >= low_value):
            raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: invalid candle geometry")
        if daily and row[4] < 0:
            raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: volume must be non-negative")
    return frame


def _load_funding(path: Path, data: bytes | None = None) -> pd.DataFrame:
    frame = _read_csv(path, data)
    time_column = _first_column(
        frame,
        ("funding_time", "fundingTime", "open_time", "timestamp"),
        path,
        "timestamp",
    )
    rate_column = _first_column(frame, ("funding_rate", "fundingRate"), path, "funding rate")
    timestamps = _parse_csv_timestamp(frame[time_column], path)
    values: list[Decimal] = [_parse_decimal(value, path, rate_column) for value in frame[rate_column]]
    result = pd.DataFrame({"funding_rate": values}, index=timestamps)
    result.index.name = "timestamp"
    if not result.index.is_unique or not result.index.is_monotonic_increasing:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{path}: duplicate/nonmonotonic timestamps")
    return result


def _canonical_payload_json(payload: Mapping[str, object]) -> str:
    def _coerce(value: Any) -> Any:
        if isinstance(value, Mapping):
            return {key: _coerce(value[key]) for key in sorted(value.keys(), key=str)}
        if isinstance(value, list):
            return [_coerce(item) for item in value]
        if isinstance(value, tuple):
            return [_coerce(item) for item in value]
        if isinstance(value, Decimal):
            return str(value)
        return value

    return json.dumps(_coerce(payload), sort_keys=True, separators=(",", ":"))


def _immutable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({
            key: _immutable(value[key])
            for key in value
        })
    if isinstance(value, list):
        return tuple(_immutable(item) for item in value)
    if isinstance(value, tuple):
        return tuple(_immutable(item) for item in value)
    return value


class MarketManifest:
    def __init__(self, path: Path, entries: Sequence[ManifestEntry]) -> None:
        if not isinstance(path, Path):
            raise TypeError("path must be pathlib.Path")
        self.path = path.resolve()
        self.directory = self.path.parent

        normalized = []
        for entry in entries:
            normalized.append(
                ManifestEntry(
                    path=_ensure_non_empty_text(entry.path, "path"),
                    sha256=_ensure_sha256(entry.sha256, "sha256"),
                )
            )
        if len({entry.path for entry in normalized}) != len(normalized):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "manifest.files: duplicate normalized path")
        self.entries = tuple(normalized)

    @property
    def sha256(self) -> str:
        payload = [
            {"path": entry.path, "sha256": entry.sha256}
            for entry in sorted(self.entries, key=lambda item: item.path)
        ]
        return hashlib.sha256(_canonical_payload_json(payload).encode()).hexdigest()

    @classmethod
    def from_json(cls, manifest_path: str | Path) -> "MarketManifest":
        file_path = Path(manifest_path).resolve()
        try:
            raw = json.loads(file_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "manifest: expected JSON object") from exc

        if not isinstance(raw, Mapping):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "manifest: expected object")
        files = raw.get("files")
        if not isinstance(files, list):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "manifest: expected files list")

        manifest_dir = file_path.parent
        entries: list[ManifestEntry] = []
        seen_paths: set[str] = set()
        canonical_paths: list[str] = []

        for record in files:
            if not isinstance(record, Mapping):
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    "manifest.files: expected list of mappings",
                )
            raw_path = _ensure_non_empty_text(record.get("path"), "manifest.files.path")
            expected_hash = _ensure_sha256(record.get("sha256"), "manifest.files.sha256")

            if Path(raw_path).is_absolute():
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{raw_path}: manifest path must be relative",
                )

            absolute = (manifest_dir / raw_path).resolve()
            try:
                canonical = absolute.relative_to(manifest_dir)
            except ValueError as exc:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{raw_path}: path outside manifest directory",
                ) from exc
            normalized = canonical.as_posix()

            if normalized in seen_paths:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"manifest.files: duplicate path {normalized}",
                )
            seen_paths.add(normalized)
            canonical_paths.append(normalized)

            if not absolute.exists():
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{raw_path}: manifest hash mismatch (file missing)",
                )
            actual = hashlib.sha256(absolute.read_bytes()).hexdigest()
            if actual != expected_hash:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{raw_path}: manifest hash mismatch",
                )
            entries.append(ManifestEntry(path=normalized, sha256=expected_hash))

        if canonical_paths != sorted(canonical_paths):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "manifest.files: expected sorted path order",
            )

        return cls(file_path, entries)

    def paths_for_symbol(self, symbol: str) -> tuple[Path, Path, Path]:
        canonical = _ensure_non_empty_text(pair_to_symbol(symbol), "symbol")
        if not _SYMBOL_RE.fullmatch(canonical):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "symbol: expected base_quote")

        daily: Path | None = None
        hourly: Path | None = None
        funding: Path | None = None

        matcher = re.compile(rf"^{re.escape(canonical)}_(1d|1h|funding)_[^/\\\\]+\.csv$")

        for entry in self.entries:
            name = Path(entry.path).name
            match = matcher.fullmatch(name)
            if match is None:
                continue
            kind = match.group(1)
            candidate = (self.directory / entry.path).resolve()

            try:
                candidate.relative_to(self.directory)
            except ValueError as exc:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{entry.path}: manifest path outside manifest directory",
                ) from exc

            if not candidate.exists():
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{entry.path}: manifest hash mismatch (file missing)",
                )
            actual = hashlib.sha256(candidate.read_bytes()).hexdigest()
            if actual != entry.sha256:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{entry.path}: manifest hash mismatch",
                )

            if kind == "1d":
                if daily is not None:
                    raise AuditedBacktestError(
                        BlockingCode.DATA_GAP,
                        f"{canonical}: ambiguous 1d files",
                    )
                daily = candidate
            elif kind == "1h":
                if hourly is not None:
                    raise AuditedBacktestError(
                        BlockingCode.DATA_GAP,
                        f"{canonical}: ambiguous 1h files",
                    )
                hourly = candidate
            elif kind == "funding":
                if funding is not None:
                    raise AuditedBacktestError(
                        BlockingCode.DATA_GAP,
                        f"{canonical}: ambiguous funding files",
                    )
                funding = candidate

        missing: list[str] = []
        if daily is None:
            missing.append("1d")
        if hourly is None:
            missing.append("1h")
        if funding is None:
            missing.append("funding")
        if missing:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{canonical}: missing {missing} file(s)",
            )

        return (daily, hourly, funding)


def load_decimal_symbol_bundle(manifest: MarketManifest, symbol: str) -> SymbolBundle:
    canonical_symbol = _ensure_non_empty_text(pair_to_symbol(symbol), "symbol")
    daily_path, hourly_path, funding_path = manifest.paths_for_symbol(canonical_symbol)
    return SymbolBundle(
        symbol=canonical_symbol,
        daily=_load_ohlc(daily_path, daily=True),
        hourly=_load_ohlc(hourly_path, daily=False),
        funding=_load_funding(funding_path),
        manifest=build_manifest((daily_path, hourly_path, funding_path)),
    )


def load_decimal_symbol_bundle_from_bytes(
    manifest: MarketManifest, symbol: str, captured_files: Mapping[str, bytes]
) -> SymbolBundle:
    canonical_symbol = _ensure_non_empty_text(pair_to_symbol(symbol), "symbol")
    entries = manifest.entries
    selected: dict[str, tuple[Path, str]] = {}
    matcher = re.compile(rf"^{re.escape(canonical_symbol)}_(1d|1h|funding)_[^/\\]+\.csv$")
    for entry in entries:
        name = Path(entry.path).name
        match = matcher.fullmatch(name)
        if match:
            kind = match.group(1)
            if kind in selected:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{canonical_symbol}: ambiguous {kind} files")
            if entry.path not in captured_files:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{entry.path}: captured bytes missing")
            if hashlib.sha256(captured_files[entry.path]).hexdigest() != entry.sha256:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{entry.path}: manifest hash mismatch")
            selected[kind] = (Path(entry.path), entry.path)
    missing = [kind for kind in ("1d", "1h", "funding") if kind not in selected]
    if missing:
        raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{canonical_symbol}: missing {missing} file(s)")
    daily_label, daily_key = selected["1d"]
    hourly_label, hourly_key = selected["1h"]
    funding_label, funding_key = selected["funding"]
    return SymbolBundle(
        symbol=canonical_symbol,
        daily=_load_ohlc(daily_label, daily=True, data=captured_files[daily_key]),
        hourly=_load_ohlc(hourly_label, daily=False, data=captured_files[hourly_key]),
        funding=_load_funding(funding_label, data=captured_files[funding_key]),
        manifest=tuple(
            ManifestEntry(path=path.as_posix(), sha256=next(entry.sha256 for entry in entries if entry.path == key))
            for path, key in (selected["1d"], selected["1h"], selected["funding"])
        ),
    )


def _validate_continuity(index: pd.DatetimeIndex, freq: str, symbol: str) -> None:
    if not isinstance(index, pd.DatetimeIndex):
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{symbol}: expected DatetimeIndex for {freq} data",
        )
    if index.tz is None:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{symbol}: expected UTC timestamps for {freq} data",
        )
    if not index.is_unique or not index.is_monotonic_increasing:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{symbol}: duplicate/nonmonotonic {freq} timestamps",
        )
    if len(index) == 0:
        return

    index_utc = index.tz_convert("UTC")
    if freq == "1h":
        if not (index_utc == index_utc.floor("1h")).all():
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{symbol}: hourly timestamps must align to 1h boundaries",
            )
    elif freq == "1D":
        if not (index_utc == index_utc.floor("1D")).all():
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{symbol}: daily timestamps must align to UTC midnight",
            )

    expected = pd.date_range(index_utc[0], index_utc[-1], freq=freq, tz="UTC")
    if not index_utc.equals(expected):
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{symbol}: missing {freq} continuity",
        )


class HistoricalMarketData:
    def __init__(self, symbol_data: Mapping[str, SymbolBundle]) -> None:
        if not isinstance(symbol_data, Mapping):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "symbol_data: expected mapping")

        data: dict[str, SymbolBundle] = {}
        for symbol, bundle in symbol_data.items():
            if not isinstance(symbol, str):
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "symbol_data: expected symbol text keys")
            if not isinstance(bundle, SymbolBundle):
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "symbol_data: expected SymbolBundle values")

            canonical = pair_to_symbol(symbol)
            if canonical != bundle.symbol:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{canonical}: key does not match bundle.symbol",
                )

            safe_bundle = SymbolBundle(
                symbol=canonical,
                daily=bundle.daily.copy(),
                hourly=bundle.hourly.copy(),
                funding=bundle.funding.copy(),
                manifest=tuple(bundle.manifest),
            )

            for label, frame in (
                    ("daily", safe_bundle.daily),
                    ("hourly", safe_bundle.hourly),
                    ("funding", safe_bundle.funding),
                ):
                if not isinstance(frame.index, pd.DatetimeIndex):
                    raise AuditedBacktestError(
                        BlockingCode.DATA_GAP,
                        f"{canonical}.{label}: expected DatetimeIndex",
                    )
                if frame.index.tz is None:
                    raise AuditedBacktestError(
                        BlockingCode.DATA_GAP,
                        f"{canonical}.{label}: expected UTC timestamps",
                    )
                if not frame.index.is_unique or not frame.index.is_monotonic_increasing:
                    raise AuditedBacktestError(
                        BlockingCode.DATA_GAP,
                        f"{canonical}.{label}: duplicate/nonmonotonic timestamps",
                    )
                frame.index = frame.index.tz_convert("UTC")

            _validate_continuity(safe_bundle.daily.index, "1D", canonical)
            _validate_continuity(safe_bundle.hourly.index, "1h", canonical)

            data[canonical] = safe_bundle

        self._symbol_data = MappingProxyType(data)

    def coverage_proof(self, start: object, end: object) -> Mapping[str, tuple[pd.Timestamp, ...]]:
        """Prove the complete hourly/daily/funding path for every loaded bundle."""
        start_utc = _as_utc_timestamp(start, "start_time")
        end_utc = _as_utc_timestamp(end, "end_time")
        if start_utc >= end_utc:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "start_time must be < end_time")
        if not self._symbol_data:
            raise AuditedBacktestError(BlockingCode.DATA_GAP, "market coverage: at least one market required")
        hourly_expected = pd.date_range(start_utc.floor("1h"), end_utc.floor("1h"), freq="1h", tz="UTC")
        proof: dict[str, tuple[pd.Timestamp, ...]] = {}
        for symbol, bundle in sorted(self._symbol_data.items()):
            hourly = bundle.hourly.index.tz_convert("UTC")
            missing_hourly = hourly_expected.difference(hourly)
            if not missing_hourly.empty:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{symbol}: missing hourly coverage at {missing_hourly[0]}")
            required_daily = pd.DatetimeIndex(
                [timestamp for timestamp in hourly_expected if timestamp == timestamp.floor("1D")],
                tz="UTC",
            )
            missing_daily = required_daily.difference(bundle.daily.index.tz_convert("UTC"))
            if not missing_daily.empty:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"{symbol}: missing daily coverage at {missing_daily[0]}")
            try:
                bundle.funding_rows_for_interval(start_utc, end_utc)
            except IntegrityError as exc:
                raise AuditedBacktestError(BlockingCode.FUNDING_GAP, str(exc)) from exc
            proof[symbol] = tuple(hourly_expected)
        return MappingProxyType(proof)

    def _frame_and_duration(self, symbol: str, interval: str) -> tuple[pd.DataFrame, pd.Timedelta]:
        bundle = self._symbol_data[symbol]
        if interval == "1h":
            return bundle.hourly.copy(), pd.Timedelta(hours=1)
        if interval == "1d":
            return bundle.daily.copy(), pd.Timedelta(days=1)
        if interval == "12h":
            hourly = bundle.hourly.sort_index()
            buckets = hourly.index.floor("12h")
            records: list[tuple[pd.Timestamp, Decimal, Decimal, Decimal, Decimal]] = []
            for bucket, rows in hourly.groupby(buckets):
                if len(rows) != 12:
                    continue
                rows = rows.sort_index()
                expected = pd.date_range(rows.index[0], periods=12, freq="1h", tz="UTC")
                if not rows.index.equals(expected):
                    continue
                records.append(
                    (
                        bucket,
                        rows["open"].iloc[0],
                        rows["high"].max(),
                        rows["low"].min(),
                        rows["close"].iloc[-1],
                    ),
                )
            if not records:
                return (
                    pd.DataFrame(
                        columns=("open", "high", "low", "close"),
                        index=pd.DatetimeIndex([], tz="UTC"),
                    ),
                    pd.Timedelta(hours=12),
                )
            index, opens, highs, lows, closes = zip(*records)
            return (
                pd.DataFrame(
                    {"open": opens, "high": highs, "low": lows, "close": closes},
                    index=pd.DatetimeIndex(index),
                ).sort_index(),
                pd.Timedelta(hours=12),
            )
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"interval: unsupported {interval!r}")

    def completed_candles(
        self,
        trading_pair: str,
        interval: str,
        now: pd.Timestamp,
        max_records: int,
    ) -> pd.DataFrame:
        symbol = pair_to_symbol(trading_pair)
        if symbol not in self._symbol_data:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{trading_pair}: missing symbol data",
            )
        if isinstance(max_records, bool) or not isinstance(max_records, int) or max_records <= 0:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "max_records: expected positive integer")

        now_utc = _as_utc_timestamp(now, "now")
        frame, duration = self._frame_and_duration(symbol, interval)
        visible = frame.loc[frame.index + duration <= now_utc] if not frame.empty else frame
        return visible.tail(max_records).copy()


@dataclass(frozen=True)
class TargetSnapshot:
    effective_at: pd.Timestamp
    written_ts: pd.Timestamp
    payload: Mapping[str, object]
    payload_sha256: str


def _parse_written_ts(raw: object, path: Path) -> pd.Timestamp:
    def _as_written_timestamp(seconds: int) -> pd.Timestamp:
        try:
            return pd.Timestamp(seconds, unit="s", tz="UTC")
        except (OverflowError, ValueError, pd.errors.OutOfBoundsDatetime) as exc:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"{path}: written_ts: exceeds supported timestamp range",
            ) from exc

    if isinstance(raw, bool):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: expected epoch seconds")
    if isinstance(raw, int):
        if raw < 0:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: expected non-negative epoch seconds")
        return _as_written_timestamp(raw)
    if isinstance(raw, Decimal):
        if not raw.is_finite():
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: must be finite")
        if raw != raw.to_integral_value() or raw < 0:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: must be integer epoch seconds")
        return _as_written_timestamp(int(raw))
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: expected non-empty")
        try:
            parsed = Decimal(text)
        except InvalidOperation as exc:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: expected epoch seconds") from exc
        if not parsed.is_finite():
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: must be finite")
        if parsed != parsed.to_integral_value() or parsed < 0:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: must be non-negative integer epoch seconds")
        return _as_written_timestamp(int(parsed))
    raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: written_ts: expected epoch seconds")


def _parse_decimal_string(value: object, path: Path, name: str) -> tuple[Decimal, str]:
    if not isinstance(value, str):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: {name}: expected decimal string")
    try:
        parsed = Decimal(value)
    except InvalidOperation as exc:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: {name}: expected decimal string") from exc
    if not parsed.is_finite() or parsed <= 0:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{path}: {name}: expected positive finite decimal")
    return parsed, value


class TargetSnapshotSeries:
    def __init__(self, snapshots: Sequence[TargetSnapshot]):
        self.snapshots = tuple(snapshots)

    @classmethod
    def from_jsonl(cls, path: str | Path, *, data: bytes | None = None) -> "TargetSnapshotSeries":
        file_path = Path(path)
        if data is None:
            try:
                text = file_path.read_text()
            except OSError as exc:
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: cannot read file") from exc
        else:
            try:
                text = data.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: cannot read file") from exc

        snapshots: list[TargetSnapshot] = []
        previous_effective: pd.Timestamp | None = None

        for raw_line in text.splitlines():
            if not raw_line.strip():
                continue
            try:
                payload = json.loads(raw_line, parse_float=Decimal)
            except json.JSONDecodeError as exc:
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: invalid JSONL line") from exc

            if not isinstance(payload, Mapping):
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: each line must be object")

            raw_effective = payload.get("effective_at")
            raw_written = payload.get("written_ts")
            legs = payload.get("legs")
            if raw_effective is None or raw_written is None or legs is None:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"{file_path}: snapshot missing required fields",
                )

            effective_at = _as_utc_timestamp(raw_effective, "effective_at")
            if previous_effective is not None and effective_at <= previous_effective:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"{file_path}: effective_at values must be strictly increasing",
                )
            written_ts = _parse_written_ts(raw_written, file_path)
            if written_ts > effective_at:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"{file_path}: written_ts must be <= effective_at",
                )

            if not isinstance(legs, list):
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"{file_path}: legs must be a list",
                )

            seen_pairs: set[str] = set()
            normalized_legs: list[dict[str, str]] = []
            for leg in legs:
                if not isinstance(leg, Mapping):
                    raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: each leg must be object")

                raw_pair = leg.get("pair")
                if raw_pair is None:
                    raise AuditedBacktestError(
                        BlockingCode.INVALID_REQUEST,
                        f"{file_path}: each leg must provide pair",
                    )
                pair = _ensure_non_empty_text(raw_pair, "leg.pair")
                if not _SYMBOL_RE.fullmatch(pair):
                    raise AuditedBacktestError(
                        BlockingCode.INVALID_REQUEST,
                        f"{file_path}: leg.pair: expected base_quote",
                    )
                if pair in seen_pairs:
                    raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: duplicate leg pair")
                seen_pairs.add(pair)

                size = leg.get("size_exposure")
                entry = leg.get("entry_ref")
                stop = leg.get("stop_price")
                if size is None or entry is None or stop is None:
                    raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{file_path}: leg missing required fields")

                size_value, size_text = _parse_decimal_string(size, file_path, "size_exposure")
                entry_value, entry_text = _parse_decimal_string(entry, file_path, "entry_ref")
                stop_value, stop_text = _parse_decimal_string(stop, file_path, "stop_price")

                if stop_value >= entry_value:
                    raise AuditedBacktestError(
                        BlockingCode.INVALID_REQUEST,
                        f"{file_path}: stop_price must be below entry_ref",
                    )

                normalized_legs.append(
                    {
                        "pair": pair,
                        "size_exposure": size_text,
                        "entry_ref": entry_text,
                        "stop_price": stop_text,
                    },
                )

                # Keep local strictness from exact decimal values in scope.
                if size_value <= 0 or entry_value <= 0 or stop_value <= 0:
                    raise AuditedBacktestError(
                        BlockingCode.INVALID_REQUEST,
                        f"{file_path}: size/entry/stop must be positive",
                    )

            canonical_payload = dict(payload)
            canonical_payload.pop("payload_sha256", None)
            canonical_payload["effective_at"] = _timestamp_to_string(effective_at)
            canonical_payload["written_ts"] = str(int(written_ts.value // 1_000_000_000))
            canonical_payload["legs"] = tuple(
                {
                    "pair": leg["pair"],
                    "size_exposure": leg["size_exposure"],
                    "entry_ref": leg["entry_ref"],
                    "stop_price": leg["stop_price"],
                }
                for leg in normalized_legs
            )
            digest = hashlib.sha256(_canonical_payload_json(canonical_payload).encode()).hexdigest()
            declared = payload.get("payload_sha256")
            if declared is not None:
                declared_text = _ensure_non_empty_text(declared, "payload_sha256")
                if _SHA256_RE.fullmatch(declared_text) is None:
                    raise AuditedBacktestError(
                        BlockingCode.INVALID_REQUEST,
                        f"{file_path}: payload_sha256 must be lowercase sha-256 hex",
                    )
                if declared_text != digest:
                    raise AuditedBacktestError(
                        BlockingCode.INVALID_REQUEST,
                        f"{file_path}: payload_sha256 mismatch",
                    )

            snapshots.append(
                TargetSnapshot(
                    effective_at=effective_at,
                    written_ts=written_ts,
                    payload=_immutable(canonical_payload),
                    payload_sha256=digest,
                ),
            )
            previous_effective = effective_at

        return cls(tuple(snapshots))

    def at(self, now: pd.Timestamp) -> TargetSnapshot | None:
        now_utc = _as_utc_timestamp(now, "now")
        selected: TargetSnapshot | None = None
        for snapshot in self.snapshots:
            if snapshot.effective_at <= now_utc:
                selected = snapshot
            else:
                break
        return selected


__all__ = [
    "MarketManifest",
    "HistoricalMarketData",
    "TargetSnapshot",
    "TargetSnapshotSeries",
    "load_decimal_symbol_bundle",
    "load_decimal_symbol_bundle_from_bytes",
    "pair_to_symbol",
]
