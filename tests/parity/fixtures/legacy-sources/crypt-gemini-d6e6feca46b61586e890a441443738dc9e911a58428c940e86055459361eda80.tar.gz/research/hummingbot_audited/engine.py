"""Audited portfolio engine for hummingbot strategy parity checks."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from types import MappingProxyType
from typing import Any

import pandas as pd

from research.blend_v2.execution import (
    _exact_decimal_product,
    _exact_decimal_sum,
    advance_long,
    open_long,
    schedule_long_exit,
    snapshot_long,
)
from research.blend_v2.types import CostModel, IntegrityError
from research.blend_v2.types import (
    ClosedTrade,
    CausalLongRequest,
    LongPositionSnapshot,
    LongPositionState,
)
from research.hummingbot_audited.contracts import (
    AuditedBacktestError,
    AuditedPositionIntent,
    AuditedStopIntent,
    BlockingCode,
    Rejection,
    RejectionCode,
)
from research.hummingbot_audited.contracts import OrderTrace
from research.hummingbot_audited.market_data import HistoricalMarketData, pair_to_symbol
from research.hummingbot_audited.rules import quantize_open
from research.hummingbot_audited.timeline import EventPhase, TradableCalendar

TOLERANCE = Decimal("1E-24")
AUDIT_DECIMAL_PRECISION = 80
ZERO = Decimal("0")


def _classify_kernel_error(exc: IntegrityError) -> BlockingCode | None:
    """Classify only the portfolio kernel's known coverage failures."""
    message = str(exc)
    if "funding coverage requires one row for slot" in message:
        return BlockingCode.FUNDING_GAP
    if "missing hourly coverage" in message:
        return BlockingCode.DATA_GAP
    return None


def _run_kernel_call(function: Any, *args: Any, **kwargs: Any) -> Any:
    try:
        return function(*args, **kwargs)
    except AuditedBacktestError:
        raise
    except IntegrityError as exc:
        code = _classify_kernel_error(exc)
        if code is None:
            raise
        raise AuditedBacktestError(code, str(exc)) from exc


class ExecutorStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    CLOSED = "closed"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class QuoteLedgerEvent:
    timestamp: pd.Timestamp
    price_pnl: Decimal
    fee_cost: Decimal
    slippage_cost: Decimal
    funding_pnl: Decimal
    net_pnl: Decimal


@dataclass
class ExecutorRecord:
    intent: AuditedPositionIntent
    status: ExecutorStatus
    quantized_amount_base: Decimal
    entry_notional_quote: Decimal
    reference_equity_quote: Decimal | None
    margin_reserved_quote: Decimal
    position_state: LongPositionState | None
    latest_position_snapshot: LongPositionSnapshot | None
    closed_trade: ClosedTrade | None
    rejection: Rejection | None
    quote_ledger: tuple[QuoteLedgerEvent, ...]
    converted_ledger_count: int

    @property
    def entry_time(self) -> pd.Timestamp | None:
        if self.position_state is None:
            return None
        return self.position_state.request.execute_time

    @property
    def exit_time(self) -> pd.Timestamp | None:
        if self.closed_trade is None:
            return None
        return self.closed_trade.exit_time

    @property
    def net_pnl_quote(self) -> Decimal:
        return self._snapshot_value("net_pnl")

    @property
    def fee_quote(self) -> Decimal:
        return self._snapshot_value("fee_cost")

    @property
    def slippage_quote(self) -> Decimal:
        return self._snapshot_value("slippage_cost")

    @property
    def funding_quote(self) -> Decimal:
        return self._snapshot_value("funding_pnl")

    def _snapshot_value(self, attr: str) -> Decimal:
        if self.reference_equity_quote is None:
            return ZERO
        if self.status is ExecutorStatus.ACTIVE and self.latest_position_snapshot is not None:
            return getattr(self.latest_position_snapshot, attr) * self.reference_equity_quote
        if self.status is ExecutorStatus.CLOSED:
            return sum(getattr(event, attr) for event in self.quote_ledger)
        snapshot = self.latest_position_snapshot
        if snapshot is None:
            return ZERO
        return getattr(snapshot, attr) * self.reference_equity_quote


def _to_utc_timestamp(value: object, context: str) -> pd.Timestamp:
    try:
        timestamp = pd.Timestamp(value)
    except (TypeError, ValueError) as exc:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{context}: expected timestamp",
        ) from exc

    if timestamp.tzinfo is None:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{context}: timestamp must be timezone-aware",
        )
    return timestamp.tz_convert("UTC")


def _as_decimal(value: object, context: str, *, positive: bool = False) -> Decimal:
    try:
        decimal = Decimal(str(value))
    except (TypeError, ValueError):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{context}: expected decimal",
        )
    if not decimal.is_finite():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{context}: expected finite decimal",
        )
    if positive and decimal < ZERO:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{context}: expected non-negative decimal",
        )
    return decimal


class AuditedPortfolioEngine:
    def __init__(
        self,
        market_data: HistoricalMarketData,
        rules: Any,
        calendar: TradableCalendar,
        event_times: pd.DatetimeIndex | Iterable[pd.Timestamp],
        initial_quote_equity: Decimal,
        cost_model: CostModel,
        max_gross: Decimal,
        max_legs: int,
    ) -> None:
        if not isinstance(max_legs, int) or max_legs < 0:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "max_legs: expected non-negative int",
            )

        self._market_data = market_data
        self._rules = rules
        self._calendar = calendar
        self._event_times = self._normalize_event_times(event_times)
        if len(self._event_times) == 0:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "event_times: must be non-empty",
            )
        self._time = self._event_times[0]
        self._last_advanced_time = None
        self._initial_quote_equity = _as_decimal(
            initial_quote_equity,
            "initial_quote_equity",
            positive=True,
        )
        self._cost_model = cost_model
        self._max_gross = _as_decimal(max_gross, "max_gross", positive=True)
        self._max_legs = max_legs

        self._records: dict[str, ExecutorRecord] = {}
        self._queued_stops: dict[str, list[AuditedStopIntent]] = defaultdict(list)
        self._queued_entries: list[str] = []
        self._rejections: list[Rejection] = []
        self._integrity_notes: set[str] = set()

        self._order_trace: list[tuple[pd.Timestamp, int, str, str, int, OrderTrace]] = []
        self._order_event_seq = 0
        self._position_snapshots: list[dict[str, Any]] = []

    @property
    def active_count(self) -> int:
        return len([record for record in self._records.values() if record.status is ExecutorStatus.ACTIVE])

    @property
    def time(self) -> pd.Timestamp:
        return self._time

    @property
    def rules(self) -> Any:
        return self._rules

    @property
    def rejections(self) -> tuple[Rejection, ...]:
        return tuple(self._rejections)

    @property
    def order_trace(self) -> tuple[OrderTrace, ...]:
        ordered = sorted(
            self._order_trace,
            key=lambda row: (row[0], row[1], row[2], row[3], row[4]),
        )
        return tuple(event for _, _, _, _, _, event in ordered)

    @property
    def integrity(self) -> tuple[Mapping[str, str], ...]:
        by_code: dict[str, str] = {}
        for note in self._integrity_notes:
            code = str(note).split(":", 1)[0].strip()
            if code not in by_code:
                by_code[code] = code
        return tuple(
            MappingProxyType({"code": by_code[code]})
            for code in sorted(by_code)
        )

    @property
    def position_snapshots(self) -> tuple[Mapping[str, Any], ...]:
        return tuple(MappingProxyType(snapshot) for snapshot in self._position_snapshots)

    def records(self) -> Mapping[str, ExecutorRecord]:
        return MappingProxyType(self._records)

    def queue_create(self, intent: AuditedPositionIntent) -> None:
        if intent.executor_id in self._records:
            raise AuditedBacktestError(
                BlockingCode.DUPLICATE_EXECUTOR_ID,
                f"{intent.executor_id}: duplicate executor",
            )
        if intent.decision_time != self._time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "decision_time must equal current engine time",
            )
        record = ExecutorRecord(
            intent=intent,
            status=ExecutorStatus.PENDING,
            quantized_amount_base=ZERO,
            entry_notional_quote=ZERO,
            reference_equity_quote=None,
            margin_reserved_quote=ZERO,
            position_state=None,
            latest_position_snapshot=None,
            closed_trade=None,
            rejection=None,
            quote_ledger=tuple(),
            converted_ledger_count=0,
        )
        self._records[intent.executor_id] = record
        self._queued_entries.append(intent.executor_id)
        self._trace(
            intent.decision_time,
            intent.executor_id,
            EventPhase.CONTROLLER,
            "CREATE",
            {
                "decision_time": intent.decision_time.isoformat(),
                "action_sequence": intent.action_sequence,
                "eligible_execution_time": intent.eligible_execution_time.isoformat(),
            },
        )

    def queue_stop(self, stop: AuditedStopIntent) -> None:
        if stop.executor_id not in self._records:
            raise AuditedBacktestError(
                BlockingCode.UNKNOWN_STOP_TARGET,
                f"{stop.executor_id}: unknown stop target",
            )
        if stop.decision_time != self._time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "decision_time must equal current engine time",
            )

        record = self._records[stop.executor_id]
        if record.status in (ExecutorStatus.CLOSED, ExecutorStatus.REJECTED, ExecutorStatus.CANCELLED):
            self._append_rejection(
                stop.executor_id,
                stop.decision_time,
                RejectionCode.IDEMPOTENT_DUPLICATE_STOP,
                "idempotent duplicate stop",
            )
            self._trace(
                stop.decision_time,
                stop.executor_id,
                EventPhase.CONTROLLER,
                "STOP_REJECTED_DUPLICATE",
                {"action_sequence": stop.action_sequence},
            )
            return

        self._queued_stops[stop.executor_id].append(stop)
        self._trace(
            stop.decision_time,
            stop.executor_id,
            EventPhase.CONTROLLER,
            "STOP_QUEUED",
            {"action_sequence": stop.action_sequence},
        )

    def advance_to(self, event_time: pd.Timestamp) -> None:
        target = _to_utc_timestamp(event_time, "event_time")
        if target not in self._event_times:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                "event_time: must be from event_times",
            )
        if target < self._time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "event_time: must be strictly increasing",
            )
        if self._last_advanced_time is not None and target <= self._last_advanced_time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "event_time: must be strictly increasing",
            )

        start_index = (
            0
            if self._last_advanced_time is None
            else int(self._event_times.searchsorted(self._last_advanced_time, side="right"))
        )
        target_index = int(self._event_times.get_loc(target))
        for current in self._event_times[start_index : target_index + 1]:
            self._advance_one(current)

    def _advance_one(self, target: pd.Timestamp) -> None:
        self._preflight_stop_execution_times(target)

        # PATH_AND_FUNDING
        for record in self._active_records():
            self._advance_active(record, target)

        # stop requests and pending cancellations (deterministic by executor id)
        for executor_id in sorted(self._queued_stops.keys()):
            stops = self._queued_stops[executor_id]
            if not stops:
                continue
            self._queued_stops[executor_id] = self._process_stops_for_record(stops, target)

        # release capacity is automatic from the updated statuses

        # queued entries: (decision_time, action_sequence, executor_id)
        for executor_id in sorted(
            self._queued_entries,
            key=lambda eid: (
                self._records[eid].intent.decision_time,
                self._records[eid].intent.action_sequence,
                eid,
            ),
        ):
            record = self._records[executor_id]
            if record.status is not ExecutorStatus.PENDING:
                continue
            if record.intent.eligible_execution_time > target:
                continue
            self._attempt_open(record, target)

        self._queued_entries = [
            eid for eid in self._queued_entries if self._records[eid].status is ExecutorStatus.PENDING
        ]

        # refresh active position snapshots
        for record in self._active_records():
            self._refresh_active_snapshot(record, target)

        self._append_position_snapshot(target)

        self._time = target
        self._last_advanced_time = target

    def _preflight_stop_execution_times(self, target: pd.Timestamp) -> None:
        for executor_id in sorted(self._queued_stops):
            stops = self._queued_stops[executor_id]
            if not stops:
                continue
            for stop in sorted(
                stops,
                key=lambda item: (
                    self._stop_execution_time(item),
                    item.action_sequence,
                ),
            ):
                if self._stop_execution_time(stop) < target:
                    raise AuditedBacktestError(
                        BlockingCode.NON_CAUSAL_TIMESTAMP,
                        "stop exec_time must equal target execution time",
                    )

    def equity_quote_at(self, timestamp: pd.Timestamp | None = None) -> Decimal:
        return self._equity_at(timestamp)

    def _equity_at(self, timestamp: pd.Timestamp | None = None) -> Decimal:
        if timestamp is not None:
            target = _to_utc_timestamp(timestamp, "timestamp")
            if target > self._time:
                raise AuditedBacktestError(
                    BlockingCode.NON_CAUSAL_TIMESTAMP,
                    "timestamp: cannot query future equity",
                )
            for snapshot in reversed(self._position_snapshots):
                if snapshot["timestamp"] <= target:
                    return snapshot["net_liquidation_equity"]
            return self._initial_quote_equity
        return self._current_equity_quote()

    def parity_summary(self) -> dict[str, Any]:
        computed = self._current_equity_quote()
        reported_equity = (
            self._position_snapshots[-1]["net_liquidation_equity"]
            if self._position_snapshots
            else self._current_equity_quote()
        )
        net_error = computed - reported_equity
        max_event_residual, aggregate_residual, violations = self._verify_quote_scaling()
        if violations:
            raise AuditedBacktestError(
                BlockingCode.LEDGER_RECONCILIATION_FAILED,
                "quote ledger reconciliation failed",
            )
        if aggregate_residual > TOLERANCE:
            raise AuditedBacktestError(
                BlockingCode.LEDGER_RECONCILIATION_FAILED,
                "quote ledger reconciliation failed",
            )
        if net_error.copy_abs() > TOLERANCE:
            raise AuditedBacktestError(
                BlockingCode.LEDGER_RECONCILIATION_FAILED,
                "quote ledger reconciliation failed",
            )
        if max_event_residual == ZERO:
            max_event_residual = ZERO
        if aggregate_residual == ZERO:
            aggregate_residual = ZERO
        return {
            "native_simulator_used": False,
            "equity_at_last_snapshot": reported_equity,
            "computed_equity": computed,
            "net_error": net_error,
            "net_error_abs": abs(net_error),
            "aggregate_tolerance": TOLERANCE,
            "within_tolerance": abs(net_error) <= TOLERANCE,
            "max_event_residual": str(max_event_residual),
            "aggregate_residual": str(aggregate_residual),
            "quote_scale_violations": tuple(violations),
        }

    def _active_records(self) -> list[ExecutorRecord]:
        return sorted(
            (
                record
                for record in self._records.values()
                if record.status is ExecutorStatus.ACTIVE
            ),
            key=lambda record: record.intent.executor_id,
        )

    def _equity_components(self) -> tuple[Decimal, Decimal, Decimal]:
        realized_ledger_pnl = ZERO
        active_snapshot_pnl = ZERO
        active_ledger_pnl = ZERO

        for record in self._records.values():
            if record.reference_equity_quote is None:
                continue
            for event in record.quote_ledger:
                realized_ledger_pnl += event.net_pnl

            if record.status is not ExecutorStatus.ACTIVE:
                continue
            if record.latest_position_snapshot is not None:
                active_snapshot_pnl += record.net_pnl_quote
            for event in record.quote_ledger:
                active_ledger_pnl += event.net_pnl

        return realized_ledger_pnl, active_snapshot_pnl, active_ledger_pnl

    def _current_equity_quote(self) -> Decimal:
        realized_ledger_pnl, active_snapshot_pnl, active_ledger_pnl = self._equity_components()
        return self._initial_quote_equity + realized_ledger_pnl + active_snapshot_pnl - active_ledger_pnl

    def _mark_price(self, trading_pair: str, timestamp: pd.Timestamp) -> Decimal:
        symbol = pair_to_symbol(trading_pair)
        bundle = self._market_data._symbol_data[symbol]
        target = _to_utc_timestamp(timestamp, "mark_time")
        if target in bundle.hourly.index:
            mark = _as_decimal(bundle.hourly.at[target, "open"], "mark")
            if mark <= ZERO:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{trading_pair}: non-positive mark",
                )
            return mark
        last_complete_open = target.floor("1h") - pd.Timedelta(hours=1)
        completed = bundle.hourly.index[bundle.hourly.index <= last_complete_open]
        if completed.empty:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{trading_pair}: missing mark",
            )
        mark = _as_decimal(bundle.hourly.at[completed[-1], "close"], "mark")
        if mark <= ZERO:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{trading_pair}: non-positive mark",
            )
        return mark

    def _active_marked_notional(self, at: pd.Timestamp) -> Decimal:
        notional = ZERO
        for record in self._active_records():
            if record.quantized_amount_base == ZERO:
                continue
            mark = self._mark_price(record.intent.trading_pair, at)
            notional += record.quantized_amount_base * mark
        return notional

    def _attempt_open(self, record: ExecutorRecord, target: pd.Timestamp) -> None:
        symbol = pair_to_symbol(record.intent.trading_pair)
        open_time = self._calendar.first_open_at_or_after(
            record.intent.trading_pair,
            record.intent.eligible_execution_time,
        )
        if open_time is None:
            return
        if open_time < target:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "open_time must equal target execution time",
            )
        if open_time > target:
            return
        bundle = self._market_data._symbol_data[symbol]
        expiry = None
        if record.intent.deadline is not None:
            expiry = self._calendar.first_open_at_or_after(
                record.intent.trading_pair,
                record.intent.deadline,
            )
            if expiry is not None and expiry <= open_time:
                raise AuditedBacktestError(
                    BlockingCode.NON_CAUSAL_TIMESTAMP,
                    f"{record.intent.executor_id}: deadline must follow fill",
                )

        rule_selection = self._rules.rule_at(
            record.intent.connector_name,
            record.intent.trading_pair,
            open_time,
        )
        self._add_integrity(rule_selection.integrity_note)
        rule = rule_selection.rule
        reference_open = self._mark_price(record.intent.trading_pair, open_time)

        quantized = quantize_open(rule, record.intent.requested_amount_base, reference_open)
        if quantized.rejection is not None:
            self._reject_record(
                record,
                target,
                quantized.rejection,
                "quantization failed",
            )
            return

        reference_equity = self._current_equity_quote()
        if reference_equity <= ZERO:
            self._reject_record(
                record,
                target,
                RejectionCode.REJECTED_INSUFFICIENT_BALANCE,
                "no reference equity",
            )
            return

        target_exposure = quantized.notional_quote / reference_equity
        request = CausalLongRequest(
            symbol=symbol,
            decision_time=record.intent.decision_time,
            execute_time=open_time,
            target_exposure=target_exposure,
            stop_fraction=record.intent.stop_fraction,
        )
        position_state = _run_kernel_call(open_long, request, bundle, self._cost_model)
        if expiry is not None:
            schedule_long_exit(position_state, expiry, "expiry")

        entry_cost_quote = (
            position_state.ledger[0].fee_cost + position_state.ledger[0].slippage_cost
        ) * reference_equity
        proposed_margin = (
            quantized.notional_quote / Decimal(record.intent.leverage)
        )
        available = reference_equity - self._reserved_margin_quote()
        if proposed_margin + entry_cost_quote > available:
            self._reject_record(
                record,
                target,
                RejectionCode.REJECTED_INSUFFICIENT_BALANCE,
                "insufficient balance",
            )
            return

        projected_gross = self._active_gross(target)
        projected_gross += quantized.notional_quote / reference_equity
        if projected_gross > self._max_gross:
            self._reject_record(
                record,
                target,
                RejectionCode.REJECTED_GROSS_CAP,
                "max gross exceeded",
            )
            return

        if self.active_count + 1 > self._max_legs:
            self._reject_record(
                record,
                target,
                RejectionCode.REJECTED_MAX_LEGS,
                "max legs exceeded",
            )
            return

        record.status = ExecutorStatus.ACTIVE
        record.quantized_amount_base = quantized.amount_base
        record.entry_notional_quote = quantized.notional_quote
        record.reference_equity_quote = reference_equity
        record.margin_reserved_quote = proposed_margin
        record.position_state = position_state
        record.closed_trade = None
        record.rejection = None
        self._convert_ledger_events(record)
        record.latest_position_snapshot = _run_kernel_call(snapshot_long, position_state, bundle, open_time)
        self._trace(
            open_time,
            record.intent.executor_id,
            EventPhase.ENTRY,
            "OPEN",
            {
                "decision_time": record.intent.decision_time.isoformat(),
                "action_sequence": record.intent.action_sequence,
                "open_time": open_time.isoformat(),
            },
            amount_base=record.quantized_amount_base,
            reference_price=record.position_state.entry_reference_price,
        )
        if expiry is not None:
            self._trace(
                open_time,
                record.intent.executor_id,
                EventPhase.ENTRY,
                "SCHEDULE_EXIT",
                {"expiry": expiry.isoformat(), "reason": "expiry"},
            )
        if record.intent.leverage != 1:
            self._trace(
                open_time,
                record.intent.executor_id,
                EventPhase.ENTRY,
                "LEVERAGE",
                {"value": str(record.intent.leverage)},
            )

    def _advance_active(self, record: ExecutorRecord, target: pd.Timestamp) -> None:
        if record.position_state is None:
            return
        bundle = self._market_data._symbol_data[pair_to_symbol(record.intent.trading_pair)]
        closed_trade = _run_kernel_call(advance_long, record.position_state, bundle, through=target)
        if closed_trade is not None:
            self._validate_closed_trade(record, closed_trade)
            self._close(record, closed_trade)
            self._trace(
                closed_trade.exit_time,
                record.intent.executor_id,
                EventPhase.EXIT,
                "NATURAL_CLOSE",
                {
                    "action_sequence": record.intent.action_sequence,
                    "reason": closed_trade.exit_reason,
                },
            )

        if closed_trade is None:
            self._convert_ledger_events(record)
            self._refresh_active_snapshot(record, target)

    def _process_stops_for_record(self, stops: list[AuditedStopIntent], target: pd.Timestamp) -> list[AuditedStopIntent]:
        keep: list[AuditedStopIntent] = []
        for stop in sorted(
            stops,
            key=lambda item: (
                self._stop_execution_time(item),
                item.action_sequence,
            ),
        ):
            if stop.executor_id not in self._records:
                continue
            exec_time = self._stop_execution_time(stop)
            if exec_time > target:
                keep.append(stop)
                continue
            if exec_time < target:
                raise AuditedBacktestError(
                    BlockingCode.NON_CAUSAL_TIMESTAMP,
                    "stop exec_time must equal target execution time",
                )
            self._apply_stop(stop, exec_time)
        return keep

    @staticmethod
    def _stop_execution_time(stop: AuditedStopIntent) -> pd.Timestamp:
        return (
            _to_utc_timestamp(stop.eligible_execution_time, "eligible_execution_time")
            if stop.eligible_execution_time is not None
            else _to_utc_timestamp(stop.decision_time, "decision_time")
        )

    def _apply_stop(self, stop: AuditedStopIntent, exec_time: pd.Timestamp) -> None:
        record = self._records[stop.executor_id]
        if record.status in (
            ExecutorStatus.CLOSED,
            ExecutorStatus.REJECTED,
            ExecutorStatus.CANCELLED,
        ):
            self._append_rejection(
                stop.executor_id,
                exec_time,
                RejectionCode.IDEMPOTENT_DUPLICATE_STOP,
                "idempotent duplicate stop",
            )
            self._trace(
                exec_time,
                stop.executor_id,
                EventPhase.EXIT,
                "STOP_REJECTED_DUPLICATE",
                {"action_sequence": stop.action_sequence},
            )
            return
        if record.status is ExecutorStatus.PENDING:
            record.status = ExecutorStatus.CANCELLED
            record.rejection = Rejection(
                executor_id=record.intent.executor_id,
                timestamp=exec_time,
                code=RejectionCode.CANCELLED_BEFORE_FILL,
                details={"details": "stop before fill"},
            )
            self._rejections.append(record.rejection)
            self._trace(
                exec_time,
                record.intent.executor_id,
                EventPhase.EXIT,
                "CANCELLED_BEFORE_FILL",
                {"action_sequence": stop.action_sequence},
            )
            return

        if record.status is not ExecutorStatus.ACTIVE or record.position_state is None:
            return

        symbol = pair_to_symbol(record.intent.trading_pair)
        bundle = self._market_data._symbol_data[symbol]
        schedule_long_exit(record.position_state, exec_time, "controller")
        closed = _run_kernel_call(advance_long, record.position_state, bundle, through=exec_time)
        if closed is not None:
            self._validate_closed_trade(record, closed)
            self._close(record, closed)
            self._trace(
                closed.exit_time,
                record.intent.executor_id,
                EventPhase.EXIT,
                "CLOSE",
                {"action_sequence": stop.action_sequence, "reason": closed.exit_reason},
            )
        else:
            self._convert_ledger_events(record)
            self._trace(
                exec_time,
                record.intent.executor_id,
                EventPhase.EXIT,
                "STOP_SCHEDULED",
                {"action_sequence": stop.action_sequence, "reason": "controller"},
            )

    def _ensure_reduce_only_closeable(
        self,
        record: ExecutorRecord,
        at: pd.Timestamp,
        close_reference: Decimal,
    ) -> None:
        rule_selection = self._rules.rule_at(record.intent.connector_name, record.intent.trading_pair, at)
        self._add_integrity(rule_selection.integrity_note)
        if rule_selection.rule.reduce_only_min_notional_exempt:
            return
        close_amount = _as_decimal(record.quantized_amount_base, "close_amount")
        close_reference = _as_decimal(close_reference, "close_reference")
        if close_reference <= ZERO:
            raise AuditedBacktestError(
                BlockingCode.EXIT_DUST_UNCLOSEABLE,
                f"{record.intent.executor_id}: close residue below exempt minimum",
            )
        if close_amount < rule_selection.rule.min_order_size:
            raise AuditedBacktestError(
                BlockingCode.EXIT_DUST_UNCLOSEABLE,
                f"{record.intent.executor_id}: close residue below exempt minimum",
            )
        if close_amount * close_reference < rule_selection.rule.min_notional_size:
            raise AuditedBacktestError(
                BlockingCode.EXIT_DUST_UNCLOSEABLE,
                f"{record.intent.executor_id}: close residue below exempt minimum",
            )

    def _validate_closed_trade(self, record: ExecutorRecord, closed_trade: ClosedTrade) -> None:
        close_reference = _as_decimal(closed_trade.exit_reference_price, "exit_reference_price")
        if close_reference <= ZERO:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{record.intent.trading_pair}: invalid close reference price",
            )
        self._ensure_reduce_only_closeable(record, closed_trade.exit_time, close_reference)

    def _close(self, record: ExecutorRecord, closed_trade: ClosedTrade) -> None:
        record.status = ExecutorStatus.CLOSED
        record.closed_trade = closed_trade
        if record.position_state is not None:
            record.position_state.closed_trade = closed_trade
            record.latest_position_snapshot = _run_kernel_call(
                snapshot_long,
                record.position_state,
                self._market_data._symbol_data[pair_to_symbol(record.intent.trading_pair)],
                closed_trade.exit_time,
            )
        record.margin_reserved_quote = ZERO
        self._convert_ledger_events(record)

    def _refresh_active_snapshot(self, record: ExecutorRecord, at: pd.Timestamp) -> None:
        bundle = self._market_data._symbol_data[pair_to_symbol(record.intent.trading_pair)]
        snapshot = _run_kernel_call(snapshot_long, record.position_state, bundle, at)
        if snapshot.is_active:
            record.latest_position_snapshot = snapshot

    def _convert_ledger_events(self, record: ExecutorRecord) -> None:
        if record.position_state is None:
            return
        if record.reference_equity_quote is None or record.reference_equity_quote == ZERO:
            return
        state = record.position_state
        events = list(record.quote_ledger)
        for ledger_event in state.ledger[record.converted_ledger_count :]:
            events.append(_convert_ledger(ledger_event, record.reference_equity_quote))
        if events:
            record.quote_ledger = tuple(events)
            record.converted_ledger_count = len(state.ledger)

    def _reject_record(self, record: ExecutorRecord, when: pd.Timestamp, code: RejectionCode, reason: str) -> None:
        rejection = Rejection(
            executor_id=record.intent.executor_id,
            timestamp=when,
            code=code,
            details={"details": reason},
        )
        record.status = ExecutorStatus.REJECTED
        record.rejection = rejection
        self._rejections.append(rejection)
        self._trace(
            when,
            record.intent.executor_id,
            EventPhase.ENTRY,
            "REJECT",
            {"code": code.name, "reason": reason},
        )

    def _append_rejection(
        self,
        executor_id: str,
        decision_time: pd.Timestamp,
        code: RejectionCode,
        reason: str,
    ) -> None:
        self._rejections.append(
            Rejection(
                executor_id=executor_id,
                timestamp=decision_time,
                code=code,
                details={"details": reason},
            )
        )

    def _append_position_snapshot(self, at: pd.Timestamp) -> None:
        active_records = self._active_records()
        realized_ledger_pnl, active_snapshot_pnl, active_ledger_pnl = self._equity_components()
        active_unrealized_pnl = active_snapshot_pnl - active_ledger_pnl

        positions: dict[str, tuple[Decimal, Decimal]] = {}
        for record in active_records:
            pair = record.intent.trading_pair
            amount_base = record.quantized_amount_base
            notional_quote = amount_base * self._mark_price(pair, at)
            prior_amount, prior_notional = positions.get(pair, (ZERO, ZERO))
            positions[pair] = (prior_amount + amount_base, prior_notional + notional_quote)
        positions_sorted = MappingProxyType(
            {
                pair: positions[pair]
                for pair in sorted(positions)
            }
        )
        positions_mapped = MappingProxyType(
            {
                pair: MappingProxyType(
                    {
                        "amount_base": amount_base,
                        "notional_quote": notional_quote,
                    }
                )
                for pair, (amount_base, notional_quote) in positions_sorted.items()
            }
        )
        current_equity = self._current_equity_quote()

        snapshot = {
            "timestamp": at,
            "active_executor_ids": tuple(sorted(record.intent.executor_id for record in active_records)),
            "pairs": tuple(sorted({record.intent.trading_pair for record in active_records})),
            "positions": positions_mapped,
            "realized_ledger_pnl": realized_ledger_pnl,
            "active_unrealized_pnl": active_unrealized_pnl,
            "gross": self._active_gross(at),
            "reserved_margin": self._reserved_margin_quote(),
            "net_liquidation_equity": current_equity,
        }
        self._position_snapshots.append(snapshot)

    def _reserved_margin_quote(self) -> Decimal:
        return sum(
            record.margin_reserved_quote
            for record in self._records.values()
            if record.status is ExecutorStatus.ACTIVE
        )

    def _active_gross(self, at: pd.Timestamp | None = None) -> Decimal:
        if at is None:
            at = self._time
        current_equity = self._current_equity_quote()
        if current_equity <= ZERO:
            return ZERO
        return self._active_marked_notional(at) / current_equity

    def _add_integrity(self, note: str | None) -> None:
        if note:
            self._integrity_notes.add(note)

    def _trace(
        self,
        event_time: pd.Timestamp,
        executor_id: str,
        phase: EventPhase,
        event: str,
        details: Mapping[str, object],
        *,
        amount_base: Decimal | None = None,
        reference_price: Decimal | None = None,
    ) -> None:
        timestamp = _to_utc_timestamp(event_time, "trace_time")
        self._order_trace.append(
            (
                timestamp,
                int(phase),
                executor_id,
                event,
                self._order_event_seq,
                OrderTrace(
                    executor_id=executor_id,
                    timestamp=timestamp,
                    event=event,
                    amount_base=amount_base,
                    reference_price=reference_price,
                    details={str(key): str(value) for key, value in details.items()},
                ),
            )
        )
        self._order_event_seq += 1

    @staticmethod
    def _normalize_event_times(event_times: Iterable[pd.Timestamp] | pd.DatetimeIndex) -> pd.DatetimeIndex:
        index = pd.DatetimeIndex(event_times)
        if index.tz is None:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                "event_times: expected timezone-aware timestamps",
            )
        index = index.tz_convert("UTC")
        if not index.is_unique or not index.is_monotonic_increasing:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                "event_times: expected unique increasing UTC timestamps",
            )
        for previous, current in zip(index, index[1:]):
            if current <= previous:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    "event_times: expected strictly increasing UTC timestamps",
                )
        return index

    def _verify_quote_scaling(self) -> tuple[Decimal, Decimal, tuple[Mapping[str, str], ...]]:
        return self._verify_quote_scaling_exact()

    def _verify_quote_scaling_exact(
        self,
    ) -> tuple[Decimal, Decimal, tuple[Mapping[str, str], ...]]:
        max_event_residual = ZERO
        aggregate_residual = ZERO
        violations: list[Mapping[str, str]] = []

        def add_residual(
            executor_id: str,
            field: str,
            residual: Decimal,
            **details: str,
        ) -> None:
            nonlocal max_event_residual, aggregate_residual
            if residual == ZERO:
                return
            abs_residual = residual.copy_abs()
            max_event_residual = max(max_event_residual, abs_residual)
            aggregate_residual = _exact_decimal_sum((aggregate_residual, abs_residual))
            payload = {
                "executor_id": executor_id,
                "field": field,
                "residual": str(residual),
                "abs_residual": str(abs_residual),
            }
            payload.update(details)
            violations.append(MappingProxyType(payload))

        def add_aggregate_residual(residual: Decimal) -> None:
            nonlocal aggregate_residual
            if residual:
                aggregate_residual = _exact_decimal_sum((aggregate_residual, residual.copy_abs()))

        def add_structure(
            executor_id: str,
            field: str,
            **details: str,
        ) -> None:
            payload = {
                "executor_id": executor_id,
                "field": field,
            }
            payload.update(details)
            violations.append(MappingProxyType(payload))

        for record in sorted(
            self._records.values(),
            key=lambda item: item.intent.executor_id,
        ):
            if record.position_state is None or record.reference_equity_quote is None:
                continue
            executor_id = record.intent.executor_id
            reference = record.reference_equity_quote
            raw_ledger = record.position_state.ledger
            quote_ledger = record.quote_ledger
            if record.converted_ledger_count != len(raw_ledger):
                add_structure(
                    executor_id,
                    "converted_ledger_count",
                    converted_ledger_count=str(record.converted_ledger_count),
                    raw_ledger_length=str(len(raw_ledger)),
                )
            if len(raw_ledger) != len(quote_ledger):
                add_structure(
                    executor_id,
                    "ledger_length",
                    raw_ledger_length=str(len(raw_ledger)),
                    quote_ledger_length=str(len(quote_ledger)),
                    detail="ledger length mismatch",
                )

            for index, (raw, converted) in enumerate(
                zip(raw_ledger, quote_ledger),
            ):
                if raw.timestamp != converted.timestamp:
                    add_structure(
                        executor_id,
                        "timestamp",
                        index=str(index),
                        raw_timestamp=raw.timestamp.isoformat(),
                        quote_timestamp=converted.timestamp.isoformat(),
                    )

                raw_identity_residual = _exact_decimal_product(
                    _exact_decimal_sum((
                        raw.net_pnl,
                        raw.price_pnl.copy_negate(),
                        raw.funding_pnl.copy_negate(),
                        raw.fee_cost,
                        raw.slippage_cost,
                    )),
                    reference,
                )
                add_residual(
                    executor_id,
                    "net_pnl_raw_identity",
                    raw_identity_residual,
                    index=str(index),
                    timestamp=converted.timestamp.isoformat(),
                )

                for field, raw_value in {
                    "price_pnl": raw.price_pnl,
                    "fee_cost": raw.fee_cost,
                    "slippage_cost": raw.slippage_cost,
                    "funding_pnl": raw.funding_pnl,
                    "net_pnl": raw.net_pnl,
                }.items():
                    expected = _exact_decimal_product(raw_value, reference)
                    actual = getattr(converted, field)
                    residual = _exact_decimal_sum((actual, expected.copy_negate()))
                    add_residual(
                        executor_id,
                        field,
                        residual,
                        index=str(index),
                        timestamp=converted.timestamp.isoformat(),
                    )

                quote_identity_residual = _exact_decimal_sum((
                    converted.net_pnl,
                    converted.price_pnl.copy_negate(),
                    converted.funding_pnl.copy_negate(),
                    converted.fee_cost,
                    converted.slippage_cost,
                ))
                add_residual(
                    executor_id,
                    "net_pnl_quote_identity",
                    quote_identity_residual,
                    index=str(index),
                    timestamp=converted.timestamp.isoformat(),
                )

            closed_trade = record.closed_trade
            state_closed_trade = record.position_state.closed_trade
            if record.status is ExecutorStatus.CLOSED:
                if closed_trade is None:
                    add_structure(executor_id, "closed_trade_missing")
                    continue
                if state_closed_trade != closed_trade:
                    add_structure(executor_id, "closed_trade_state_mismatch")
                if tuple(raw_ledger) != closed_trade.ledger:
                    add_structure(executor_id, "closed_trade_ledger")
                for trade_field, event_field in (
                    ("gross_pnl", "price_pnl"),
                    ("fee_cost", "fee_cost"),
                    ("slippage_cost", "slippage_cost"),
                    ("funding_pnl", "funding_pnl"),
                    ("net_pnl", "net_pnl"),
                ):
                    raw_total = _exact_decimal_sum(getattr(event, event_field) for event in raw_ledger)
                    closed_value = getattr(closed_trade, trade_field)
                    add_aggregate_residual(
                        _exact_decimal_product(
                            _exact_decimal_sum((closed_value, raw_total.copy_negate())),
                            reference,
                        )
                    )
                    quote_total = _exact_decimal_sum(getattr(event, event_field) for event in quote_ledger)
                    add_aggregate_residual(
                        _exact_decimal_sum(
                            (
                                quote_total,
                                _exact_decimal_product(closed_value, reference).copy_negate(),
                            )
                        )
                    )
            elif closed_trade is not None or state_closed_trade is not None:
                add_structure(executor_id, "closed_trade_lifecycle")
        violations = sorted(
            violations,
            key=lambda item: (
                item["executor_id"],
                item.get("index", ""),
                item.get("field", ""),
                item.get("timestamp", ""),
                item.get("raw_timestamp", ""),
                item.get("quote_timestamp", ""),
            ),
        )
        return max_event_residual, aggregate_residual, tuple(violations)


def _convert_ledger(event: Any, reference_equity: Decimal) -> QuoteLedgerEvent:
    return QuoteLedgerEvent(
        timestamp=event.timestamp,
        price_pnl=_exact_decimal_product(event.price_pnl, reference_equity),
        fee_cost=_exact_decimal_product(event.fee_cost, reference_equity),
        slippage_cost=_exact_decimal_product(event.slippage_cost, reference_equity),
        funding_pnl=_exact_decimal_product(event.funding_pnl, reference_equity),
        net_pnl=_exact_decimal_product(event.net_pnl, reference_equity),
    )
