"""Pure, deterministic result serialization for audited backtests."""
from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from enum import Enum
from typing import Any

import pandas as pd

from research.hummingbot_audited.engine import AUDIT_DECIMAL_PRECISION, ExecutorStatus
from research.hummingbot_audited.timeline import AUDITED_EVENT_CLOCK_VERSION


# This context is treated as immutable by convention; localcontext() copies it
# for each payload build so caller settings cannot affect result arithmetic.
FIXED_CONTEXT = Context(
    prec=AUDIT_DECIMAL_PRECISION,
    rounding=ROUND_HALF_EVEN,
    Emin=-999999,
    Emax=999999,
    capitals=1,
    clamp=0,
    flags=[],
    traps=[],
)


def _timestamp(value: pd.Timestamp) -> str:
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is None:
        raise ValueError("timestamp must be timezone-aware")
    return timestamp.tz_convert("UTC").isoformat(timespec="microseconds").replace("+00:00", "Z")


def _enum_value(value: Enum) -> str:
    return value.value if isinstance(value.value, str) else value.name


def _canonical(value: Any) -> Any:
    if isinstance(value, Enum):
        return _enum_value(value)
    if isinstance(value, pd.Timestamp):
        return _timestamp(value)
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("Decimal must be finite")
        return str(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("float must be finite")
        return value
    if isinstance(value, Mapping):
        items = []
        for key, item in value.items():
            normalized_key = _canonical(key)
            if not isinstance(normalized_key, str):
                normalized_key = str(normalized_key)
            if any(existing_key == normalized_key for existing_key, _ in items):
                raise ValueError(f"normalized mapping key collision: {normalized_key}")
            items.append((normalized_key, _canonical(item)))
        return {key: item for key, item in sorted(items, key=lambda pair: pair[0])}
    if hasattr(value, "model_dump") and callable(value.model_dump):
        return _canonical(value.model_dump(by_alias=True, exclude_none=False))
    if is_dataclass(value) and not isinstance(value, type):
        return _canonical({field.name: getattr(value, field.name) for field in fields(value)})
    if isinstance(value, (tuple, list)):
        return [_canonical(item) for item in value]
    if value is None or isinstance(value, (bool, str, int)):
        return value
    raise TypeError(f"unsupported canonical value: {type(value).__name__}")


def _canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        _canonical(value),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def canonical_json_bytes(value: Any) -> bytes:
    """Return compact UTF-8 JSON with stable recursive normalization."""
    with localcontext(FIXED_CONTEXT):
        return _canonical_json_bytes(value)


def canonical_result_hash(payload: Mapping[str, object]) -> str:
    with localcontext(FIXED_CONTEXT):
        core = dict(payload)
        core.pop("runtime", None)
        audit = core.get("audit")
        if isinstance(audit, Mapping):
            audit = dict(audit)
            audit.pop("canonical_result_hash", None)
            core["audit"] = audit
        return hashlib.sha256(_canonical_json_bytes(core)).hexdigest()


def _record_ledger(record: Any) -> list[dict[str, Any]]:
    return [
        {
            "executor_id": record.intent.executor_id,
            "timestamp": event.timestamp,
            "price_pnl": event.price_pnl,
            "fee_cost": event.fee_cost,
            "slippage_cost": event.slippage_cost,
            "funding_pnl": event.funding_pnl,
            "net_pnl": event.net_pnl,
        }
        for event in record.quote_ledger
    ]


def _close_type(record: Any) -> str | None:
    if record.closed_trade is None:
        return None
    reason = record.closed_trade.exit_reason
    return {
        "stop": "STOP_LOSS",
        "expiry": "TIME_LIMIT",
        "signal": "EARLY_STOP",
        "controller": "EARLY_STOP",
    }[reason]


def _filled_volume(record: Any) -> Decimal:
    if record.status is ExecutorStatus.ACTIVE:
        return record.quantized_amount_base * record.position_state.entry_fill_price
    if record.status is ExecutorStatus.CLOSED:
        trade = record.closed_trade
        return record.quantized_amount_base * (record.position_state.entry_fill_price + trade.exit_price)
    return Decimal("0")


def _sum(records: list[Any], attr: str) -> Decimal:
    return sum((getattr(record, attr) for record in records), Decimal("0"))


def _metric(value: Decimal) -> str:
    if not value.is_finite():
        raise ValueError("Decimal must be finite")
    if value.is_zero():
        return "0"
    formatted = format(value, "f")
    if "." in formatted:
        formatted = formatted.rstrip("0").rstrip(".")
    return formatted


def _build_result_payload(output: Any, *, generated_at: Any = None, runtime_seconds: Any = None) -> dict[str, Any]:
    records = [
        record for record in output.records
        if record.status in {ExecutorStatus.PENDING, ExecutorStatus.ACTIVE, ExecutorStatus.CLOSED}
    ]
    active = [record for record in records if record.status is ExecutorStatus.ACTIVE]
    closed = [record for record in records if record.status is ExecutorStatus.CLOSED]
    snapshots = list(output.position_held_timeseries)
    final = snapshots[-1] if snapshots else {"net_liquidation_equity": output.initial_quote_equity}
    final_pnl = final["net_liquidation_equity"] - output.initial_quote_equity

    position_holds = []
    for record in active:
        ledger_net = sum((event.net_pnl for event in record.quote_ledger), Decimal("0"))
        position_holds.append({
            "executor_id": record.intent.executor_id,
            "connector": record.intent.connector_name,
            "trading_pair": record.intent.trading_pair,
            "side": record.intent.side,
            "amount_base": record.quantized_amount_base,
            "entry_price": record.position_state.entry_fill_price,
            "entry_time": record.entry_time,
            "exit_time": None,
            "unrealized_pnl_quote": _metric(record.net_pnl_quote - ledger_net),
        })

    close_counts: dict[str, int] = {}
    for record in closed:
        close = _close_type(record)
        if close is not None:
            close_counts[close] = close_counts.get(close, 0) + 1
    limitations = {str(item.get("code")) for item in output.integrity}
    if output.rule_policy.value == "pinned_snapshot":
        limitations.add("NON_HISTORICAL_RULES")

    audit = {
        "action_trace": output.action_trace,
        "order_trace": output.order_trace,
        "data_read_trace": output.data_read_trace,
        "ledger": [entry for record in records for entry in _record_ledger(record)],
        "rejections": output.rejections,
        "integrity": {"blocking": [], "limitations": sorted(limitations)},
        "manifest": output.manifest,
        "request_hash": output.request_hash,
        "run_id": output.run_id,
        "git_sha": output.git_sha,
        "controller_config_hash": output.controller_config_hash,
        "trading_rules_hash": output.trading_rules_hash,
        "hummingbot_image_digest": output.hummingbot_image_digest,
        "event_clock_version": AUDITED_EVENT_CLOCK_VERSION,
        "parity_summary": output.parity_summary,
        "deployment_authorized": False,
    }
    payload = {
        "executors": output.executors,
        "processed_data": output.processed_data,
        "results": {
            "total_executors": len(records),
            "closed_executors": len(closed),
            "net_pnl_quote": _metric(final_pnl),
            "net_pnl_pct": _metric(final_pnl / output.initial_quote_equity),
            "fee_quote": _metric(_sum(records, "fee_quote")),
            "slippage_quote": _metric(_sum(records, "slippage_quote")),
            "funding_quote": _metric(_sum(records, "funding_quote")),
            "volume": _metric(sum((_filled_volume(record) for record in records), Decimal("0"))),
            "close_type_counts": close_counts,
            "result_grade": "decision_grade" if output.decision_grade_eligible else "development",
        },
        "position_holds": position_holds,
        "position_held_timeseries": snapshots,
        "pnl_timeseries": [
            {"timestamp": snapshot["timestamp"], "value": _metric(snapshot["net_liquidation_equity"] - output.initial_quote_equity)}
            for snapshot in snapshots
        ],
        "audit": audit,
        "runtime": {"generated_at": generated_at, "runtime_seconds": runtime_seconds},
    }
    payload["audit"]["canonical_result_hash"] = canonical_result_hash(payload)
    return _canonical(payload)


def build_result_payload(output: Any, *, generated_at: Any = None, runtime_seconds: Any = None) -> dict[str, Any]:
    with localcontext(FIXED_CONTEXT):
        return _build_result_payload(output, generated_at=generated_at, runtime_seconds=runtime_seconds)


__all__ = ["build_result_payload", "canonical_json_bytes", "canonical_result_hash"]
