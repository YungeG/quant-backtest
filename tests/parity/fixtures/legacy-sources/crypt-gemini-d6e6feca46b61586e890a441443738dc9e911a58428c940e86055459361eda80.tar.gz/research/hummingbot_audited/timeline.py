from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from enum import IntEnum

import pandas as pd

from research.hummingbot_audited.contracts import AuditedBacktestError, BlockingCode

AUDITED_EVENT_CLOCK_VERSION = "hbot-audited-v1"


class EventPhase(IntEnum):
    PATH_AND_FUNDING = 10
    EXIT = 20
    ENTRY = 30
    CONTROLLER = 40


def decision_times(
    start: pd.Timestamp,
    end: pd.Timestamp,
    resolution: str,
) -> pd.DatetimeIndex:
    try:
        start_utc = pd.Timestamp(start).tz_convert("UTC")
        end_utc = pd.Timestamp(end).tz_convert("UTC")
    except TypeError as exc:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "decision_times: timezone-aware start/end timestamps required",
        ) from exc

    if start_utc.tzinfo is None or end_utc.tzinfo is None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "decision_times: timezone-aware start/end timestamps required",
        )

    if resolution not in {"1h", "12h", "1d"}:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"decision_times: unsupported resolution {resolution!r}",
        )

    resolved = {"1d": "1D"}.get(resolution, resolution)
    return pd.date_range(start_utc, end_utc, freq=resolved, tz="UTC")


def _to_utc_timestamp(value: object, context: str) -> pd.Timestamp:
    try:
        if isinstance(value, pd.Timestamp):
            timestamp = value
        else:
            timestamp = pd.Timestamp(value)
    except (TypeError, ValueError) as exc:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{context}: expected timestamp",
        ) from exc

    if pd.isna(timestamp):
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{context}: timestamp cannot be NaT",
        )

    if timestamp.tzinfo is None:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{context}: timezone-aware timestamp required",
        )

    return timestamp.tz_convert("UTC")


def _as_utc_index(values: Iterable[object], context: str) -> pd.DatetimeIndex:
    if isinstance(values, pd.DatetimeIndex):
        values = values.tolist()
    values_list = list(values)
    if not values_list:
        return pd.DatetimeIndex([], tz="UTC")
    normalized = pd.DatetimeIndex([_to_utc_timestamp(value, context) for value in values_list])

    if not normalized.is_unique or not normalized.is_monotonic_increasing:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"{context}: expected unique strictly increasing UTC timestamps",
        )

    for previous, current in zip(normalized, normalized[1:]):
        if current <= previous:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"{context}: expected strictly increasing UTC timestamps",
            )

    return normalized


class TradableCalendar:
    def __init__(
        self,
        tradable_opens_by_pair: Mapping[str, Sequence[pd.Timestamp] | pd.DatetimeIndex],
        *,
        funding_times: Sequence[pd.Timestamp] | pd.DatetimeIndex | None = None,
        end_time: pd.Timestamp | None = None,
    ) -> None:
        if not isinstance(tradable_opens_by_pair, Mapping):
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                "tradable_opens_by_pair: expected mapping",
            )

        self._tradable_opens_by_pair: dict[str, pd.DatetimeIndex] = {}

        for pair, opens in tradable_opens_by_pair.items():
            if not isinstance(pair, str) or not pair:
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    "tradable_opens_by_pair: expected non-empty pair names",
                )

            if not isinstance(opens, (pd.DatetimeIndex, Sequence)):
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"{pair}: expected sequence of UTC timestamps",
                )

            opens_index = _as_utc_index(opens, f"trading_opens[{pair}]")
            if any(
                ts.minute != 0
                or ts.second != 0
                or ts.microsecond != 0
                or ts.nanosecond != 0
                for ts in opens_index
            ):
                raise AuditedBacktestError(
                    BlockingCode.DATA_GAP,
                    f"trading_opens[{pair}]: expected hourly boundaries",
                )
            self._tradable_opens_by_pair[pair] = opens_index

        self._funding_times = pd.DatetimeIndex([], tz="UTC")
        if funding_times is not None:
            self._funding_times = _as_utc_index(funding_times, "funding_times")

        self._end_time = _to_utc_timestamp(end_time, "end_time") if end_time is not None else None

    def next_open_after(
        self,
        trading_pair: str,
        timestamp: pd.Timestamp,
    ) -> pd.Timestamp | None:
        if trading_pair not in self._tradable_opens_by_pair:
            return None

        opens = self._tradable_opens_by_pair[trading_pair]
        target = _to_utc_timestamp(timestamp, "timestamp")
        index = opens.searchsorted(target, side="right")
        if index >= len(opens):
            return None

        value = opens[index]
        if self._end_time is not None and value > self._end_time:
            return None
        return value

    def first_open_at_or_after(
        self,
        trading_pair: str,
        timestamp: pd.Timestamp,
    ) -> pd.Timestamp | None:
        if trading_pair not in self._tradable_opens_by_pair:
            return None

        opens = self._tradable_opens_by_pair[trading_pair]
        target = _to_utc_timestamp(timestamp, "timestamp")
        index = opens.searchsorted(target, side="left")
        if index >= len(opens):
            return None

        value = opens[index]
        if self._end_time is not None and value > self._end_time:
            return None
        return value

    def event_times(
        self,
        start: pd.Timestamp,
        end: pd.Timestamp,
        decisions: pd.DatetimeIndex,
    ) -> pd.DatetimeIndex:
        start_utc = _to_utc_timestamp(start, "start")
        end_utc = _to_utc_timestamp(end, "end")

        if end_utc < start_utc:
            return pd.DatetimeIndex([], tz="UTC")

        if self._end_time is not None:
            end_utc = min(end_utc, self._end_time)

        candidate_times: list[pd.Timestamp] = []

        for opens in self._tradable_opens_by_pair.values():
            candidate_times.extend(opens[(opens >= start_utc) & (opens <= end_utc)])

        if len(self._funding_times):
            funding_candidates = self._funding_times[
                (self._funding_times >= start_utc) & (self._funding_times <= end_utc)
            ]
            candidate_times.extend(funding_candidates)

        for decision in decisions:
            candidate = _to_utc_timestamp(decision, "decision")
            if start_utc <= candidate <= end_utc:
                candidate_times.append(candidate)

        if not candidate_times:
            return pd.DatetimeIndex([], tz="UTC")

        events = pd.DatetimeIndex(candidate_times, tz="UTC").unique().sort_values()
        if not events.is_monotonic_increasing:
            # `sort_values()` guarantees this, but defensive check keeps the contract explicit.
            events = events.sort_values()
        return events

__all__ = [
    "AUDITED_EVENT_CLOCK_VERSION",
    "EventPhase",
    "TradableCalendar",
    "decision_times",
]
