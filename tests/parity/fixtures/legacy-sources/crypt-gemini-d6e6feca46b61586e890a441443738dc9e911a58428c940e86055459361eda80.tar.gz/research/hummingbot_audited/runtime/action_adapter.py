from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import timedelta
from hashlib import sha256
from decimal import Decimal
from types import MappingProxyType
from typing import Any

import pandas as pd

from research.hummingbot_audited.contracts import (
    AuditedBacktestError,
    AuditedPositionIntent,
    AuditedStopIntent,
    BlockingCode,
    Rejection,
    RejectionCode,
    as_decimal,
    as_utc,
)
from research.hummingbot_audited.timeline import TradableCalendar

from hummingbot.strategy_v2.executors.position_executor.data_types import PositionExecutorConfig
from hummingbot.strategy_v2.models.executor_actions import (
    CreateExecutorAction,
    StopExecutorAction,
)


def _stable_executor_id(expected_controller_id: str, decision_time: pd.Timestamp, action_sequence: int) -> str:
    stable_raw = f"{expected_controller_id}|{decision_time.isoformat()}|{action_sequence}".encode()
    return "exec-" + sha256(stable_raw).hexdigest()[:32]


def _canonical_json(payload: Any) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _normalize_decimal(value: object, name: str) -> str:
    return str(as_decimal(value, name))


def _enum_name(value: object, name: str) -> str:
    if not hasattr(value, "name"):
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            f"{name}: expected enum value",
        )
    text = str(getattr(value, "name"))
    if not text:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            f"{name}: expected non-empty enum value",
        )
    return text


def _ensure_positive_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            f"{name}: expected positive int",
        )
    if value <= 0:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            f"{name}: expected positive int",
        )
    return int(value)


def _ensure_action_sequence(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected non-negative integer",
        )
    return int(value)


def _canonical_position_payload(
    config: PositionExecutorConfig,
) -> dict[str, object]:
    barrier = config.triple_barrier_config
    return {
        "type": "position_executor",
        "controller_id": config.controller_id,
        "timestamp": str(Decimal(str(config.timestamp))),
        "connector_name": config.connector_name,
        "trading_pair": config.trading_pair,
        "side": _enum_name(config.side, "side"),
        "entry_price": None,
        "amount": _normalize_decimal(config.amount, "amount"),
        "leverage": config.leverage,
        "stop_loss": None if barrier.stop_loss is None else _normalize_decimal(barrier.stop_loss, "stop_loss"),
        "time_limit": barrier.time_limit,
        "open_order_type": _enum_name(barrier.open_order_type, "open_order_type"),
    }


def _canonical_config_hash(config: PositionExecutorConfig) -> str:
    payload = _canonical_position_payload(config)
    return sha256(_canonical_json(payload).encode()).hexdigest()


def _create_canonical_action_hash(config: PositionExecutorConfig) -> str:
    payload = {
        "action_type": "CreateExecutorAction",
        "semantic_payload": _canonical_position_payload(config),
    }
    return sha256(_canonical_json(payload).encode()).hexdigest()


def _stop_canonical_action_hash(
    *,
    executor_id: str,
    expected_controller_id: str,
    decision_time: pd.Timestamp,
) -> str:
    payload = {
        "action_type": "StopExecutorAction",
        "executor_id": executor_id,
        "controller_id": expected_controller_id,
        "decision_time": as_utc(decision_time, "decision_time").isoformat(),
    }
    return sha256(_canonical_json(payload).encode()).hexdigest()


def _next_open_for_known_stop(calendar: TradableCalendar, decision_time: pd.Timestamp, trading_pair: str) -> pd.Timestamp | None:
    pairs = getattr(calendar, "_tradable_opens_by_pair", None)
    if not isinstance(pairs, Mapping):
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            "stop: missing tradable-opens pair map",
        )
    if trading_pair not in pairs:
        raise AuditedBacktestError(
            BlockingCode.DATA_GAP,
            f"stop: trading_pair {trading_pair} missing from tradable-opens pair map",
        )
    return calendar.next_open_after(trading_pair, decision_time)


@dataclass(frozen=True)
class NormalizedCreate:
    intent: AuditedPositionIntent
    executor_config: PositionExecutorConfig
    canonical_action_hash: str


@dataclass(frozen=True)
class NormalizedStop:
    intent: AuditedStopIntent
    canonical_action_hash: str


@dataclass(frozen=True)
class NormalizedRejection:
    rejection: Rejection
    action_type: str
    canonical_action_hash: str


NormalizedAction = NormalizedCreate | NormalizedStop | NormalizedRejection


def _validate_create_semantics(
    *,
    action: CreateExecutorAction,
    config: PositionExecutorConfig,
    expected_controller_id: str,
    decision_time: pd.Timestamp,
    action_sequence: int,
) -> tuple[PositionExecutorConfig, str, pd.Timestamp | None]:
    if action.controller_id != expected_controller_id:
        raise AuditedBacktestError(
            BlockingCode.LOSSY_ACTION_MAPPING,
            "action.controller_id mismatch",
        )
    if config.controller_id != expected_controller_id:
        raise AuditedBacktestError(
            BlockingCode.LOSSY_ACTION_MAPPING,
            "config.controller_id mismatch",
        )

    try:
        action_timestamp = Decimal(str(config.timestamp))
    except Exception as exc:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "timestamp: invalid timestamp value",
        ) from exc
    if not action_timestamp.is_finite():
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "timestamp: must be finite",
        )
    if action_timestamp != Decimal(str(decision_time.timestamp())):
        raise AuditedBacktestError(
            BlockingCode.WALL_CLOCK_DEPENDENCY,
            "timestamp: controller timestamp mismatch",
        )

    barrier = config.triple_barrier_config

    if _enum_name(config.side, "side") != "BUY":
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "side: must be BUY",
        )
    if config.entry_price is not None:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "entry_price: must be None",
        )
    try:
        amount = as_decimal(config.amount, "amount")
    except AuditedBacktestError:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "amount: unsupported amount type",
        )
    if amount <= 0:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "amount: must be positive",
        )
    leverage = _ensure_positive_int(config.leverage, "leverage")

    if config.activation_bounds is not None:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "activation_bounds: unsupported",
        )
    if config.level_id is not None:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "level_id: unsupported",
        )
    if barrier is None:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "triple_barrier_config: missing",
        )
    if barrier.take_profit is not None:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "take_profit: unsupported",
        )
    if barrier.trailing_stop is not None:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "trailing_stop: unsupported",
        )
    if _enum_name(barrier.open_order_type, "open_order_type") != "MARKET":
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "open_order_type: must be MARKET",
        )

    try:
        stop_loss = None if barrier.stop_loss is None else as_decimal(barrier.stop_loss, "stop_loss")
    except AuditedBacktestError as exc:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "stop_loss: unsupported decimal value",
        ) from exc
    if stop_loss is not None:
        if not stop_loss.is_finite():
            raise AuditedBacktestError(
                BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
                "stop_loss: must be finite",
            )
        if stop_loss <= 0 or stop_loss >= 1:
            raise AuditedBacktestError(
                BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
                "stop_loss: must be in (0,1)",
            )
        if _enum_name(barrier.stop_loss_order_type, "stop_loss_order_type") != "MARKET":
            raise AuditedBacktestError(
                BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
                "stop_loss_order_type: must be MARKET",
            )
    if barrier.time_limit is not None:
        validated_time_limit = _ensure_positive_int(barrier.time_limit, "time_limit")
        if _enum_name(barrier.time_limit_order_type, "time_limit_order_type") != "MARKET":
            raise AuditedBacktestError(
                BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
                "time_limit_order_type: must be MARKET",
            )
    else:
        validated_time_limit = None

    stable_id = _stable_executor_id(expected_controller_id, decision_time, action_sequence)
    canonical_config = config.model_copy(update={"id": stable_id})
    canonical_config_hash = _canonical_config_hash(config)
    deadline = (
        decision_time + timedelta(seconds=validated_time_limit)
        if validated_time_limit is not None
        else None
    )

    return canonical_config, canonical_config_hash, deadline


def normalize_action(
    action: object,
    decision_time: pd.Timestamp,
    action_sequence: int,
    calendar: TradableCalendar,
    *,
    expected_controller_id: str,
    executor_pairs: Mapping[str, str],
) -> NormalizedAction:
    if not isinstance(expected_controller_id, str) or not expected_controller_id.strip():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "expected_controller_id: must be non-empty string",
        )
    decision_time = as_utc(decision_time, "decision_time")
    action_sequence = _ensure_action_sequence(action_sequence, "action_sequence")

    if not isinstance(executor_pairs, MappingProxyType):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "executor_pairs: expected immutable mapping",
        )
    for executor_id, trading_pair in executor_pairs.items():
        if not isinstance(executor_id, str) or not executor_id.strip() or not isinstance(trading_pair, str) or not trading_pair.strip():
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "executor_pairs: keys and values must be non-empty strings")

    if not isinstance(action, (CreateExecutorAction, StopExecutorAction)):
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_TYPE,
            "action: unsupported executor action",
        )

    if isinstance(action, CreateExecutorAction):
        config = action.executor_config
        if not isinstance(config, PositionExecutorConfig):
            raise AuditedBacktestError(
                BlockingCode.UNSUPPORTED_EXECUTOR_TYPE,
                "executor_config: unsupported executor config",
            )

        executor_config, canonical_config_hash, deadline = _validate_create_semantics(
            action=action,
            config=config,
            expected_controller_id=expected_controller_id,
            decision_time=decision_time,
            action_sequence=action_sequence,
        )
        pairs = getattr(calendar, "_tradable_opens_by_pair", None)
        if not isinstance(pairs, Mapping):
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                "create: missing tradable-opens pair map",
            )
        if config.trading_pair not in pairs:
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                f"create: trading_pair {config.trading_pair} missing from tradable-opens pair map",
            )

        executable_id = _stable_executor_id(expected_controller_id, decision_time, action_sequence)
        next_open = calendar.next_open_after(
            config.trading_pair,
            decision_time,
        )
        if next_open is None:
            return NormalizedRejection(
                rejection=Rejection(
                    executor_id=executable_id,
                    timestamp=decision_time,
                    code=RejectionCode.CANCELLED_BEFORE_FILL,
                    details={"action_type": "CreateExecutorAction"},
                ),
                action_type="CreateExecutorAction",
                canonical_action_hash=_create_canonical_action_hash(config),
            )

        intent = AuditedPositionIntent(
            executor_id=executable_id,
            controller_id=expected_controller_id,
            decision_time=decision_time,
            eligible_execution_time=next_open,
            connector_name=config.connector_name,
            trading_pair=config.trading_pair,
            side="BUY",
            requested_amount_base=config.amount,
            leverage=executor_config.leverage,
            stop_fraction=None
            if executor_config.triple_barrier_config.stop_loss is None
            else Decimal(str(executor_config.triple_barrier_config.stop_loss)),
            deadline=deadline,
            canonical_config_hash=canonical_config_hash,
            action_sequence=action_sequence,
        )

        return NormalizedCreate(
            intent=intent,
            executor_config=executor_config,
            canonical_action_hash=_create_canonical_action_hash(executor_config),
        )

    if action.controller_id != expected_controller_id:
        raise AuditedBacktestError(
            BlockingCode.LOSSY_ACTION_MAPPING,
            "action.controller_id mismatch",
        )
    if action.keep_position is not False:
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            "keep_position: must be False",
        )
    if action.executor_id not in executor_pairs:
        raise AuditedBacktestError(
            BlockingCode.UNKNOWN_STOP_TARGET,
            "action.executor_id is unknown",
        )

    next_open = _next_open_for_known_stop(calendar, decision_time, executor_pairs[action.executor_id])
    intent = AuditedStopIntent(
        executor_id=action.executor_id,
        controller_id=expected_controller_id,
        decision_time=decision_time,
        eligible_execution_time=next_open,
        action_sequence=action_sequence,
    )
    if next_open is None:
        return NormalizedRejection(
            rejection=Rejection(
                executor_id=action.executor_id,
                timestamp=decision_time,
                code=RejectionCode.CANCELLED_BEFORE_FILL,
                details={"action_type": "StopExecutorAction"},
            ),
            action_type="StopExecutorAction",
            canonical_action_hash=_stop_canonical_action_hash(
                executor_id=action.executor_id,
                expected_controller_id=expected_controller_id,
                decision_time=decision_time,
            ),
        )

    return NormalizedStop(
        intent=intent,
        canonical_action_hash=_stop_canonical_action_hash(
            executor_id=action.executor_id,
            expected_controller_id=expected_controller_id,
            decision_time=decision_time,
        ),
    )


__all__ = [
    "NormalizedCreate",
    "NormalizedStop",
    "NormalizedRejection",
    "NormalizedAction",
    "normalize_action",
]
