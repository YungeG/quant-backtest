from __future__ import annotations

import asyncio
import json
import re
from collections.abc import Mapping
from decimal import Decimal
from enum import Enum
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any

from hummingbot.core.data_type.common import TradeType
from hummingbot.strategy_v2.models.base import RunnableStatus
from hummingbot.strategy_v2.models.executors import CloseType
from hummingbot.strategy_v2.models.executors_info import ExecutorInfo

from research.hummingbot_audited.contracts import (
    ActionTrace,
    AuditedBacktestError,
    BlockingCode,
    Rejection,
    RejectionCode,
    RunnerOutput,
)
from research.hummingbot_audited.engine import AuditedPortfolioEngine, ExecutorStatus
from research.hummingbot_audited.runtime.action_adapter import (
    NormalizedCreate,
    NormalizedRejection,
    NormalizedStop,
    normalize_action,
)
from research.hummingbot_audited.runtime.provider import ManifestBacktestingDataProvider
from research.hummingbot_audited.timeline import TradableCalendar, decision_times
from strategy.chan_reversal.chan_reversal_follower import (
    ChanReversalFollowerConfig,
    ChanReversalFollowerController,
)

_HASH_40 = re.compile(r"^[0-9a-f]{40}$")
_HASH_64 = re.compile(r"^[0-9a-f]{64}$")
_RUN_ID = re.compile(r"^hba-[0-9a-f]{24}$")


def _ensure_sha_hash(value: str, expr: re.Pattern[str], name: str, expected: str) -> str:
    if not isinstance(value, str):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected lowercase hex")
    if not expr.fullmatch(value):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: must be {expected}")
    return value


def _serialize_payload(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            key: _serialize_payload(item)
            for key, item in sorted(value.items(), key=lambda item: str(item[0]))
        }
    if isinstance(value, tuple):
        return tuple(_serialize_payload(item) for item in value)
    if isinstance(value, list):
        return [_serialize_payload(item) for item in value]
    if isinstance(value, Decimal):
        return str(value)
    if hasattr(value, "model_dump"):
        return _serialize_payload(value.model_dump(by_alias=True, exclude_none=False))
    if hasattr(value, "dict"):
        return _serialize_payload(value.dict())
    return value


def _runtime_boundary(value: Any) -> Any:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, Mapping):
        return {
            _runtime_boundary(key): _runtime_boundary(item)
            for key, item in sorted(value.items(), key=lambda item: str(item[0]))
        }
    if isinstance(value, tuple):
        return tuple(_runtime_boundary(item) for item in value)
    if isinstance(value, list):
        return [_runtime_boundary(item) for item in value]
    if hasattr(value, "model_dump"):
        return _runtime_boundary(value.model_dump(by_alias=True, exclude_none=False))
    if hasattr(value, "dict"):
        return _runtime_boundary(value.dict())
    return value


def _read_yaml_mapping(path: Path) -> Mapping[str, object]:
    import yaml

    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "controller_config: YAML must be a mapping",
        )
    return payload


def _read_yaml_mapping_bytes(data: bytes, label: str) -> Mapping[str, object]:
    import yaml
    try:
        payload = yaml.safe_load(data.decode("utf-8"))
    except (UnicodeDecodeError, yaml.YAMLError) as exc:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{label}: invalid YAML") from exc
    if not isinstance(payload, Mapping):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{label}: YAML must be a mapping")
    return payload


def load_reversal_controller_config(mapping: Mapping[str, object]) -> tuple[ChanReversalFollowerConfig, str]:
    if not isinstance(mapping, Mapping):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "controller_config: expected mapping")

    controller_name = mapping.get("controller_name")
    if not isinstance(controller_name, str) or controller_name != "chan_reversal_follower":
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"controller_name: expected chan_reversal_follower, got {controller_name!r}",
        )

    normalized = dict(mapping)
    normalized["id"] = "__placeholder_controller_id__"

    try:
        parsed = ChanReversalFollowerConfig.model_validate(normalized)
    except AttributeError:
        parsed = ChanReversalFollowerConfig.parse_obj(normalized)

    canonical = _serialize_payload(parsed)
    canonical.pop("id", None)
    controller_config_hash = sha256(
        json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()

    stable_id = "ctrl-" + controller_config_hash[:24]
    parsed = parsed.model_copy(update={"id": stable_id})

    return parsed, controller_config_hash


class HistoricalControllerRunner:
    def __init__(
        self,
        request,
        provider: ManifestBacktestingDataProvider,
        *,
        git_sha: str,
        request_hash: str,
        run_id: str,
    ) -> None:
        self._request = request
        self._provider = provider
        _ensure_sha_hash(git_sha, _HASH_40, "git_sha", "40 lowercase hex")
        _ensure_sha_hash(request_hash, _HASH_64, "request_hash", "64 lowercase hex")
        _ensure_sha_hash(run_id, _RUN_ID, "run_id", "hba- + 24 lowercase hex")
        if run_id != f"hba-{request_hash[:24]}":
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"run_id must match request_hash prefix: hba-{request_hash[:24]}",
            )
        self._git_sha = git_sha
        self._request_hash = request_hash
        self._run_id = run_id
        self._latest_controller_config: ChanReversalFollowerConfig | None = None
        self._executor_configs: dict[str, Any] = {}

    @property
    def _calendar(self) -> TradableCalendar:
        calendar = getattr(self._provider.engine, "_calendar", None)
        if not isinstance(calendar, TradableCalendar):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "engine calendar must be TradableCalendar",
            )
        return calendar

    @property
    def _controller_class(self):
        if self._latest_controller_config is not None:
            getter = getattr(self._latest_controller_config, "get_controller_class", None)
            if callable(getter):
                return getter()
        return ChanReversalFollowerController

    def _status_tuple(self, status: ExecutorStatus) -> tuple[RunnableStatus, bool, bool]:
        if status is ExecutorStatus.PENDING:
            return RunnableStatus.NOT_STARTED, True, False
        if status is ExecutorStatus.ACTIVE:
            return RunnableStatus.RUNNING, True, True
        if status is ExecutorStatus.CLOSED:
            return RunnableStatus.TERMINATED, False, False
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"unsupported executor status: {status!r}",
        )

    def _close_type(self, record) -> CloseType | None:
        if record.closed_trade is None:
            return None
        if record.closed_trade.exit_reason in {"controller", "signal"}:
            return CloseType.EARLY_STOP
        if record.closed_trade.exit_reason == "stop":
            return CloseType.STOP_LOSS
        if record.closed_trade.exit_reason == "expiry":
            return CloseType.TIME_LIMIT
        raise AuditedBacktestError(
            BlockingCode.UNSUPPORTED_EXECUTOR_SEMANTICS,
            f"unsupported close reason: {record.closed_trade.exit_reason!r}",
        )

    def _filled_amount_quote(self, record) -> Decimal:
        if record.status is ExecutorStatus.PENDING:
            return Decimal("0")
        if record.status is ExecutorStatus.ACTIVE:
            if record.position_state is None:
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "active record missing position_state")
            return (
                record.quantized_amount_base
                * record.position_state.entry_fill_price
            )
        if record.status is ExecutorStatus.CLOSED:
            if record.position_state is None or record.closed_trade is None:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    "closed record missing position_state or closed_trade",
                )
            return (
                record.quantized_amount_base * record.position_state.entry_fill_price
            ) + (
                record.quantized_amount_base * record.closed_trade.exit_price
            )
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"unsupported executor status: {record.status!r}")

    def _executor_infos(self, _event_time) -> tuple[ExecutorInfo, ...]:
        return tuple(
            info
            for record in sorted(
                self._provider.engine.records().values(),
                key=lambda item: item.intent.executor_id,
            )
            if (info := self._executor_info(record)) is not None
        )

    def _executor_info(self, record):
        if record.status not in {ExecutorStatus.PENDING, ExecutorStatus.ACTIVE, ExecutorStatus.CLOSED}:
            return None
        runnable_status, is_active, is_trading = self._status_tuple(record.status)
        config = self._executor_configs.get(record.intent.executor_id)
        if config is None:
            return None
        return ExecutorInfo(
            id=record.intent.executor_id,
            timestamp=record.intent.decision_time.timestamp(),
            type="position_executor",
            status=runnable_status,
            config=config,
            net_pnl_pct=Decimal("0") if record.reference_equity_quote is None else record.net_pnl_quote / record.reference_equity_quote,
            net_pnl_quote=record.net_pnl_quote,
            cum_fees_quote=record.fee_quote,
            filled_amount_quote=self._filled_amount_quote(record),
            is_active=is_active,
            is_trading=is_trading,
            custom_info={
                "side": TradeType.BUY,
                "audit": {
                    "slippage_quote": record.slippage_quote,
                    "funding_quote": record.funding_quote,
                },
            },
            close_timestamp=None if record.exit_time is None else record.exit_time.timestamp(),
            close_type=self._close_type(record),
            controller_id=record.intent.controller_id,
        )

    def _preflight_eligibility(self, controller_cfg: ChanReversalFollowerConfig) -> bool:
        if self._request.rule_policy.value == "pinned_snapshot":
            return False
        if self._provider.rules.rule_policy is not self._request.rule_policy:
            raise AuditedBacktestError(
                BlockingCode.TRADING_RULES_MISSING,
                "provider rule policy does not match historical request",
            )
        proof = self._provider.market_data.coverage_proof(
            self._request.start_time,
            self._request.end_time,
        )
        start = self._request.start_time.tz_convert("UTC")
        for symbol, timestamps in proof.items():
            pair = symbol.replace("_", "-").upper()
            for timestamp in timestamps:
                if timestamp <= start:
                    continue
                try:
                    self._provider.rules.rule_at(
                        controller_cfg.connector_name,
                        pair,
                        timestamp,
                    )
                except AuditedBacktestError as exc:
                    if exc.code is not BlockingCode.TRADING_RULES_MISSING:
                        raise
                    checked_at = (
                        timestamp.tz_convert("UTC")
                        .isoformat(timespec="nanoseconds")
                        .replace("+00:00", "Z")
                    )
                    raise AuditedBacktestError(
                        BlockingCode.TRADING_RULES_MISSING,
                        "historical trading rule coverage failed: "
                        f"connector_name={controller_cfg.connector_name!r}, "
                        f"trading_pair={pair!r}, timestamp={checked_at}",
                        context={
                            "connector_name": str(controller_cfg.connector_name),
                            "trading_pair": str(pair),
                            "timestamp": str(checked_at),
                        },
                    ) from exc
        return True

    async def run(self, controller_config: Mapping[str, object] | str | Path | ChanReversalFollowerConfig) -> RunnerOutput:
        if isinstance(controller_config, (str, Path)):
            raw_config = _read_yaml_mapping(Path(controller_config))
        elif isinstance(controller_config, Mapping):
            raw_config = dict(controller_config)
        elif isinstance(controller_config, ChanReversalFollowerConfig):
            raw_config = _serialize_payload(controller_config)
        else:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "controller_config: expected mapping or yaml path",
            )

        controller_cfg, controller_config_hash = load_reversal_controller_config(raw_config)
        self._latest_controller_config = controller_cfg
        self._executor_configs = {}

        decision_grade_eligible = self._preflight_eligibility(controller_cfg)

        controller = self._controller_class(
            controller_cfg,
            market_data_provider=self._provider,
            actions_queue=asyncio.Queue(),
        )

        decisions = decision_times(
            self._request.start_time,
            self._request.end_time,
            self._request.decision_resolution,
        )
        decision_set = frozenset(decisions)
        events = self._calendar.event_times(
            self._request.start_time,
            self._request.end_time,
            decisions,
        )

        action_sequence = 0
        action_trace: list[ActionTrace] = []
        local_rejections: list[Rejection] = []
        engine: AuditedPortfolioEngine = self._provider.engine

        for event_time in events:
            engine.advance_to(event_time)
            self._provider.update_historical_time(event_time)

            if event_time not in decision_set:
                continue

            controller.executors_info = self._executor_infos(event_time)
            await controller.update_processed_data()
            actions = controller.determine_executor_actions()

            gate_reason = controller.processed_data.get("gate_reason")
            if not actions and gate_reason not in (None, "ok"):
                local_rejections.append(
                    Rejection(
                        executor_id=controller_cfg.id,
                        timestamp=event_time,
                        code=RejectionCode.CONTROLLER_SUPPRESSED_ACTION,
                        details={"details": gate_reason},
                    )
                )

            for action in actions:
                normalized = normalize_action(
                    action,
                    event_time,
                    action_sequence,
                    self._calendar,
                    expected_controller_id=controller_cfg.id,
                    executor_pairs=MappingProxyType({
                        executor_id: record.intent.trading_pair
                        for executor_id, record in engine.records().items()
                    }),
                )
                action_sequence += 1

                if isinstance(normalized, NormalizedRejection):
                    action_trace.append(
                        ActionTrace(
                            action_sequence=action_sequence - 1,
                            decision_time=event_time,
                            action_type=normalized.action_type,
                            canonical_action_hash=normalized.canonical_action_hash,
                            executor_id=normalized.rejection.executor_id,
                            outcome=(
                                "cancelled"
                                if normalized.rejection.code is RejectionCode.CANCELLED_BEFORE_FILL
                                else "rejected"
                            ),
                            reason=normalized.rejection.code.value,
                        )
                    )
                    local_rejections.append(normalized.rejection)
                    continue

                action_trace.append(
                    ActionTrace(
                        action_sequence=normalized.intent.action_sequence,
                        decision_time=event_time,
                        action_type=(
                            "CreateExecutorAction"
                            if isinstance(normalized, NormalizedCreate)
                            else "StopExecutorAction"
                        ),
                        canonical_action_hash=normalized.canonical_action_hash,
                        executor_id=normalized.intent.executor_id,
                        outcome="accepted",
                        reason=None,
                    )
                )

                if isinstance(normalized, NormalizedCreate):
                    self._executor_configs[normalized.intent.executor_id] = (
                        normalized.executor_config.model_copy(deep=True)
                        if hasattr(normalized.executor_config, "model_copy")
                        else normalized.executor_config
                    )
                    engine.queue_create(normalized.intent)
                else:
                    engine.queue_stop(normalized.intent)

        sorted_records = tuple(
            sorted(
                engine.records().values(),
                key=lambda item: (
                    item.intent.decision_time,
                    item.intent.action_sequence,
                    item.intent.executor_id,
                ),
            )
        )
        if decision_grade_eligible and self._provider.engine.integrity:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "decision-grade run retains engine integrity limitations",
            )
        executor_infos = tuple(
            info for record in sorted_records if (info := self._executor_info(record)) is not None
        )

        rejections = tuple(
            sorted(
                [*local_rejections, *engine.rejections],
                key=lambda item: (item.timestamp, item.executor_id, item.code.value),
            )
        )

        return RunnerOutput(
            executors=tuple(_runtime_boundary(executor_info.to_dict()) for executor_info in executor_infos),
            processed_data=dict(controller.processed_data),
            records=sorted_records,
            position_held_timeseries=tuple(self._provider.engine.position_snapshots),
            action_trace=tuple(action_trace),
            order_trace=tuple(self._provider.engine.order_trace),
            data_read_trace=tuple(self._provider.read_trace),
            rejections=rejections,
            integrity=tuple(self._provider.engine.integrity),
            manifest=tuple(self._provider.manifest_records),
            initial_quote_equity=self._request.initial_quote_equity,
            rule_policy=self._request.rule_policy,
            parity_summary={
                **self._provider.engine.parity_summary(),
                "native_comparison": {
                    "authoritative": False,
                    "invoked": False,
                    "status": "NOT_COMPARABLE",
                    "reason": "NATIVE_POSITION_SIMULATOR_REQUIRES_ENTRY_PRICE_AND_CLOSE_COST_MODEL",
                },
            },
            request_hash=self._request_hash,
            run_id=self._run_id,
            git_sha=self._git_sha,
            controller_config_hash=controller_config_hash,
            trading_rules_hash=self._provider.rules.sha256,
            hummingbot_image_digest=self._request.hummingbot_image_digest,
            decision_grade_eligible=decision_grade_eligible,
        )


__all__ = [
    "load_reversal_controller_config",
    "HistoricalControllerRunner",
]
