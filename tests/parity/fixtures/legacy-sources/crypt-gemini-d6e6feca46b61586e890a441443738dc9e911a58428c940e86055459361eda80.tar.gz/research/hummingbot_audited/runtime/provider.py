from __future__ import annotations

from collections.abc import Mapping, Sequence
from decimal import Decimal
from math import isfinite
from pathlib import PurePosixPath
from types import MappingProxyType
from numbers import Real
import posixpath
import re

import pandas as pd

from hummingbot.connector.connector_base import ConnectorBase
from hummingbot.connector.trading_rule import TradingRule
from hummingbot.core.data_type.common import PriceType
from hummingbot.data_feed.candles_feed.candles_factory import CandlesFactory
from hummingbot.data_feed.candles_feed.data_types import CandlesConfig
from hummingbot.data_feed.market_data_provider import MarketDataProvider
from hummingbot.strategy_v2.backtesting.backtesting_data_provider import BacktestingDataProvider
from research.hummingbot_audited.contracts import (
    AuditedBacktestError,
    BlockingCode,
    DataReadTrace,
    as_utc,
)
from research.hummingbot_audited.market_data import HistoricalMarketData


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_KNOWN_INTERVALS = {"1h", "12h", "1d"}
_DT_COLUMNS = (
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "quote_asset_volume",
    "n_trades",
    "taker_buy_base_volume",
    "taker_buy_quote_volume",
)
_OPTIONAL_VOLUME_COLUMNS = (
    "volume",
    "quote_asset_volume",
    "n_trades",
    "taker_buy_base_volume",
    "taker_buy_quote_volume",
)


def _ensure_non_empty_text(value: object, name: str) -> str:
    if not isinstance(value, str):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected non-empty text")
    value = value.strip()
    if not value:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected non-empty text")
    return value


def _ensure_manifest_text(value: object, name: str) -> str:
    if not isinstance(value, str):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected non-empty text")
    if value != value.strip():
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected non-empty text")
    if not value:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected non-empty text")
    return value


def _ensure_positive_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected positive int")
    return value


def _ensure_strict_connector(value: object, name: str) -> str:
    return _ensure_non_empty_text(value, name)


def _ensure_strict_trading_pair(value: object, name: str) -> str:
    return _ensure_non_empty_text(value, name)


def _ensure_finite_decimal(value: object, name: str) -> Decimal:
    if isinstance(value, bool):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected finite decimal")
    if isinstance(value, int):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected decimal")
    if isinstance(value, float):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected decimal")
    if not isinstance(value, Decimal):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected decimal")
    if not value.is_finite():
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: expected finite decimal")
    return value


def _ensure_strict_decimal(value: object, name: str) -> Decimal:
    return _ensure_finite_decimal(value, name)


def _validate_manifest_records(records: Sequence[Mapping[str, object]]) -> tuple[Mapping[str, object], ...]:
    if not isinstance(records, Sequence) or isinstance(records, (str, bytes, bytearray)):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "manifest_records: expected sequence",
        )
    if len(records) == 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "manifest_records: expected non-empty sequence",
        )

    canonical_paths: dict[str, str] = {}
    validated: list[Mapping[str, object]] = []

    for index, record in enumerate(records):
        if not isinstance(record, Mapping):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}]: expected mapping",
            )

        raw_path = _ensure_manifest_text(record.get("path"), f"manifest_records[{index}].path")
        raw_sha256 = _ensure_manifest_text(record.get("sha256"), f"manifest_records[{index}].sha256")
        if "\\" in raw_path:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: must be normalized POSIX path",
            )

        if raw_path.startswith("./") or raw_path.endswith("/.") or raw_path.find("/./") != -1:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: must not include dot segments",
            )

        path_obj = PurePosixPath(raw_path)
        if path_obj.is_absolute():
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: must be relative",
            )
        if any(part in (".", "..") for part in path_obj.parts):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: must not include parent traversal or dot segments",
            )

        normalized_path = posixpath.normpath(raw_path)
        if normalized_path != raw_path:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: must be normalized",
            )
        if normalized_path in {".", ""}:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: must be relative path",
            )

        if normalized_path in canonical_paths:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].path: duplicate path alias",
            )

        if not _SHA256_RE.fullmatch(raw_sha256):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"manifest_records[{index}].sha256: must be lowercase sha-256 hex",
            )

        canonical_paths[normalized_path] = str(raw_sha256)
        validated.append(
            MappingProxyType(
                {
                    "path": normalized_path,
                    "sha256": str(raw_sha256),
                },
            )
        )

    return tuple(
        sorted(
            validated,
            key=lambda item: item["path"],
        )
    )


def _to_float_list(values: Sequence[object]) -> list[float]:
    out: list[float] = []
    for value in values:
        if pd.isna(value):
            out.append(0.0)
            continue
        try:
            out.append(float(value))
        except (TypeError, ValueError) as exc:
            raise AuditedBacktestError(BlockingCode.DATA_GAP, "invalid decimal in candle data") from exc
    return out


def _thaw(value):
    if isinstance(value, Mapping):
        return {key: _thaw(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw(item) for item in value]
    if isinstance(value, list):
        return [_thaw(item) for item in value]
    return value


def _interval_delta(interval: str) -> pd.Timedelta:
    if interval == "1h":
        return pd.Timedelta(hours=1)
    if interval == "12h":
        return pd.Timedelta(hours=12)
    if interval == "1d":
        return pd.Timedelta(days=1)
    raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"interval: unsupported {interval!r}")


def _coerce_utc_seconds(value: object, name: str) -> pd.Timestamp:
    if isinstance(value, bool):
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: timezone-aware timestamp required")
    if isinstance(value, Real):
        if not isfinite(value):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"{name}: timezone-aware timestamp required")
        return pd.to_datetime(value, unit="s", utc=True)
    return as_utc(value, name)


class ManifestBacktestingDataProvider(BacktestingDataProvider):
    def __init__(
        self,
        market_data,
        targets,
        rules,
        engine,
        manifest_records: Sequence[Mapping[str, object]],
        start_time,
        end_time,
    ) -> None:
        super().__init__(connectors={})

        self._market_data = market_data
        self._targets = targets
        self._rules = rules
        self._engine = engine

        self._request_start_time = as_utc(start_time, "start_time")
        self._request_end_time = as_utc(end_time, "end_time")
        if self._request_start_time >= self._request_end_time:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "start_time must be < end_time")

        self._active_start_time = self._request_start_time
        self._active_end_time = self._request_end_time
        self.start_time = self._active_start_time.timestamp()
        self.end_time = self._active_end_time.timestamp()

        self._historical_time: pd.Timestamp | None = None
        self._time: float | None = None

        self._read_trace: list[DataReadTrace] = []

        self._manifest_records = _validate_manifest_records(manifest_records)

        self.trading_rules: dict[str, dict[str, TradingRule]] = {}
        self.candles_feeds: dict[str, pd.DataFrame] = {}

        self._known_markets = frozenset(
            (
                _ensure_non_empty_text(snapshot.connector_name, "connector_name"),
                _ensure_non_empty_text(snapshot.trading_pair, "trading_pair"),
            )
            for snapshot in getattr(rules, "snapshots", ())
        )

    @property
    def rules(self):
        return self._rules

    @property
    def market_data(self) -> HistoricalMarketData:
        return self._market_data

    @property
    def engine(self):
        return self._engine

    @property
    def ready(self) -> bool:
        return self._historical_time is not None

    @property
    def manifest_records(self) -> tuple[Mapping[str, object], ...]:
        return tuple(self._manifest_records)

    @property
    def read_trace(self) -> tuple[DataReadTrace, ...]:
        return tuple(self._read_trace)

    def time(self) -> float:
        if self._time is None:
            raise AuditedBacktestError(
                BlockingCode.WALL_CLOCK_DEPENDENCY,
                "provider time: not initialized",
            )
        return self._time

    def _require_time(self) -> pd.Timestamp:
        if self._historical_time is None:
            raise AuditedBacktestError(
                BlockingCode.WALL_CLOCK_DEPENDENCY,
                "provider time: required",
            )
        return self._historical_time

    def _advance_historical_time(
        self,
        timestamp: pd.Timestamp,
        *,
        window_start: pd.Timestamp,
        window_end: pd.Timestamp,
    ) -> None:
        if timestamp < self._request_start_time or timestamp > self._request_end_time:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "timestamp: outside provider start/end bounds",
            )
        if timestamp < window_start or timestamp > window_end:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "timestamp: outside active backtesting window",
            )
        if self._historical_time is not None and timestamp < self._historical_time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "timestamp: cannot move backwards",
            )
        if self._historical_time is not None and timestamp > self._historical_time:
            self.trading_rules.clear()
            self.candles_feeds.clear()
        self._historical_time = timestamp
        self._time = timestamp.timestamp()

    def _propose_backtesting_bounds(
        self,
        start_time: object,
        end_time: object,
    ) -> tuple[pd.Timestamp, pd.Timestamp]:
        start_timestamp = _coerce_utc_seconds(start_time, "start_time")
        end_timestamp = _coerce_utc_seconds(end_time, "end_time")

        if not start_timestamp < end_timestamp:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "start_time: must be < end_time")
        if start_timestamp < self._request_start_time or end_timestamp > self._request_end_time:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "start_time/end_time: window must be within request bounds",
            )
        if self._historical_time is not None and start_timestamp < self._historical_time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "start_time: cannot move backwards",
            )
        return start_timestamp, end_timestamp

    def update_backtesting_time(self, start_time: object, end_time: object) -> None:
        start_timestamp, end_timestamp = self._propose_backtesting_bounds(start_time, end_time)
        self._advance_historical_time(
            start_timestamp,
            window_start=start_timestamp,
            window_end=end_timestamp,
        )
        self._active_start_time = start_timestamp
        self._active_end_time = end_timestamp
        self.start_time = start_timestamp.timestamp()
        self.end_time = end_timestamp.timestamp()

    def update_historical_time(self, timestamp: object) -> None:
        normalized = _coerce_utc_seconds(timestamp, "timestamp")
        self._advance_historical_time(
            normalized,
            window_start=self._active_start_time,
            window_end=self._active_end_time,
        )

    @staticmethod
    def _raise_audited_network_blocked(operation: str) -> None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{operation}: unavailable in manifest provider",
        )

    async def _raise_audited_network_blocked_async(self, operation: str) -> None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{operation}: unavailable in manifest provider",
        )

    def _append_read_trace(
        self,
        operation: str,
        resource: str,
        record_count: int,
        *,
        first_visible_at: pd.Timestamp | None = None,
        last_visible_at: pd.Timestamp | None = None,
        payload_hash: str | None = None,
    ) -> None:
        self._read_trace.append(
            DataReadTrace(
                event_time=self._require_time(),
                operation=operation,
                resource=resource,
                first_visible_at=first_visible_at,
                last_visible_at=last_visible_at,
                record_count=record_count,
                payload_hash=payload_hash,
            )
        )

    def _ensure_connector_name(self, value: object) -> str:
        return _ensure_strict_connector(value, "connector")

    def _ensure_trading_pair(self, value: object) -> str:
        return _ensure_strict_trading_pair(value, "trading_pair")

    def _validate_market(self, connector_name: object, trading_pair: object) -> tuple[str, str]:
        connector = self._ensure_connector_name(connector_name)
        trading_pair = self._ensure_trading_pair(trading_pair)
        if (connector, trading_pair) not in self._known_markets:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "market: unknown connector or trading pair")
        return connector, trading_pair

    def _validate_candles_config(self, config: CandlesConfig) -> tuple[str, str, str, int]:
        if not isinstance(config, CandlesConfig):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "config: expected CandlesConfig")
        connector, pair = self._validate_market(config.connector, config.trading_pair)
        interval = _ensure_non_empty_text(config.interval, "interval")
        if interval not in _KNOWN_INTERVALS:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"interval: unsupported {interval!r}")
        max_records = _ensure_positive_int(config.max_records, "config.max_records")
        return connector, pair, interval, max_records

    def _rule_selection(self, connector_name: object, trading_pair: object):
        connector, pair = self._validate_market(connector_name, trading_pair)
        return self._rules.rule_at(
            connector_name=connector,
            trading_pair=pair,
            timestamp=self._require_time(),
        )

    def _build_trading_rule(self, snapshot) -> TradingRule:
        return TradingRule(
            trading_pair=snapshot.trading_pair,
            min_order_size=Decimal(str(snapshot.min_order_size)),
            min_price_increment=Decimal(str(snapshot.min_price_increment)),
            min_base_amount_increment=Decimal(str(snapshot.min_base_amount_increment)),
            min_notional_size=Decimal(str(snapshot.min_notional_size)),
            min_order_value=Decimal(str(snapshot.min_notional_size)),
            supports_limit_orders=False,
            supports_market_orders=True,
        )

    def _build_candles_df(self, frame: pd.DataFrame, interval: str) -> pd.DataFrame:
        if frame.empty:
            return pd.DataFrame({column: pd.Series(dtype="float64") for column in _DT_COLUMNS}, columns=_DT_COLUMNS)

        expected = ("open", "high", "low", "close")
        for column in expected:
            if column not in frame.columns:
                raise AuditedBacktestError(BlockingCode.DATA_GAP, f"completed_candles: missing {column}")

        index = [ts.tz_convert("UTC").timestamp() for ts in frame.index]

        rows: dict[str, list[float]] = {
            "timestamp": index,
            "open": _to_float_list(frame["open"].tolist()),
            "high": _to_float_list(frame["high"].tolist()),
            "low": _to_float_list(frame["low"].tolist()),
            "close": _to_float_list(frame["close"].tolist()),
        }
        for column in _OPTIONAL_VOLUME_COLUMNS:
            if column in frame.columns:
                rows[column] = _to_float_list(frame[column].tolist())
            else:
                rows[column] = [0.0] * len(frame)

        return pd.DataFrame(rows, columns=_DT_COLUMNS, dtype="float64")

    def _generate_candle_feed_key(self, config: CandlesConfig) -> str:
        connector, pair, interval, _ = self._validate_candles_config(config)
        return f"{connector}_{pair}_{interval}"

    def _load_or_refresh_candles_feed(self, config: CandlesConfig) -> pd.DataFrame:
        connector, pair, interval, max_records = self._validate_candles_config(config)
        key = self._generate_candle_feed_key(config)
        frame = self._market_data.completed_candles(
            trading_pair=pair,
            interval=interval,
            now=self._require_time(),
            max_records=max_records,
        )
        if not isinstance(frame, pd.DataFrame):
            raise AuditedBacktestError(BlockingCode.DATA_GAP, "completed_candles: unavailable")
        candles = self._build_candles_df(frame, interval)
        self.candles_feeds[key] = candles
        return candles

    def initialize_candles_feed_list(self, config_list: Sequence[object]) -> None:
        for config in config_list:
            if not isinstance(config, CandlesConfig):
                raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "config_list: expected CandlesConfig sequence")
            self._load_or_refresh_candles_feed(config)

    async def initialize_trading_rules(self, connector_name: str) -> None:
        _ = self._ensure_connector_name(connector_name)
        _ = self._require_time()
        if not any(connector == connector_name for connector, _ in self._known_markets):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "connector: unknown connector")

        next_rules: dict[str, TradingRule] = {}
        pairs = sorted(pair for conn, pair in self._known_markets if conn == connector_name)
        for pair in pairs:
            try:
                selection = self._rule_selection(connector_name, pair)
            except AuditedBacktestError as exc:
                if exc.code is BlockingCode.TRADING_RULES_MISSING:
                    self.trading_rules.pop(connector_name, None)
                raise
            trading_rule = self._build_trading_rule(selection.rule)
            next_rules[pair] = trading_rule
        self.trading_rules[connector_name] = next_rules

    async def initialize_candles_feed(self, config: CandlesConfig) -> None:
        self._load_or_refresh_candles_feed(config)

    async def get_candles_feed(self, config: CandlesConfig) -> pd.DataFrame:
        return self._load_or_refresh_candles_feed(config).copy()

    def get_candles_df(
        self,
        connector_name: str,
        trading_pair: str,
        interval: str,
        max_records: int = 500,
    ) -> pd.DataFrame:
        connector, pair = self._validate_market(connector_name, trading_pair)
        max_records = _ensure_positive_int(max_records, "max_records")
        if interval not in _KNOWN_INTERVALS:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, f"interval: unsupported {interval!r}")

        now = self._require_time()
        frame = self._market_data.completed_candles(
            trading_pair=pair,
            interval=interval,
            now=now,
            max_records=max_records,
        )
        if not isinstance(frame, pd.DataFrame):
            raise AuditedBacktestError(BlockingCode.DATA_GAP, "completed_candles: unavailable")

        candles = self._build_candles_df(frame, interval)
        if candles.empty:
            first_visible = None
            last_visible = None
        else:
            closed_start = frame.index + _interval_delta(interval)
            first_visible = closed_start[0]
            last_visible = closed_start[-1]

        self._append_read_trace(
            operation="get_candles_df",
            resource=f"candles:{connector}:{pair}:{interval}",
            record_count=len(candles),
            first_visible_at=first_visible,
            last_visible_at=last_visible,
            payload_hash=None,
        )
        return candles

    def get_price_by_type(
        self,
        connector_name: str,
        trading_pair: str,
        price_type: PriceType,
    ) -> Decimal:
        connector, pair = self._validate_market(connector_name, trading_pair)
        now = self._require_time()
        completed = self._market_data.completed_candles(
            trading_pair=pair,
            interval="1h",
            now=now,
            max_records=1,
        )
        if not isinstance(completed, pd.DataFrame):
            raise AuditedBacktestError(BlockingCode.DATA_GAP, "completed_candles: unavailable")

        if completed.empty:
            self._append_read_trace(
                operation="get_price_by_type",
                resource=f"price:{connector}:{pair}:{price_type.name if hasattr(price_type, 'name') else str(price_type)}",
                record_count=0,
                first_visible_at=None,
                last_visible_at=None,
                payload_hash=None,
            )
            raise AuditedBacktestError(
                BlockingCode.DATA_GAP,
                "no completed candle for price lookup",
            )

        close_time = completed.index[-1] + pd.Timedelta(hours=1)
        price = Decimal(str(completed.iloc[-1]["close"]))
        if not price.is_finite():
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "price: expected finite decimal")

        self._append_read_trace(
            operation="get_price_by_type",
            resource=f"price:{connector}:{pair}:{price_type.name if hasattr(price_type, 'name') else str(price_type)}",
            record_count=1,
            first_visible_at=close_time,
            last_visible_at=close_time,
            payload_hash=None,
        )
        return price

    def get_balance(self, connector_name: str, asset: str) -> Decimal:
        connector = self._ensure_connector_name(connector_name)
        requested_asset = _ensure_non_empty_text(asset, "asset")
        known_connectors = {connector_name for connector_name, _ in self._known_markets}

        if requested_asset != "USDT":
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "asset: only USDT supported")
        if connector not in known_connectors:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "connector: unknown connector")

        now = self._require_time()
        balance = self._engine.equity_quote_at(now)
        if not isinstance(balance, Decimal):
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "balance: expected decimal")
        balance = _ensure_strict_decimal(balance, "balance")

        self._append_read_trace(
            operation="get_balance",
            resource=f"balance:{connector}:{requested_asset}",
            record_count=1,
            first_visible_at=None,
            last_visible_at=None,
            payload_hash=None,
        )
        return balance

    def get_target_snapshot(self, _path: str) -> dict[str, object]:
        now = self._require_time()
        selected = self._targets.at(now)
        if selected is None:
            payload = {"written_ts": "0", "legs": []}
            self._append_read_trace(
                operation="get_target_snapshot",
                resource="targets:historical",
                record_count=0,
                first_visible_at=None,
                last_visible_at=None,
                payload_hash=None,
            )
            return payload

        payload = _thaw(selected.payload)
        visible_at = selected.effective_at
        self._append_read_trace(
            operation="get_target_snapshot",
            resource="targets:historical",
            record_count=1,
            first_visible_at=visible_at,
            last_visible_at=visible_at,
            payload_hash=getattr(selected, "payload_sha256", None),
        )
        return payload

    def get_trading_rules(self, connector_name: str, trading_pair: str) -> TradingRule:
        selection = self._rule_selection(connector_name, trading_pair)
        snapshot = selection.rule
        trading_rule = self._build_trading_rule(snapshot)

        connector_rules = self.trading_rules.setdefault(snapshot.connector_name, {})
        connector_rules[snapshot.trading_pair] = trading_rule

        self._append_read_trace(
            operation="get_trading_rules",
            resource=(
                f"rules:{snapshot.connector_name}:{snapshot.trading_pair}:{snapshot.effective_from.isoformat()}:{snapshot.effective_to.isoformat()}:"
                f"{self._rules.sha256}"
            ),
            record_count=1,
            first_visible_at=None,
            last_visible_at=None,
            payload_hash=self._rules.sha256,
        )
        return trading_rule

    def get_rate(self, pair: str) -> Decimal:
        self._raise_audited_network_blocked("get_rate")

    async def get_historical_candles_df(
        self,
        connector_name: str,
        trading_pair: str,
        interval: str,
        start_time: int | None = None,
        end_time: int | None = None,
        max_records: int | None = None,
        max_cache_records: int = 10000,
    ) -> pd.DataFrame:
        await self._raise_audited_network_blocked_async("get_historical_candles_df")

    def get_order_book(self, *_args: object, **_kwargs: object) -> object:
        self._raise_audited_network_blocked("get_order_book")

    @staticmethod
    def get_connector_config_map(connector_name: str) -> Mapping[str, object]:
        _ = _ensure_non_empty_text(connector_name, "connector_name")
        raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "get_connector_config_map: unavailable in manifest provider")

    def get_funding_info(self, *_args: object, **_kwargs: object) -> object:
        self._raise_audited_network_blocked("get_funding_info")

    def get_trading_pairs(self, *_args: object, **_kwargs: object) -> list[str]:
        self._raise_audited_network_blocked("get_trading_pairs")

    async def update_rates_task(self, *_args: object, **_kwargs: object) -> None:
        await self._raise_audited_network_blocked_async("update_rates_task")

    async def initialize_order_books(self, *_args: object, **_kwargs: object) -> None:
        await self._raise_audited_network_blocked_async("initialize_order_books")

    async def remove_order_books(self, *_args: object, **_kwargs: object) -> None:
        await self._raise_audited_network_blocked_async("remove_order_books")

    async def _safe_get_last_traded_prices(self, *_args: object, **_kwargs: object) -> object:
        await self._raise_audited_network_blocked_async("_safe_get_last_traded_prices")

    async def _safe_get_last_traded_price(self, *_args: object, **_kwargs: object) -> Decimal:
        await self._raise_audited_network_blocked_async("_safe_get_last_traded_price")

    def quantize_order_amount(
        self,
        connector_name: str,
        trading_pair: str,
        amount: object,
    ) -> Decimal:
        connector, pair = self._ensure_connector_name(connector_name), self._ensure_trading_pair(trading_pair)
        selection = self._rule_selection(connector, pair)
        trading_rule = self._build_trading_rule(selection.rule)
        raw_amount = _ensure_strict_decimal(amount, "amount")
        if raw_amount < 0:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "amount: expected non-negative decimal")
        step = trading_rule.min_base_amount_increment
        quantized = (raw_amount // step) * step

        snapshot = selection.rule
        self._append_read_trace(
            operation="quantize_order_amount",
            resource=(
                f"quantize_amount:{connector}:{pair}:{snapshot.effective_from.isoformat()}:{snapshot.effective_to.isoformat()}:"
                f"{self._rules.sha256}"
            ),
            record_count=1,
            first_visible_at=None,
            last_visible_at=None,
            payload_hash=self._rules.sha256,
        )
        return quantized

    def quantize_order_price(
        self,
        connector_name: str,
        trading_pair: str,
        price: object,
    ) -> Decimal:
        connector, pair = self._ensure_connector_name(connector_name), self._ensure_trading_pair(trading_pair)
        selection = self._rule_selection(connector, pair)
        trading_rule = self._build_trading_rule(selection.rule)
        raw_price = _ensure_strict_decimal(price, "price")
        if raw_price < 0:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "price: expected non-negative decimal")
        step = trading_rule.min_price_increment
        quantized = (raw_price // step) * step

        snapshot = selection.rule
        self._append_read_trace(
            operation="quantize_order_price",
            resource=(
                f"quantize_price:{connector}:{pair}:{snapshot.effective_from.isoformat()}:{snapshot.effective_to.isoformat()}:"
                f"{self._rules.sha256}"
            ),
            record_count=1,
            first_visible_at=None,
            last_visible_at=None,
            payload_hash=self._rules.sha256,
        )
        return quantized

    def get_connector(self, *_args: object, **_kwargs: object) -> object:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "Connector access is disabled for manifest provider",
        )

    def get_connector_with_fallback(self, *_args: object, **_kwargs: object) -> object:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "Connector access is disabled for manifest provider",
        )

    def get_non_trading_connector(self, *_args: object, **_kwargs: object) -> object:
        self._raise_audited_network_blocked("get_non_trading_connector")

    async def _ensure_non_trading_connector_started(
        self,
        connector: ConnectorBase,
        connector_name: str,
        trading_pair: str,
    ) -> bool:
        await self._raise_audited_network_blocked_async("_ensure_non_trading_connector_started")

    async def _wait_for_order_book_initialized(
        self,
        connector: ConnectorBase,
        trading_pair: str,
        timeout: float = 30.0,
    ) -> bool:
        await self._raise_audited_network_blocked_async("_wait_for_order_book_initialized")

    def _create_non_trading_connector(self, *_args: object, **_kwargs: object) -> object:
        self._raise_audited_network_blocked("create_non_trading_connector")

    def initialize_rate_sources(self, *_args: object, **_kwargs: object) -> None:
        self._raise_audited_network_blocked("initialize_rate_sources")

    def get_available_balance(self, *_args: object, **_kwargs: object) -> Decimal:
        self._raise_audited_network_blocked("get_available_balance")

    def stop(self) -> None:
        task = getattr(self, "_rates_update_task", None)
        if task is not None and hasattr(task, "cancel"):
            task.cancel()
        self._rates_update_task = None
        self.trading_rules.clear()
        self.candles_feeds.clear()
        self._rates.clear()
        self._rates_required.clear()
        self._non_trading_connectors.clear()
        self._non_trading_connectors_started.clear()
        self.connectors.clear()

    def stop_candle_feed(
        self,
        config: CandlesConfig,
    ) -> None:
        self.candles_feeds.pop(self._generate_candle_feed_key(config), None)


__all__ = [
    "ManifestBacktestingDataProvider",
    "BacktestingDataProvider",
    "MarketDataProvider",
    "CandlesFactory",
]
