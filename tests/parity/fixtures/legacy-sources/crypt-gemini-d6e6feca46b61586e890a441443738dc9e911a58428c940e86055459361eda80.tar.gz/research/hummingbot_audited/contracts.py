from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from decimal import InvalidOperation
from enum import Enum
import re
from pathlib import Path
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Literal, Mapping, Sequence

import pandas as pd

from research.blend_v2.types import IntegrityError


_DECIMAL_RE = r"^[0-9a-f]{64}$"
_SHA_RE = r"^sha256:[0-9a-f]{64}$"
_RUN_ID_RE = r"^hba-[0-9a-f]{24}$"


class BlockingCode(str, Enum):
    INVALID_REQUEST = "INVALID_REQUEST"
    DATA_GAP = "DATA_GAP"
    FUNDING_GAP = "FUNDING_GAP"
    TRADING_RULES_MISSING = "TRADING_RULES_MISSING"
    EXIT_DUST_UNCLOSEABLE = "EXIT_DUST_UNCLOSEABLE"
    NON_CAUSAL_TIMESTAMP = "NON_CAUSAL_TIMESTAMP"
    WALL_CLOCK_DEPENDENCY = "WALL_CLOCK_DEPENDENCY"
    UNSUPPORTED_EXECUTOR_TYPE = "UNSUPPORTED_EXECUTOR_TYPE"
    UNSUPPORTED_EXECUTOR_SEMANTICS = "UNSUPPORTED_EXECUTOR_SEMANTICS"
    LOSSY_ACTION_MAPPING = "LOSSY_ACTION_MAPPING"
    DUPLICATE_EXECUTOR_ID = "DUPLICATE_EXECUTOR_ID"
    UNKNOWN_STOP_TARGET = "UNKNOWN_STOP_TARGET"
    LEDGER_RECONCILIATION_FAILED = "LEDGER_RECONCILIATION_FAILED"
    NONDETERMINISTIC_REPLAY = "NONDETERMINISTIC_REPLAY"
    CONTAINER_DIGEST_MISMATCH = "CONTAINER_DIGEST_MISMATCH"


class RejectionCode(str, Enum):
    REJECTED_MIN_ORDER_SIZE = "REJECTED_MIN_ORDER_SIZE"
    REJECTED_MIN_NOTIONAL = "REJECTED_MIN_NOTIONAL"
    REJECTED_QUANTIZED_TO_ZERO = "REJECTED_QUANTIZED_TO_ZERO"
    REJECTED_INSUFFICIENT_BALANCE = "REJECTED_INSUFFICIENT_BALANCE"
    REJECTED_GROSS_CAP = "REJECTED_GROSS_CAP"
    REJECTED_MAX_LEGS = "REJECTED_MAX_LEGS"
    CANCELLED_BEFORE_FILL = "CANCELLED_BEFORE_FILL"
    CONTROLLER_SUPPRESSED_ACTION = "CONTROLLER_SUPPRESSED_ACTION"
    IDEMPOTENT_DUPLICATE_STOP = "IDEMPOTENT_DUPLICATE_STOP"


class RulePolicy(str, Enum):
    HISTORICAL_EXACT = "historical_exact"
    PINNED_SNAPSHOT = "pinned_snapshot"


def _ensure_mapping(value: Mapping[str, Any], name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected mapping",
        )
    return value


def _ensure_non_empty_text(value: str, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be non-empty string",
        )
    return value


def _ensure_non_negative_int(
    value: int,
    name: str,
    *,
    allow_zero: bool = False,
) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected integer",
        )
    if (allow_zero and value < 0) or (not allow_zero and value <= 0):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected positive value",
        )
    return int(value)


def _ensure_positive_decimal(value: Decimal, name: str) -> Decimal:
    if value <= 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected positive decimal",
        )
    return value


def _ensure_finite_decimal(value: Decimal, name: str) -> Decimal:
    if not value.is_finite():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be finite decimal",
        )
    return value


def _ensure_count(value: int, name: str) -> int:
    return _ensure_non_negative_int(value, name, allow_zero=True)


def _ensure_hash64(value: str, name: str) -> str:
    text = _ensure_non_empty_text(value, name)
    if re.fullmatch(_DECIMAL_RE, text) is None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be 64 lowercase hex",
        )
    return text


def _ensure_sha256_image(value: str, name: str) -> str:
    text = _ensure_non_empty_text(value, name)
    if re.fullmatch(_SHA_RE, text) is None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be sha256:<64 lowercase hex>",
        )
    return text


def _ensure_run_id(value: str, name: str) -> str:
    text = _ensure_non_empty_text(value, name)
    if re.fullmatch(_RUN_ID_RE, text) is None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be hba-[0-9a-f]{{24}}",
        )
    return text


def as_decimal(raw_value: object, name: str) -> Decimal:
    if isinstance(raw_value, bool):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: Decimal string required; bool is not allowed",
        )
    if isinstance(raw_value, int):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: Decimal string required",
        )
    if isinstance(raw_value, float):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: Decimal string required",
        )
    if isinstance(raw_value, Decimal):
        value = raw_value
    elif isinstance(raw_value, str):
        try:
            value = Decimal(raw_value)
        except InvalidOperation as exc:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"{name}: Decimal string required",
            ) from exc
    else:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: Decimal string required",
        )
    if not value.is_finite():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: Decimal string required",
        )
    return value


def as_utc(value: pd.Timestamp | str, name: str) -> pd.Timestamp:
    try:
        timestamp = pd.Timestamp(value)
    except (TypeError, ValueError) as exc:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: timezone-aware timestamp required",
        ) from exc

    if timestamp.tzinfo is None:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: timezone-aware timestamp required",
        )
    return timestamp.tz_convert("UTC")


def _serialize_mapping(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {
            key: _serialize_mapping(item)
            for key, item in sorted(value.items(), key=lambda item: str(item[0]))
        }
    if isinstance(value, pd.Timestamp):
        return _timestamp_to_string(value)
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_serialize_mapping(item) for item in value]
    return value


def _timestamp_to_string(timestamp: pd.Timestamp) -> str:
    return as_utc(timestamp, "timestamp").isoformat(timespec="nanoseconds").replace(
        "+00:00",
        "Z",
    )


def _snapshot_mapping(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType(
            {
                key: _snapshot_mapping(item)
                for key, item in value.items()
            }
        )
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return tuple(_snapshot_mapping(item) for item in value)
    return value


def _resolve_alias(path: Path, aliases: Mapping[str, str] | None) -> str:
    if not aliases:
        return str(path)
    try:
        normalized_aliases = {
            str(Path(k).resolve(strict=False)): alias for k, alias in aliases.items()
        }
        return normalized_aliases.get(str(path.resolve(strict=False)), str(path))
    except TypeError:
        return str(path)


def _validate_rule_policy(raw_policy: str) -> RulePolicy:
    try:
        return RulePolicy(raw_policy)
    except ValueError as exc:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"rule_policy: unsupported value {raw_policy!r}",
        ) from exc


def _validate_optional_decimal(value: object, name: str) -> Decimal | None:
    if value is None:
        return None
    value = as_decimal(value, name)
    _ensure_finite_decimal(value, name)
    if value < 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected non-negative decimal",
        )
    return value


def _validate_mappings(value: Mapping[str, str], name: str) -> MappingProxyType:
    return MappingProxyType(dict(value))


@dataclass
class AuditedBacktestError(IntegrityError):
    code: BlockingCode | RejectionCode
    message: str
    context: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.context = _validate_mappings(self.context, "context")
        self.args = (self.message,)


@dataclass(frozen=True)
class AuditedPositionIntent:
    executor_id: str
    controller_id: str
    decision_time: pd.Timestamp
    eligible_execution_time: pd.Timestamp
    connector_name: str
    trading_pair: str
    side: Literal["BUY"]
    requested_amount_base: Decimal
    leverage: int
    stop_fraction: Decimal | None
    deadline: pd.Timestamp | None
    canonical_config_hash: str
    action_sequence: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "executor_id", _ensure_non_empty_text(self.executor_id, "executor_id"))
        object.__setattr__(self, "controller_id", _ensure_non_empty_text(self.controller_id, "controller_id"))
        object.__setattr__(self, "connector_name", _ensure_non_empty_text(self.connector_name, "connector_name"))
        object.__setattr__(self, "trading_pair", _ensure_non_empty_text(self.trading_pair, "trading_pair"))
        if self.side != "BUY":
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "side: must be BUY",
            )
        object.__setattr__(self, "requested_amount_base", _ensure_finite_decimal(as_decimal(self.requested_amount_base, "requested_amount_base"), "requested_amount_base"))
        object.__setattr__(self, "requested_amount_base", _ensure_positive_decimal(self.requested_amount_base, "requested_amount_base"))
        object.__setattr__(self, "decision_time", as_utc(self.decision_time, "decision_time"))
        object.__setattr__(self, "eligible_execution_time", as_utc(self.eligible_execution_time, "eligible_execution_time"))
        if self.eligible_execution_time <= self.decision_time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "eligible_execution_time: must be strictly after decision_time",
            )
        object.__setattr__(self, "leverage", _ensure_non_negative_int(self.leverage, "leverage", allow_zero=False))
        stop_fraction = _validate_optional_decimal(self.stop_fraction, "stop_fraction")
        if stop_fraction is not None:
            if not (Decimal(0) < stop_fraction < Decimal(1)):
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    "stop_fraction: must be strictly between 0 and 1",
                )
        object.__setattr__(self, "stop_fraction", stop_fraction)
        deadline = None if self.deadline is None else as_utc(self.deadline, "deadline")
        if deadline is not None and deadline <= self.decision_time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "deadline: must be after decision_time",
            )
        object.__setattr__(self, "deadline", deadline)
        object.__setattr__(self, "canonical_config_hash", _ensure_hash64(self.canonical_config_hash, "canonical_config_hash"))
        object.__setattr__(self, "action_sequence", _ensure_count(self.action_sequence, "action_sequence"))


@dataclass(frozen=True)
class AuditedStopIntent:
    executor_id: str
    controller_id: str
    decision_time: pd.Timestamp
    eligible_execution_time: pd.Timestamp | None
    action_sequence: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "executor_id", _ensure_non_empty_text(self.executor_id, "executor_id"))
        object.__setattr__(self, "controller_id", _ensure_non_empty_text(self.controller_id, "controller_id"))
        object.__setattr__(self, "decision_time", as_utc(self.decision_time, "decision_time"))
        eligible_time = None if self.eligible_execution_time is None else as_utc(self.eligible_execution_time, "eligible_execution_time")
        if eligible_time is not None and eligible_time <= self.decision_time:
            raise AuditedBacktestError(
                BlockingCode.NON_CAUSAL_TIMESTAMP,
                "eligible_execution_time: must be strictly after decision_time",
            )
        object.__setattr__(self, "eligible_execution_time", eligible_time)
        object.__setattr__(self, "action_sequence", _ensure_count(self.action_sequence, "action_sequence"))


@dataclass(frozen=True)
class Rejection:
    executor_id: str
    timestamp: pd.Timestamp
    code: RejectionCode
    details: Mapping[str, str]

    def __post_init__(self) -> None:
        object.__setattr__(self, "executor_id", _ensure_non_empty_text(self.executor_id, "executor_id"))
        object.__setattr__(self, "timestamp", as_utc(self.timestamp, "timestamp"))
        if not isinstance(self.code, RejectionCode):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "code: must be RejectionCode",
            )
        object.__setattr__(self, "details", _validate_mappings(self.details, "details"))


@dataclass(frozen=True)
class ActionTrace:
    action_sequence: int
    decision_time: pd.Timestamp
    action_type: str
    canonical_action_hash: str
    executor_id: str
    outcome: str
    reason: str | None

    def __post_init__(self) -> None:
        object.__setattr__(self, "action_sequence", _ensure_count(self.action_sequence, "action_sequence"))
        object.__setattr__(self, "decision_time", as_utc(self.decision_time, "decision_time"))
        object.__setattr__(self, "action_type", _ensure_non_empty_text(self.action_type, "action_type"))
        object.__setattr__(self, "canonical_action_hash", _ensure_hash64(self.canonical_action_hash, "canonical_action_hash"))
        object.__setattr__(self, "executor_id", _ensure_non_empty_text(self.executor_id, "executor_id"))
        object.__setattr__(self, "outcome", _ensure_non_empty_text(self.outcome, "outcome"))
        if self.reason is not None:
            object.__setattr__(self, "reason", str(self.reason))


@dataclass(frozen=True)
class OrderTrace:
    executor_id: str
    timestamp: pd.Timestamp
    event: str
    amount_base: Decimal | None
    reference_price: Decimal | None
    details: Mapping[str, str]

    def __post_init__(self) -> None:
        object.__setattr__(self, "executor_id", _ensure_non_empty_text(self.executor_id, "executor_id"))
        object.__setattr__(self, "timestamp", as_utc(self.timestamp, "timestamp"))
        object.__setattr__(self, "event", _ensure_non_empty_text(self.event, "event"))
        amount = _validate_optional_decimal(self.amount_base, "amount_base")
        reference_price = _validate_optional_decimal(self.reference_price, "reference_price")
        object.__setattr__(self, "amount_base", amount)
        object.__setattr__(self, "reference_price", reference_price)
        object.__setattr__(self, "details", _validate_mappings(self.details, "details"))


@dataclass(frozen=True)
class DataReadTrace:
    event_time: pd.Timestamp
    operation: str
    resource: str
    first_visible_at: pd.Timestamp | None
    last_visible_at: pd.Timestamp | None
    record_count: int
    payload_hash: str | None

    def __post_init__(self) -> None:
        object.__setattr__(self, "event_time", as_utc(self.event_time, "event_time"))
        object.__setattr__(self, "operation", _ensure_non_empty_text(self.operation, "operation"))
        object.__setattr__(self, "resource", _ensure_non_empty_text(self.resource, "resource"))
        first_visible_at = None if self.first_visible_at is None else as_utc(self.first_visible_at, "first_visible_at")
        last_visible_at = None if self.last_visible_at is None else as_utc(self.last_visible_at, "last_visible_at")
        if first_visible_at is not None and first_visible_at > self.event_time:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "first_visible_at: must be no later than event_time",
            )
        if last_visible_at is not None and last_visible_at > self.event_time:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "last_visible_at: must be no later than event_time",
            )
        if first_visible_at is not None and last_visible_at is not None and first_visible_at > last_visible_at:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "first_visible_at: must be <= last_visible_at",
            )
        object.__setattr__(self, "first_visible_at", first_visible_at)
        object.__setattr__(self, "last_visible_at", last_visible_at)
        object.__setattr__(self, "record_count", _ensure_count(self.record_count, "record_count"))
        if self.payload_hash is not None:
            value = _ensure_non_empty_text(self.payload_hash, "payload_hash")
            if __import__("re").fullmatch(_DECIMAL_RE, value) is None:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    "payload_hash: must be lowercase sha-256 hash",
                )
            object.__setattr__(self, "payload_hash", value)


if TYPE_CHECKING:
    from .engine import ExecutorRecord


@dataclass(frozen=True)
class RunnerOutput:
    executors: tuple[Mapping[str, object], ...]
    processed_data: Mapping[str, object]
    records: tuple["ExecutorRecord", ...]
    position_held_timeseries: tuple[Mapping[str, object], ...]
    action_trace: tuple[ActionTrace, ...]
    order_trace: tuple[OrderTrace, ...]
    data_read_trace: tuple[DataReadTrace, ...]
    rejections: tuple[Rejection, ...]
    integrity: tuple[Mapping[str, str], ...]
    manifest: tuple[Mapping[str, str], ...]
    initial_quote_equity: Decimal
    rule_policy: RulePolicy
    parity_summary: Mapping[str, object]
    request_hash: str
    run_id: str
    git_sha: str
    controller_config_hash: str
    trading_rules_hash: str
    hummingbot_image_digest: str
    decision_grade_eligible: bool

    def __post_init__(self) -> None:
        object.__setattr__(self, "executors", tuple(self.executors))
        object.__setattr__(self, "position_held_timeseries", tuple(self.position_held_timeseries))
        object.__setattr__(self, "action_trace", tuple(self.action_trace))
        object.__setattr__(self, "order_trace", tuple(self.order_trace))
        object.__setattr__(self, "data_read_trace", tuple(self.data_read_trace))
        object.__setattr__(self, "rejections", tuple(self.rejections))
        object.__setattr__(self, "integrity", tuple(self.integrity))
        object.__setattr__(self, "manifest", tuple(self.manifest))
        object.__setattr__(self, "records", tuple(self.records))
        if type(self.decision_grade_eligible) is not bool:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "decision_grade_eligible: expected bool")
        if self.decision_grade_eligible and self.integrity:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "decision-grade output cannot retain integrity limitations",
            )
        object.__setattr__(self, "initial_quote_equity", _ensure_positive_decimal(as_decimal(self.initial_quote_equity, "initial_quote_equity"), "initial_quote_equity"))
        if not isinstance(self.rule_policy, RulePolicy):
            object.__setattr__(self, "rule_policy", RulePolicy(self.rule_policy))
        if self.rule_policy is RulePolicy.PINNED_SNAPSHOT and self.decision_grade_eligible:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "pinned_snapshot cannot be decision-grade")
        if self.rule_policy is RulePolicy.HISTORICAL_EXACT and not self.decision_grade_eligible:
            raise AuditedBacktestError(BlockingCode.INVALID_REQUEST, "historical_exact requires decision-grade eligibility")
        object.__setattr__(self, "request_hash", _ensure_hash64(self.request_hash, "request_hash"))
        object.__setattr__(self, "run_id", _ensure_run_id(self.run_id, "run_id"))
        object.__setattr__(self, "controller_config_hash", _ensure_hash64(self.controller_config_hash, "controller_config_hash"))
        object.__setattr__(self, "trading_rules_hash", _ensure_hash64(self.trading_rules_hash, "trading_rules_hash"))
        object.__setattr__(self, "hummingbot_image_digest", _ensure_sha256_image(self.hummingbot_image_digest, "hummingbot_image_digest"))


@dataclass(frozen=True)
class BacktestRequest:
    controller_config: Path | Mapping[str, object]
    start_time: pd.Timestamp
    end_time: pd.Timestamp
    decision_resolution: Literal["1h", "12h", "1d"]
    market_manifest_path: Path
    target_snapshots_path: Path | None
    trading_rules_path: Path
    initial_quote_equity: Decimal
    fee_rate: Decimal
    slippage_rate: Decimal
    max_gross: Decimal
    max_legs: int
    seed: int
    hummingbot_image_digest: str
    rule_policy: RulePolicy

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, object]) -> "BacktestRequest":
        values = dict(mapping)
        required = {
            "controller_config",
            "start_time",
            "end_time",
            "decision_resolution",
            "market_manifest_path",
            "trading_rules_path",
            "initial_quote_equity",
            "fee_rate",
            "slippage_rate",
            "max_gross",
            "max_legs",
            "seed",
            "hummingbot_image_digest",
            "rule_policy",
        }
        for missing in required - values.keys():
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"Missing required field: {missing}",
            )

        controller_config = values["controller_config"]
        if isinstance(controller_config, str):
            controller_config_path = Path(controller_config)
        elif isinstance(controller_config, Mapping):
            controller_config_path = _snapshot_mapping(
                _ensure_mapping(controller_config, "controller_config")
            )
        else:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "controller_config: expected path string or mapping",
            )

        start_time = as_utc(values["start_time"], "start_time")
        end_time = as_utc(values["end_time"], "end_time")
        if end_time <= start_time:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "end_time: must be after start_time",
            )

        decision_resolution = _ensure_non_empty_text(
            str(values["decision_resolution"]),
            "decision_resolution",
        )
        if decision_resolution not in {"1h", "12h", "1d"}:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "decision_resolution: must be one of 1h, 12h, 1d",
            )

        market_manifest_path = Path(values["market_manifest_path"])
        trading_rules_path = Path(values["trading_rules_path"])
        target_snapshots_path = (
            None
            if values.get("target_snapshots_path") is None
            else Path(values["target_snapshots_path"])
        )

        initial_quote_equity = _ensure_positive_decimal(
            as_decimal(values["initial_quote_equity"], "initial_quote_equity"),
            "initial_quote_equity",
        )
        fee_rate = as_decimal(values["fee_rate"], "fee_rate")
        if fee_rate < 0 or fee_rate >= 1:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "fee_rate: must be in [0, 1)",
            )
        slippage_rate = as_decimal(values["slippage_rate"], "slippage_rate")
        if slippage_rate < 0 or slippage_rate >= 1:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "slippage_rate: must be in [0, 1)",
            )

        max_gross = _ensure_positive_decimal(
            as_decimal(values["max_gross"], "max_gross"),
            "max_gross",
        )
        max_legs = _ensure_non_negative_int(values["max_legs"], "max_legs")
        if max_legs == 0:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "max_legs: expected positive value",
            )
        seed = _ensure_non_negative_int(values["seed"], "seed", allow_zero=True)
        hummingbot_image_digest = _ensure_sha256_image(
            _ensure_non_empty_text(str(values["hummingbot_image_digest"]), "hummingbot_image_digest"),
            "hummingbot_image_digest",
        )
        rule_policy = _validate_rule_policy(_ensure_non_empty_text(str(values["rule_policy"]), "rule_policy"))

        return cls(
            controller_config=controller_config_path,
            start_time=start_time,
            end_time=end_time,
            decision_resolution=decision_resolution,
            market_manifest_path=market_manifest_path,
            target_snapshots_path=target_snapshots_path,
            trading_rules_path=trading_rules_path,
            initial_quote_equity=initial_quote_equity,
            fee_rate=fee_rate,
            slippage_rate=slippage_rate,
            max_gross=max_gross,
            max_legs=max_legs,
            seed=seed,
            hummingbot_image_digest=hummingbot_image_digest,
            rule_policy=rule_policy,
        )

    def canonical_mapping(self, *, path_aliases: Mapping[str, str] | None = None) -> dict[str, object]:
        return {
            "controller_config": (
                _serialize_mapping(self.controller_config)
                if isinstance(self.controller_config, Mapping)
                else _resolve_alias(self.controller_config, path_aliases)
            ),
            "start_time": _timestamp_to_string(self.start_time),
            "end_time": _timestamp_to_string(self.end_time),
            "decision_resolution": self.decision_resolution,
            "market_manifest_path": _resolve_alias(self.market_manifest_path, path_aliases),
            "target_snapshots_path": None
            if self.target_snapshots_path is None
            else _resolve_alias(self.target_snapshots_path, path_aliases),
            "trading_rules_path": _resolve_alias(self.trading_rules_path, path_aliases),
            "initial_quote_equity": str(self.initial_quote_equity),
            "fee_rate": str(self.fee_rate),
            "slippage_rate": str(self.slippage_rate),
            "max_gross": str(self.max_gross),
            "max_legs": self.max_legs,
            "seed": self.seed,
            "hummingbot_image_digest": self.hummingbot_image_digest,
            "rule_policy": self.rule_policy.value,
        }


__all__ = [
    "BlockingCode",
    "RejectionCode",
    "RulePolicy",
    "AuditedBacktestError",
    "as_decimal",
    "as_utc",
    "AuditedPositionIntent",
    "AuditedStopIntent",
    "Rejection",
    "ActionTrace",
    "OrderTrace",
    "DataReadTrace",
    "RunnerOutput",
    "BacktestRequest",
]
