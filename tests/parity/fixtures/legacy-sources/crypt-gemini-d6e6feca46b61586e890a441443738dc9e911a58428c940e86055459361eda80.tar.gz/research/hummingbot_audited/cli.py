"A fail-closed isolated CLI for audited Hummingbot replays."
from __future__ import annotations

import argparse
import asyncio
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import stat
import subprocess
import sys
import tempfile
import warnings
from collections.abc import Mapping
from dataclasses import replace
from typing import Any

from research.hummingbot_audited.contracts import AuditedBacktestError, BacktestRequest, BlockingCode
from research.hummingbot_audited.result import build_result_payload, canonical_json_bytes

_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_GIT_SHA = re.compile(r"^[0-9a-f]{40}$")
_REQUEST_FIELDS = frozenset({
    "controller_config", "start_time", "end_time", "decision_resolution",
    "market_manifest_path", "target_snapshots_path", "trading_rules_path",
    "initial_quote_equity", "fee_rate", "slippage_rate", "max_gross",
    "max_legs", "seed", "hummingbot_image_digest", "rule_policy",
})


class _ArgumentError(Exception):
    pass


class _Parser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise _ArgumentError(message)


class _UniqueAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None) -> None:
        if getattr(namespace, self.dest, None) is not None:
            raise _ArgumentError(f"{option_string}: repeated option")
        setattr(namespace, self.dest, values)


def _strict_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant: {value}")


def _strict_json(data: bytes, *, context: str) -> Any:
    try:
        return json.loads(
            data.decode("utf-8", errors="strict"),
            object_pairs_hook=_strict_pairs,
            parse_constant=_reject_constant,
        )
    except (UnicodeDecodeError, ValueError, json.JSONDecodeError) as exc:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{context}: strict JSON required",
            {"context": context},
        ) from exc


def _raise(code: BlockingCode, message: str, context: str) -> None:
    raise AuditedBacktestError(code, message, {"context": context})


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _relative_path(path: Path, root: Path, *, name: str) -> str:
    lexical_parts = Path(os.fspath(path)).parts
    if any(part in {".", ".."} for part in lexical_parts):
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: path traversal is forbidden", name)
    absolute = _absolute(path)
    try:
        relative = absolute.relative_to(root)
    except ValueError as exc:
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: path outside request root", name)
        raise AssertionError from exc
    parts = PurePosixPath(relative.as_posix()).parts
    if not parts or any(part in {"", ".", ".."} for part in parts):
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: path must be normalized", name)
    return PurePosixPath(*parts).as_posix()


def _required_open_flags(*names: str) -> int:
    try:
        flags = 0
        for name in names:
            flags |= getattr(os, name)
        return flags
    except AttributeError as exc:
        raise OSError(f"required open capability unavailable: {exc.args[0]}") from exc


def _open_request_root(root: Path) -> int:
    flags = _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
    absolute = _absolute(root)
    current_fd = os.open(os.sep, flags)
    try:
        for component in absolute.parts[1:]:
            next_fd = os.open(component, flags, dir_fd=current_fd)
            os.close(current_fd)
            current_fd = next_fd
        return current_fd
    except BaseException:
        os.close(current_fd)
        raise


def _open_output_root(path: Path) -> tuple[int, int, bool, tuple[int, int]]:
    flags = _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
    absolute = _absolute(path)
    current_fd = os.open(os.sep, flags)
    try:
        components = absolute.parts[1:]
        if not components:
            raise OSError("output directory must not be filesystem root")
        for index, component in enumerate(components):
            final = index == len(components) - 1
            created = False
            created_identity: tuple[int, int] | None = None
            next_fd: int | None = None
            try:
                next_fd = os.open(component, flags, dir_fd=current_fd)
            except FileNotFoundError:
                try:
                    os.mkdir(component, 0o700, dir_fd=current_fd)
                except FileExistsError:
                    pass
                else:
                    created = final
                    if created:
                        info = os.stat(component, dir_fd=current_fd, follow_symlinks=False)
                        created_identity = (info.st_dev, info.st_ino)
                try:
                    next_fd = os.open(component, flags, dir_fd=current_fd)
                except BaseException:
                    if created and created_identity is not None:
                        try:
                            info = os.stat(component, dir_fd=current_fd, follow_symlinks=False)
                            if (info.st_dev, info.st_ino) == created_identity:
                                os.rmdir(component, dir_fd=current_fd)
                        except OSError:
                            pass
                    raise
            if final:
                parent_fd = current_fd
                try:
                    info = os.fstat(next_fd)
                except BaseException:
                    os.close(next_fd)
                    if created and created_identity is not None:
                        try:
                            bound = os.stat(component, dir_fd=parent_fd, follow_symlinks=False)
                            if (bound.st_dev, bound.st_ino) == created_identity:
                                os.rmdir(component, dir_fd=parent_fd)
                        except OSError:
                            pass
                    raise
                if created and created_identity != (info.st_dev, info.st_ino):
                    os.close(next_fd)
                    raise OSError("output directory binding changed")
                return next_fd, parent_fd, created, (info.st_dev, info.st_ino)
            old_fd = current_fd
            current_fd = next_fd
            next_fd = None
            os.close(old_fd)
    except BaseException:
        os.close(current_fd)
        raise
    raise AssertionError("unreachable output root traversal")


def _capture_relative(relative: str, root_fd: int, *, name: str) -> bytes:
    if not isinstance(relative, str) or not relative or relative.startswith("/") or "\\" in relative:
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: path must be normalized", name)
    raw_components = relative.split("/")
    if any(component in {"", ".", ".."} for component in raw_components):
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: path must be normalized", name)
    if "/".join(raw_components) != relative:
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: path must be normalized", name)
    parent_flags = _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
    file_flags = _required_open_flags("O_RDONLY", "O_NOFOLLOW", "O_CLOEXEC")
    components = tuple(raw_components)
    current_fd = os.dup(root_fd)
    try:
        for component in components[:-1]:
            next_fd = os.open(component, parent_flags, dir_fd=current_fd)
            os.close(current_fd)
            current_fd = next_fd
        fd = os.open(components[-1], file_flags, dir_fd=current_fd)
        try:
            before = os.fstat(fd)
            if not stat.S_ISREG(before.st_mode):
                raise OSError("not a regular file")
            chunks: list[bytes] = []
            while True:
                chunk = os.read(fd, 1024 * 1024)
                if not chunk:
                    break
                chunks.append(chunk)
            after = os.fstat(fd)
        finally:
            os.close(fd)
        if (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) != (
            before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns
        ):
            raise OSError("file changed while reading")
    except OSError as exc:
        _raise(BlockingCode.INVALID_REQUEST, f"{name}: secure read failed", name)
        raise AssertionError from exc
    finally:
        os.close(current_fd)
    return b"".join(chunks)


def _capture(path: Path, root: Path, *, name: str, root_fd: int | None = None) -> tuple[str, bytes]:
    owned_fd = root_fd is None
    if owned_fd:
        try:
            root_fd = _open_request_root(root)
        except OSError as exc:
            _raise(BlockingCode.INVALID_REQUEST, f"{name}: secure root open failed", name)
            raise AssertionError from exc
    try:
        relative = _relative_path(path, root, name=name)
        return relative, _capture_relative(relative, root_fd, name=name)
    finally:
        if owned_fd:
            os.close(root_fd)


def _validate_manifest(
    raw: Any, *, root_fd: int, manifest_relative: str
) -> list[tuple[str, str, bytes]]:
    if not isinstance(raw, Mapping) or not isinstance(raw.get("files"), list):
        _raise(BlockingCode.INVALID_REQUEST, "manifest: expected object with files list", "manifest")
    output: list[tuple[str, str, bytes]] = []
    seen: set[str] = set()
    listed: list[str] = []
    for index, record in enumerate(raw["files"]):
        if not isinstance(record, Mapping) or not {"path", "sha256"} <= set(record):
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: invalid record", "manifest")
        raw_path = record["path"]
        expected = record["sha256"]
        if not isinstance(raw_path, str) or not isinstance(expected, str) or not _SHA256.fullmatch(expected):
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: invalid path/hash", "manifest")
        if Path(raw_path).is_absolute() or "\\" in raw_path:
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: path must be relative", "manifest")
        parts = PurePosixPath(raw_path).parts
        normalized = PurePosixPath(*parts).as_posix() if parts else ""
        if not parts or normalized != raw_path or any(part in {"", ".", ".."} for part in parts):
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: path must be normalized", "manifest")
        if raw_path in seen:
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: duplicate path", "manifest")
        seen.add(raw_path)
        listed.append(raw_path)
        alias = PurePosixPath(manifest_relative).parent.joinpath(raw_path).as_posix()
        if alias.startswith("../") or alias == "..":
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: path outside request root", "manifest")
        data = _capture_relative(alias, root_fd, name=f"manifest.files[{index}]")
        if hashlib.sha256(data).hexdigest() != expected:
            _raise(BlockingCode.INVALID_REQUEST, f"manifest.files[{index}]: hash mismatch", "manifest")
        # Keep the manifest's own relative path for runtime semantics.  The
        # request-root alias is only the location from which immutable bytes
        # were captured and is reconstructed where provenance/snapshot paths
        # are recorded.
        output.append((raw_path, expected, data))
    if listed != sorted(listed):
        _raise(BlockingCode.INVALID_REQUEST, "manifest.files: expected sorted path order", "manifest")
    return output


def _git_sha(_root: Path) -> str:
    try:
        value = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=Path(__file__).resolve().parents[2],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError) as exc:
        _raise(BlockingCode.INVALID_REQUEST, "git_sha: unable to identify commit", "git_sha")
        raise AssertionError from exc
    if not _GIT_SHA.fullmatch(value):
        _raise(BlockingCode.INVALID_REQUEST, "git_sha: invalid commit id", "git_sha")
    return value


def _write_snapshot_data(fd: int, data: bytes) -> None:
    view = memoryview(data)
    while view:
        written = os.write(fd, view)
        if written <= 0:
            raise OSError("snapshot write made no progress")
        view = view[written:]


def _rename_noreplace(parent_fd: int, source: str, destination: str) -> None:
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        renameat2 = libc.renameat2
    except (AttributeError, OSError) as exc:
        raise OSError("renameat2 is unavailable; refusing non-atomic snapshot installation") from exc
    renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    renameat2.restype = ctypes.c_int
    result = renameat2(
        parent_fd,
        source.encode(),
        parent_fd,
        destination.encode(),
        1,
    )
    if result != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error), destination)


def _copy_snapshot_owned(
    workspace: "_BoundSnapshotWorkspace", relative: str, data: bytes
) -> Path:
    parts = PurePosixPath(relative).parts
    current_fd = os.dup(workspace.root_fd)
    file_fd = -1
    parent_identity = workspace.identity
    try:
        for name in parts[:-1]:
            try:
                named_info = os.stat(name, dir_fd=current_fd, follow_symlinks=False)
            except FileNotFoundError:
                expected = workspace._entries.get((parent_identity, name))
                if expected is not None:
                    raise OSError("snapshot directory binding changed")
                child_fd = -1
                temporary_name: str | None = None
                installed = False
                child_identity: tuple[int, int] | None = None
                try:
                    flags = _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
                    for _ in range(32):
                        candidate = f".hba-snapshot-tmp-{secrets.token_hex(16)}"
                        try:
                            os.mkdir(candidate, 0o700, dir_fd=current_fd)
                        except FileExistsError:
                            continue
                        temporary_name = candidate
                        break
                    if temporary_name is None:
                        raise FileExistsError("unable to allocate private snapshot directory")
                    child_fd = os.open(temporary_name, flags, dir_fd=current_fd)
                    child_info = os.fstat(child_fd)
                    child_identity = (child_info.st_dev, child_info.st_ino)
                    temporary_info = os.stat(temporary_name, dir_fd=current_fd, follow_symlinks=False)
                    if (
                        not stat.S_ISDIR(temporary_info.st_mode)
                        or child_identity != (temporary_info.st_dev, temporary_info.st_ino)
                    ):
                        raise OSError("snapshot directory binding changed")
                    _rename_noreplace(current_fd, temporary_name, name)
                    installed = True
                    named_info = os.stat(name, dir_fd=current_fd, follow_symlinks=False)
                    named_identity = (named_info.st_dev, named_info.st_ino)
                    bound_info = os.fstat(child_fd)
                    if (
                        not stat.S_ISDIR(named_info.st_mode)
                        or named_identity != child_identity
                        or named_identity != (bound_info.st_dev, bound_info.st_ino)
                    ):
                        raise OSError("snapshot directory binding changed")
                    workspace._entries[(parent_identity, name)] = (child_identity, True)
                except BaseException as active:
                    if child_fd >= 0:
                        try:
                            os.close(child_fd)
                        except BaseException:
                            pass
                        child_fd = -1
                    cleanup_name = name if installed else temporary_name
                    if cleanup_name is not None and child_identity is not None:
                        try:
                            current = os.stat(cleanup_name, dir_fd=current_fd, follow_symlinks=False)
                            if (current.st_dev, current.st_ino) == child_identity:
                                os.rmdir(cleanup_name, dir_fd=current_fd)
                        except BaseException:
                            pass
                    raise
                os.close(current_fd)
                current_fd = child_fd
                parent_identity = child_identity
                continue
            expected = workspace._entries.get((parent_identity, name))
            named_identity = (named_info.st_dev, named_info.st_ino)
            if (
                expected is None
                or not expected[1]
                or expected[0] != named_identity
                or not stat.S_ISDIR(named_info.st_mode)
            ):
                raise OSError("snapshot directory binding changed")
            child_fd = os.open(
                name,
                _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC"),
                dir_fd=current_fd,
            )
            child_info = os.fstat(child_fd)
            child_identity = (child_info.st_dev, child_info.st_ino)
            if named_identity != child_identity:
                os.close(child_fd)
                raise OSError("snapshot directory binding changed")
            os.close(current_fd)
            current_fd = child_fd
            parent_identity = child_identity

        file_fd = os.open(
            parts[-1],
            _required_open_flags("O_WRONLY", "O_CREAT", "O_EXCL", "O_NOFOLLOW", "O_CLOEXEC"),
            0o600,
            dir_fd=current_fd,
        )
        file_info = os.fstat(file_fd)
        file_identity = (file_info.st_dev, file_info.st_ino)
        if not stat.S_ISREG(file_info.st_mode):
            os.close(file_fd)
            raise OSError("snapshot file binding changed")
        workspace._entries[(parent_identity, parts[-1])] = (file_identity, False)
        try:
            _write_snapshot_data(file_fd, data)
        except BaseException as active:
            try:
                os.close(file_fd)
            except BaseException:
                pass
            file_fd = -1
            raise active
        os.close(file_fd)
        file_fd = -1
        os.close(current_fd)
        current_fd = -1
        return workspace.runtime_path / relative
    except BaseException as active:
        try:
            os.close(current_fd)
        except BaseException:
            pass
        raise active
    finally:
        if file_fd >= 0:
            try:
                os.close(file_fd)
            except BaseException:
                if sys.exc_info()[0] is None:
                    raise


class _BoundSnapshotWorkspace:
    """Own one allocated snapshot directory by descriptor identity."""

    def __init__(self, lexical_path: Path, parent_fd: int, root_fd: int, identity: tuple[int, int]) -> None:
        self.lexical_path = lexical_path
        self.lexical_name = lexical_path.name
        self.parent_fd = parent_fd
        self.root_fd = root_fd
        self.identity = identity
        self.runtime_path = Path(f"/proc/self/fd/{root_fd}")
        self._entries: dict[tuple[tuple[int, int], str], tuple[tuple[int, int], bool]] = {}

    @classmethod
    def allocate(cls) -> "_BoundSnapshotWorkspace":
        lexical_path = Path(tempfile.mkdtemp(prefix=".hba-snapshot-"))
        allocated = os.lstat(lexical_path)
        allocated_identity = (allocated.st_dev, allocated.st_ino)
        parent_fd: int | None = None
        root_fd: int | None = None
        try:
            parent_fd = _open_request_root(lexical_path.parent)
            flags = _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
            root_fd = os.open(lexical_path.name, flags, dir_fd=parent_fd)
            info = os.fstat(root_fd)
            opened_identity = (info.st_dev, info.st_ino)
            if opened_identity != allocated_identity:
                raise OSError("snapshot directory binding changed")
            return cls(lexical_path, parent_fd, root_fd, opened_identity)
        except BaseException as allocation_error:
            if root_fd is not None:
                try:
                    os.close(root_fd)
                except BaseException:
                    pass
            if parent_fd is not None:
                try:
                    os.close(parent_fd)
                except BaseException:
                    pass
            try:
                cleanup_parent_fd = _open_request_root(lexical_path.parent)
                try:
                    current = os.stat(lexical_path.name, dir_fd=cleanup_parent_fd, follow_symlinks=False)
                    if (current.st_dev, current.st_ino) == allocated_identity:
                        cleanup_fd = os.open(
                            lexical_path.name,
                            _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC"),
                            dir_fd=cleanup_parent_fd,
                        )
                        try:
                            cleanup_info = os.fstat(cleanup_fd)
                            cleanup_identity = (cleanup_info.st_dev, cleanup_info.st_ino)
                        finally:
                            try:
                                os.close(cleanup_fd)
                            except BaseException:
                                pass
                        if cleanup_identity == allocated_identity:
                            try:
                                os.rmdir(lexical_path.name, dir_fd=cleanup_parent_fd)
                            except BaseException:
                                pass
                finally:
                    try:
                        os.close(cleanup_parent_fd)
                    except BaseException:
                        pass
            except BaseException:
                pass
            raise

    def cleanup(self) -> None:
        try:
            self._remove_contents(self.root_fd, self._entries, self.identity)
            for name in os.listdir(self.parent_fd):
                try:
                    current = os.stat(name, dir_fd=self.parent_fd, follow_symlinks=False)
                    if (current.st_dev, current.st_ino) == self.identity:
                        os.rmdir(name, dir_fd=self.parent_fd)
                        break
                except OSError:
                    continue
        finally:
            try:
                os.close(self.root_fd)
            finally:
                os.close(self.parent_fd)

    @classmethod
    def _remove_contents(
        cls,
        directory_fd: int,
        entries: dict[tuple[tuple[int, int], str], tuple[tuple[int, int], bool]],
        directory_identity: tuple[int, int],
    ) -> None:
        for name in os.listdir(directory_fd):
            expected = entries.get((directory_identity, name))
            if expected is None:
                continue
            expected_identity, expected_is_directory = expected
            try:
                info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
                current_identity = (info.st_dev, info.st_ino)
                current_is_directory = stat.S_ISDIR(info.st_mode)
                if current_identity != expected_identity or current_is_directory != expected_is_directory:
                    continue
                if expected_is_directory:
                    child_fd = os.open(
                        name,
                        _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC"),
                        dir_fd=directory_fd,
                    )
                    try:
                        child_info = os.fstat(child_fd)
                        child_identity = (child_info.st_dev, child_info.st_ino)
                        if child_identity != expected_identity:
                            continue
                        cls._remove_contents(child_fd, entries, expected_identity)
                    finally:
                        os.close(child_fd)
                    current = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
                    if (current.st_dev, current.st_ino) == expected_identity:
                        os.rmdir(name, dir_fd=directory_fd)
                else:
                    os.unlink(name, dir_fd=directory_fd)
            except OSError:
                pass


def _discover_symbols(records: list[tuple[str, str, bytes]]) -> set[str]:
    symbols: set[str] = set()
    matcher = re.compile(r"^([a-z0-9]+_[a-z0-9]+)_(?:1d|1h|funding)_[^/]+\.csv$")
    for path, _, _ in records:
        match = matcher.fullmatch(PurePosixPath(path).name)
        if match:
            symbols.add(match.group(1))
    if not symbols:
        _raise(BlockingCode.DATA_GAP, "manifest: no market symbol bundles", "manifest")
    return symbols


def _collect(request_path: Path, request: BacktestRequest, request_bytes: bytes, *, root_fd: int):
    root = _absolute(request_path).parent
    request_relative = _relative_path(request_path, root, name="request")
    records: list[tuple[str, str, bytes]] = [
        (request_relative, hashlib.sha256(request_bytes).hexdigest(), request_bytes)
    ]
    manifest_relative, manifest_bytes = _capture(
        request.market_manifest_path, root, name="market_manifest_path", root_fd=root_fd
    )
    manifest_raw = _strict_json(manifest_bytes, context="market_manifest")
    market_records = _validate_manifest(
        manifest_raw,
        root_fd=root_fd,
        manifest_relative=manifest_relative,
    )
    records.extend(
        (
            PurePosixPath(manifest_relative).parent.joinpath(path).as_posix(),
            digest,
            data,
        )
        for path, digest, data in market_records
    )
    records.append((manifest_relative, hashlib.sha256(manifest_bytes).hexdigest(), manifest_bytes))
    rules_relative, rules_bytes = _capture(
        request.trading_rules_path, root, name="trading_rules_path", root_fd=root_fd
    )
    _strict_json(rules_bytes, context="trading_rules")
    records.append((rules_relative, hashlib.sha256(rules_bytes).hexdigest(), rules_bytes))
    target_bytes = None
    target_relative = None
    if request.target_snapshots_path is not None:
        target_relative, target_bytes = _capture(
            request.target_snapshots_path, root, name="target_snapshots_path", root_fd=root_fd
        )
        records.append((target_relative, hashlib.sha256(target_bytes).hexdigest(), target_bytes))
    if isinstance(request.controller_config, Mapping):
        controller_bytes = canonical_json_bytes(request.controller_config)
        controller_relative = None
        records.append(("controller_config:inline", hashlib.sha256(controller_bytes).hexdigest(), controller_bytes))
    else:
        controller_relative, controller_bytes = _capture(
            request.controller_config, root, name="controller_config", root_fd=root_fd
        )
        records.append((controller_relative, hashlib.sha256(controller_bytes).hexdigest(), controller_bytes))
    paths = [path for path, _, _ in records]
    if len(paths) != len(set(paths)):
        duplicate = next(path for path in paths if paths.count(path) > 1)
        _raise(BlockingCode.INVALID_REQUEST, f"provenance: duplicate path: {duplicate}", "provenance")
    provenance = tuple(
        {"path": path, "sha256": digest}
        for path, digest, _ in sorted(records, key=lambda item: item[0])
    )
    path_aliases = {str(_absolute(request_path)): request_relative}
    for path, _, _ in records:
        if path != "controller_config:inline":
            path_aliases[str(root / path)] = path
    git_sha = _git_sha(root)
    request_hash = hashlib.sha256(canonical_json_bytes({
        "request": request.canonical_mapping(path_aliases=path_aliases),
        "provenance": provenance,
        "git_sha": git_sha,
    })).hexdigest()
    return (
        root, provenance, git_sha, request_hash, f"hba-{request_hash[:24]}",
        market_records, manifest_bytes, manifest_relative, target_bytes, target_relative,
        rules_bytes, rules_relative, controller_bytes, controller_relative,
    )


class _AtomicPublisher:
    _RENAME_NOREPLACE = 1

    def __init__(self, output_dir: Path, run_id: str) -> None:
        self.output_dir = output_dir
        self.run_id = run_id
        self.root_fd: int | None = None
        self.lock_fd: int | None = None
        self._lock_acquired = False
        self.stage_fd: int | None = None
        self._stage_name: str | None = None
        self._stage_identity: tuple[int, int] | None = None
        self._lock_name = f".hba-{run_id}.lock"
        self._output_parent_fd: int | None = None
        self._output_created = False
        self._output_identity: tuple[int, int] | None = None

    def __enter__(self) -> "_AtomicPublisher":
        (
            self.root_fd,
            self._output_parent_fd,
            self._output_created,
            self._output_identity,
        ) = _open_output_root(self.output_dir)
        gate_fd = self.root_fd
        gate_held = False
        try:
            fcntl.flock(self.root_fd, fcntl.LOCK_EX)
            gate_held = True
            self.lock_fd = os.open(
                self._lock_name,
                _required_open_flags("O_RDWR", "O_CREAT", "O_NOFOLLOW", "O_CLOEXEC"),
                0o600,
                dir_fd=self.root_fd,
            )
            fcntl.flock(self.lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self._lock_acquired = True
            try:
                os.stat(self.run_id, dir_fd=self.root_fd, follow_symlinks=False)
            except FileNotFoundError:
                pass
            else:
                raise FileExistsError(self.run_id)
            self.prepare()
            return self
        except BaseException:
            try:
                self._cleanup()
            except BaseException:
                pass
            raise
        finally:
            if gate_held:
                try:
                    fcntl.flock(gate_fd, fcntl.LOCK_UN)
                except OSError:
                    pass

    def prepare(self) -> None:
        if self.stage_fd is not None:
            return
        if self.root_fd is None:
            raise RuntimeError("publisher is not open")
        flags = _required_open_flags("O_RDONLY", "O_DIRECTORY", "O_NOFOLLOW", "O_CLOEXEC")
        for _ in range(32):
            name = f".hba-stage-{secrets.token_hex(16)}"
            try:
                os.mkdir(name, 0o700, dir_fd=self.root_fd)
            except FileExistsError:
                continue
            self._stage_name = name
            stage = os.stat(name, dir_fd=self.root_fd, follow_symlinks=False)
            self._stage_identity = (stage.st_dev, stage.st_ino)
            self.stage_fd = os.open(name, flags, dir_fd=self.root_fd)
            return
        raise FileExistsError("unable to allocate unique staging directory")

    def publish(self, result_bytes: bytes) -> None:
        if self.root_fd is None or self.stage_fd is None or self._stage_name is None:
            raise RuntimeError("publisher is not prepared")
        result_fd = os.open(
            "result.json",
            _required_open_flags("O_WRONLY", "O_CREAT", "O_EXCL", "O_NOFOLLOW", "O_CLOEXEC"),
            0o600,
            dir_fd=self.stage_fd,
        )
        try:
            offset = 0
            while offset < len(result_bytes):
                written = os.write(result_fd, result_bytes[offset:])
                if written <= 0:
                    raise OSError("short result write")
                offset += written
            os.fsync(result_fd)
        finally:
            os.close(result_fd)
        os.fsync(self.stage_fd)
        bound = os.stat(self._stage_name, dir_fd=self.root_fd, follow_symlinks=False)
        stage = os.fstat(self.stage_fd)
        if (bound.st_dev, bound.st_ino) != (stage.st_dev, stage.st_ino):
            raise OSError("staging directory binding changed")
        self._revalidate_lexical_output_root()
        try:
            libc = ctypes.CDLL(None, use_errno=True)
            renameat2 = libc.renameat2
        except (AttributeError, OSError) as exc:
            raise OSError("renameat2 is unavailable; refusing non-atomic publication") from exc
        renameat2.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        renameat2.restype = ctypes.c_int
        result = renameat2(
            self.root_fd,
            self._stage_name.encode(),
            self.root_fd,
            self.run_id.encode(),
            self._RENAME_NOREPLACE,
        )
        if result != 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), self.run_id)
        try:
            installed = os.stat(self.run_id, dir_fd=self.root_fd, follow_symlinks=False)
            stage = os.fstat(self.stage_fd)
            stage_identity = (stage.st_dev, stage.st_ino)
            if (installed.st_dev, installed.st_ino) != stage_identity:
                raise OSError("published run directory binding changed")
            self._revalidate_lexical_output_root()
            os.fsync(self.root_fd)
            self._revalidate_lexical_output_root()
        except BaseException:
            try:
                installed = os.stat(self.run_id, dir_fd=self.root_fd, follow_symlinks=False)
                if (installed.st_dev, installed.st_ino) == stage_identity:
                    os.rmdir(self.run_id, dir_fd=self.root_fd)
            except BaseException:
                pass
            raise
        # Keep stage_fd and _stage_name live until all post-rename checks pass.
        self._stage_name = None
        os.close(self.stage_fd)
        self.stage_fd = None

    def _revalidate_lexical_output_root(self) -> None:
        if self.root_fd is None:
            raise OSError("publisher root is closed")
        lexical_fd = _open_request_root(self.output_dir)
        try:
            bound = os.fstat(self.root_fd)
            lexical = os.fstat(lexical_fd)
            if (bound.st_dev, bound.st_ino) != (lexical.st_dev, lexical.st_ino):
                raise OSError("output root lexical binding changed")
        finally:
            os.close(lexical_fd)

    def __exit__(self, exc_type, exc, traceback) -> bool:
        try:
            self._cleanup()
        except BaseException:
            if exc_type is None:
                raise
        return False

    def _cleanup(self) -> None:
        if self.stage_fd is not None:
            try:
                os.unlink("result.json", dir_fd=self.stage_fd)
            except OSError:
                pass
            if self.root_fd is not None:
                gate_held = False
                try:
                    fcntl.flock(self.root_fd, fcntl.LOCK_EX)
                    gate_held = True
                    stage = os.fstat(self.stage_fd)
                    for name in os.listdir(self.root_fd):
                        try:
                            candidate = os.stat(name, dir_fd=self.root_fd, follow_symlinks=False)
                        except OSError:
                            continue
                        if (candidate.st_dev, candidate.st_ino) == (stage.st_dev, stage.st_ino):
                            try:
                                os.rmdir(name, dir_fd=self.root_fd)
                            except OSError:
                                pass
                except OSError:
                    pass
                finally:
                    if gate_held:
                        try:
                            fcntl.flock(self.root_fd, fcntl.LOCK_UN)
                        except OSError:
                            pass
            try:
                os.close(self.stage_fd)
            except OSError:
                pass
            self.stage_fd = None
            self._stage_name = None
            self._stage_identity = None
        elif self._stage_name is not None and self.root_fd is not None:
            try:
                candidate = os.stat(self._stage_name, dir_fd=self.root_fd, follow_symlinks=False)
                if self._stage_identity == (candidate.st_dev, candidate.st_ino):
                    os.rmdir(self._stage_name, dir_fd=self.root_fd)
            except OSError:
                pass
            self._stage_name = None
            self._stage_identity = None
        if self.lock_fd is not None:
            gate_held = False
            if self.root_fd is not None and self._lock_acquired:
                try:
                    fcntl.flock(self.root_fd, fcntl.LOCK_EX)
                    gate_held = True
                    lock_info = os.fstat(self.lock_fd)
                    try:
                        path_info = os.stat(self._lock_name, dir_fd=self.root_fd, follow_symlinks=False)
                    except OSError:
                        path_info = None
                    if path_info is not None and (path_info.st_dev, path_info.st_ino) == (
                        lock_info.st_dev, lock_info.st_ino
                    ):
                        os.unlink(self._lock_name, dir_fd=self.root_fd)
                except OSError:
                    pass
            try:
                os.close(self.lock_fd)
            except OSError:
                pass
            self.lock_fd = None
            self._lock_acquired = False
            if gate_held:
                try:
                    fcntl.flock(self.root_fd, fcntl.LOCK_UN)
                except OSError:
                    pass
        if self._output_created and self._output_parent_fd is not None and self._output_identity is not None:
            try:
                candidate = os.stat(self.output_dir.name, dir_fd=self._output_parent_fd, follow_symlinks=False)
                if (candidate.st_dev, candidate.st_ino) == self._output_identity:
                    os.rmdir(self.output_dir.name, dir_fd=self._output_parent_fd)
            except OSError:
                pass
        if self.root_fd is not None:
            try:
                os.close(self.root_fd)
            except OSError:
                pass
            self.root_fd = None
        if self._output_parent_fd is not None:
            try:
                os.close(self._output_parent_fd)
            except OSError:
                pass
            self._output_parent_fd = None


async def run_request(request_path: Path, output_dir: Path) -> dict[str, Any]:
    request_path = _absolute(request_path)
    root = request_path.parent
    root_fd = _open_request_root(root)
    snapshot_workspace: _BoundSnapshotWorkspace | None = None
    try:
        request_relative, request_bytes = _capture(request_path, root, name="request", root_fd=root_fd)
        del request_relative
        raw_request = _strict_json(request_bytes, context="request")
        required_request_fields = _REQUEST_FIELDS - {"target_snapshots_path"}
        if (
            not isinstance(raw_request, Mapping)
            or not set(raw_request) <= _REQUEST_FIELDS
            or not required_request_fields <= set(raw_request)
        ):
            _raise(BlockingCode.INVALID_REQUEST, "request: unknown or missing fields", "request")
        request = BacktestRequest.from_mapping(raw_request)
        if os.environ.get("HUMMINGBOT_IMAGE_DIGEST") != request.hummingbot_image_digest:
            raise AuditedBacktestError(
                BlockingCode.CONTAINER_DIGEST_MISMATCH,
                "HUMMINGBOT_IMAGE_DIGEST does not match request",
                {"context": "container_digest"},
            )
        if request.target_snapshots_path is None:
            _raise(
                BlockingCode.INVALID_REQUEST,
                "target_snapshots_path: required and must not be null",
                "target_snapshots_path",
            )
        request_root = request_path.parent
        request = replace(
            request,
            controller_config=(
                request.controller_config
                if isinstance(request.controller_config, Mapping)
                else request_root / request.controller_config
            ),
            market_manifest_path=request_root / request.market_manifest_path,
            target_snapshots_path=request_root / request.target_snapshots_path,
            trading_rules_path=request_root / request.trading_rules_path,
        )
        (
            root, provenance, git_sha, request_hash, run_id, market_records,
            manifest_bytes, manifest_relative, target_bytes, target_relative,
            rules_bytes, rules_relative, controller_bytes, controller_relative,
        ) = _collect(request_path, request, request_bytes, root_fd=root_fd)
    finally:
        os.close(root_fd)

    output_dir = _absolute(output_dir)
    with _AtomicPublisher(output_dir, run_id) as publisher:
        snapshot_workspace = _BoundSnapshotWorkspace.allocate()
        snapshot_dir = snapshot_workspace.runtime_path
        try:
            for path, _, data in market_records:
                market_alias = PurePosixPath(manifest_relative).parent.joinpath(path).as_posix()
                _copy_snapshot_owned(snapshot_workspace, market_alias, data)
            _copy_snapshot_owned(snapshot_workspace, manifest_relative, manifest_bytes)
            _copy_snapshot_owned(snapshot_workspace, rules_relative, rules_bytes)
            if target_relative is not None and target_bytes is not None:
                _copy_snapshot_owned(snapshot_workspace, target_relative, target_bytes)
            if isinstance(request.controller_config, Mapping):
                controller_value: Mapping[str, object] | Path = request.controller_config
            else:
                controller_value = _copy_snapshot_owned(snapshot_workspace, controller_relative, controller_bytes)
                from research.hummingbot_audited.runtime.runner import _read_yaml_mapping_bytes
                controller_value = _read_yaml_mapping_bytes(controller_bytes, str(controller_relative))
            manifest_path = snapshot_dir / manifest_relative
            rules_path = snapshot_dir / rules_relative

            from research.hummingbot_audited.market_data import (
                HistoricalMarketData, MarketManifest, TargetSnapshotSeries, load_decimal_symbol_bundle_from_bytes,
            )
            from research.blend_v2.data import ManifestEntry
            from research.hummingbot_audited.rules import RuleBook
            from research.hummingbot_audited.timeline import TradableCalendar, decision_times
            from research.hummingbot_audited.engine import AuditedPortfolioEngine
            from research.blend_v2.types import CostModel

            captured_market_files = {path: data for path, _, data in market_records}
            market_manifest = MarketManifest(
                Path(manifest_relative),
                tuple(ManifestEntry(path=path, sha256=digest) for path, digest, _ in market_records),
            )
            symbols = _discover_symbols(market_records)
            bundles = {
                symbol: load_decimal_symbol_bundle_from_bytes(market_manifest, symbol, captured_market_files)
                for symbol in sorted(symbols)
            }
            market_data = HistoricalMarketData(bundles)
            targets = (
                TargetSnapshotSeries(())
                if target_relative is None
                else TargetSnapshotSeries.from_jsonl(Path(target_relative), data=target_bytes)
            )
            target_symbols = {
                str(leg["pair"]).lower().replace("-", "_")
                for snapshot in targets.snapshots
                for leg in snapshot.payload.get("legs", ())
            }
            if not target_symbols.issubset(bundles):
                _raise(BlockingCode.DATA_GAP, "targets: symbol is absent from market manifest", "targets")
            rules = RuleBook.from_mapping(
                _strict_json(rules_bytes, context="trading_rules"), request.rule_policy
            )
            decisions = decision_times(request.start_time, request.end_time, request.decision_resolution)
            calendar = TradableCalendar(
                {symbol.upper().replace("_", "-"): bundle.hourly.index for symbol, bundle in bundles.items()},
                funding_times=sorted({
                    timestamp for bundle in bundles.values() for timestamp in bundle.funding.index
                }),
                end_time=request.end_time,
            )
            event_times = calendar.event_times(request.start_time, request.end_time, decisions)
            engine = AuditedPortfolioEngine(
                market_data, rules, calendar, event_times, request.initial_quote_equity,
                CostModel(request.fee_rate, request.slippage_rate), request.max_gross, request.max_legs,
            )
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                from research.hummingbot_audited.runtime.provider import ManifestBacktestingDataProvider
                from research.hummingbot_audited.runtime.runner import HistoricalControllerRunner

            runtime_request = replace(
                request,
                market_manifest_path=manifest_path,
                target_snapshots_path=None if target_relative is None else snapshot_dir / target_relative,
                trading_rules_path=rules_path,
                controller_config=controller_value,
            )
            provider = ManifestBacktestingDataProvider(
                market_data, targets, rules, engine, provenance, request.start_time, request.end_time
            )
            runner = HistoricalControllerRunner(
                runtime_request, provider, git_sha=git_sha, request_hash=request_hash, run_id=run_id
            )
            output = await runner.run(controller_value)
            payload = build_result_payload(output)
            publisher.publish(canonical_json_bytes(payload) + b"\n")
            return payload
        finally:
            if snapshot_workspace is not None:
                active_exception = sys.exc_info()[0]
                try:
                    snapshot_workspace.cleanup()
                except BaseException:
                    if active_exception is None:
                        raise
                snapshot_workspace = None


def _parser() -> argparse.ArgumentParser:
    parser = _Parser(add_help=False, allow_abbrev=False)
    parser.add_argument("--request", required=True, action=_UniqueAction)
    parser.add_argument("--output-dir", required=True, action=_UniqueAction)
    return parser


def _error(code: str, message: str, context: str) -> dict[str, Any]:
    return {"code": code, "message": message, "context": {"context": context}}


def main(argv: list[str] | None = None) -> int:
    try:
        args = _parser().parse_args(argv)
        payload = asyncio.run(run_request(Path(args.request), Path(args.output_dir)))
        sys.stdout.write(payload["audit"]["run_id"] + "\n")
        return 0
    except _ArgumentError as exc:
        error = _error(BlockingCode.INVALID_REQUEST.value, str(exc), "arguments")
    except AuditedBacktestError as exc:
        code = exc.code.value if hasattr(exc.code, "value") else str(exc.code)
        error = {"code": code, "message": exc.message, "context": dict(exc.context)}
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        error = _error(BlockingCode.INVALID_REQUEST.value, str(exc) or type(exc).__name__, "validation")
    except Exception as exc:
        error = _error(BlockingCode.INVALID_REQUEST.value, str(exc) or type(exc).__name__, "runtime")
    sys.stderr.write(json.dumps(error, ensure_ascii=False, separators=(",", ":")) + "\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
