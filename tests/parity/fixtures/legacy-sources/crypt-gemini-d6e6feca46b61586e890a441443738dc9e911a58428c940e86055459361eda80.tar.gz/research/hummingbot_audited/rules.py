from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from hashlib import sha256
import json
from typing import Any, Mapping, Sequence

import pandas as pd

from research.hummingbot_audited.contracts import (
    AuditedBacktestError,
    BlockingCode,
    RejectionCode,
    RulePolicy,
    as_decimal,
    as_utc,
)


def _ensure_non_empty_text(value: str, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: must be non-empty text",
        )
    return value


def _ensure_positive_decimal(value: Decimal, name: str) -> Decimal:
    if value <= 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected positive decimal",
        )
    return value


def _ensure_non_negative_decimal(value: Decimal, name: str) -> Decimal:
    if value < 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected non-negative decimal",
        )
    return value


def _ensure_bool(value: Any, name: str) -> bool:
    if not isinstance(value, bool):
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            f"{name}: expected boolean",
        )
    return value


def _timestamp_to_string(timestamp: pd.Timestamp) -> str:
    normalized = as_utc(timestamp, "timestamp").isoformat(timespec="nanoseconds")
    return normalized.replace("+00:00", "Z")


def _canonical_decimal(value: Decimal) -> str:
    return str(value)


def _snapshot_records(value: Any) -> Sequence[Mapping[str, object]]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return tuple(value)
    if isinstance(value, Mapping):
        for key in ("rules", "trading_rules", "records"):
            records = value.get(key)
            if records is not None:
                if isinstance(records, Sequence) and not isinstance(records, (str, bytes, bytearray)):
                    return tuple(records)
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"{key}: expected sequence",
                )
        for required in (
            "connector_name",
            "trading_pair",
            "min_base_amount_increment",
            "min_price_increment",
            "min_order_size",
            "min_notional_size",
            "effective_from",
            "effective_to",
            "reduce_only_min_notional_exempt",
            "source",
            "captured_at",
        ):
            if required not in value:
                raise AuditedBacktestError(
                    BlockingCode.INVALID_REQUEST,
                    f"Missing required field: {required}",
                )
        return (value,)
    raise AuditedBacktestError(
        BlockingCode.INVALID_REQUEST,
        "trading rules: expected sequence of mapping records",
    )


@dataclass(frozen=True)
class TradingRuleSnapshot:
    connector_name: str
    trading_pair: str
    min_base_amount_increment: Decimal
    min_price_increment: Decimal
    min_order_size: Decimal
    min_notional_size: Decimal
    effective_from: pd.Timestamp
    effective_to: pd.Timestamp
    reduce_only_min_notional_exempt: bool
    source: str
    captured_at: pd.Timestamp

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "connector_name",
            _ensure_non_empty_text(self.connector_name, "connector_name"),
        )
        object.__setattr__(
            self,
            "trading_pair",
            _ensure_non_empty_text(self.trading_pair, "trading_pair"),
        )
        object.__setattr__(
            self,
            "min_base_amount_increment",
            _ensure_positive_decimal(
                as_decimal(self.min_base_amount_increment, "min_base_amount_increment"),
                "min_base_amount_increment",
            ),
        )
        object.__setattr__(
            self,
            "min_price_increment",
            _ensure_positive_decimal(
                as_decimal(self.min_price_increment, "min_price_increment"),
                "min_price_increment",
            ),
        )
        object.__setattr__(
            self,
            "min_order_size",
            _ensure_non_negative_decimal(
                as_decimal(self.min_order_size, "min_order_size"),
                "min_order_size",
            ),
        )
        object.__setattr__(
            self,
            "min_notional_size",
            _ensure_non_negative_decimal(
                as_decimal(self.min_notional_size, "min_notional_size"),
                "min_notional_size",
            ),
        )
        object.__setattr__(self, "effective_from", as_utc(self.effective_from, "effective_from"))
        object.__setattr__(self, "effective_to", as_utc(self.effective_to, "effective_to"))
        if self.effective_to < self.effective_from:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "effective_from: must be <= effective_to",
            )
        object.__setattr__(
            self,
            "reduce_only_min_notional_exempt",
            _ensure_bool(self.reduce_only_min_notional_exempt, "reduce_only_min_notional_exempt"),
        )
        object.__setattr__(self, "source", _ensure_non_empty_text(self.source, "source"))
        object.__setattr__(self, "captured_at", as_utc(self.captured_at, "captured_at"))


@dataclass(frozen=True)
class QuantizedOpen:
    amount_base: Decimal
    notional_quote: Decimal
    rejection: RejectionCode | None


@dataclass(frozen=True)
class RuleSelection:
    rule: TradingRuleSnapshot
    integrity_note: str | None


def quantize_open(
    rule: TradingRuleSnapshot,
    requested: object,
    reference_price: object,
) -> QuantizedOpen:
    requested_amount = as_decimal(requested, "requested")
    price = as_decimal(reference_price, "reference_price")
    if requested_amount <= 0 or price <= 0:
        raise AuditedBacktestError(
            BlockingCode.INVALID_REQUEST,
            "requested/reference_price: expected positive decimal",
        )

    amount = (requested_amount // rule.min_base_amount_increment) * rule.min_base_amount_increment
    notional = amount * price
    if amount == 0:
        code = RejectionCode.REJECTED_QUANTIZED_TO_ZERO
    elif amount < rule.min_order_size:
        code = RejectionCode.REJECTED_MIN_ORDER_SIZE
    elif notional < rule.min_notional_size:
        code = RejectionCode.REJECTED_MIN_NOTIONAL
    else:
        code = None
    return QuantizedOpen(amount, notional, code)


@dataclass(frozen=True)
class RuleBook:
    snapshots: tuple[TradingRuleSnapshot, ...]
    rule_policy: RulePolicy

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "snapshots",
            tuple(
                snapshot if isinstance(snapshot, TradingRuleSnapshot) else self._coerce_snapshot(snapshot)
                for snapshot in self.snapshots
            ),
        )
        try:
            policy = RulePolicy(self.rule_policy)
        except ValueError as exc:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"rule_policy: unsupported value {self.rule_policy!r}",
            ) from exc
        object.__setattr__(self, "rule_policy", policy)

    @staticmethod
    def _coerce_snapshot(snapshot: Mapping[str, object]) -> TradingRuleSnapshot:
        if not isinstance(snapshot, Mapping):
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                "trading rules: expected mapping snapshots",
            )
        required = {
            "connector_name",
            "trading_pair",
            "min_base_amount_increment",
            "min_price_increment",
            "min_order_size",
            "min_notional_size",
            "effective_from",
            "effective_to",
            "reduce_only_min_notional_exempt",
            "source",
            "captured_at",
        }
        missing = required - snapshot.keys()
        if missing:
            raise AuditedBacktestError(
                BlockingCode.INVALID_REQUEST,
                f"Missing required field: {next(iter(missing))}",
            )
        return TradingRuleSnapshot(
            connector_name=snapshot["connector_name"],
            trading_pair=snapshot["trading_pair"],
            min_base_amount_increment=snapshot["min_base_amount_increment"],
            min_price_increment=snapshot["min_price_increment"],
            min_order_size=snapshot["min_order_size"],
            min_notional_size=snapshot["min_notional_size"],
            effective_from=snapshot["effective_from"],
            effective_to=snapshot["effective_to"],
            reduce_only_min_notional_exempt=snapshot["reduce_only_min_notional_exempt"],
            source=snapshot["source"],
            captured_at=snapshot["captured_at"],
        )

    @classmethod
    def from_mapping(
        cls,
        mapping: Mapping[str, Any] | Sequence[Any],
        rule_policy: RulePolicy | str = RulePolicy.HISTORICAL_EXACT,
    ) -> "RuleBook":
        records = _snapshot_records(mapping)
        return cls(
            tuple(cls._coerce_snapshot(record) for record in records),
            rule_policy,
        )

    def _select(self, connector_name: str, trading_pair: str, timestamp: pd.Timestamp) -> tuple[TradingRuleSnapshot, ...]:
        timestamp = as_utc(timestamp, "timestamp")
        return tuple(
            snapshot
            for snapshot in self.snapshots
            if snapshot.connector_name == connector_name
            and snapshot.trading_pair == trading_pair
            and snapshot.effective_from <= timestamp <= snapshot.effective_to
        )

    def rule_at(
        self,
        connector_name: str,
        trading_pair: str,
        timestamp: pd.Timestamp,
    ) -> RuleSelection:
        connector_name = _ensure_non_empty_text(connector_name, "connector_name")
        trading_pair = _ensure_non_empty_text(trading_pair, "trading_pair")
        timestamp = as_utc(timestamp, "timestamp")

        if self.rule_policy == RulePolicy.PINNED_SNAPSHOT:
            matches = tuple(
                snapshot
                for snapshot in self.snapshots
                if snapshot.connector_name == connector_name
                and snapshot.trading_pair == trading_pair
            )
            if len(matches) != 1:
                raise AuditedBacktestError(
                    BlockingCode.TRADING_RULES_MISSING,
                    "rule coverage: exactly one pinned trading rule required",
                )
            return RuleSelection(rule=matches[0], integrity_note="NON_HISTORICAL_RULES")

        matches = self._select(connector_name, trading_pair, timestamp)
        if len(matches) != 1:
            raise AuditedBacktestError(
                BlockingCode.TRADING_RULES_MISSING,
                "rule coverage: no unique historical trading rule for timestamp",
            )
        return RuleSelection(rule=matches[0], integrity_note=None)

    @property
    def sha256(self) -> str:
        canonical_records = sorted(
            [self._canonical_record(snapshot) for snapshot in self.snapshots],
            key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":")),
        )
        payload = json.dumps(
            canonical_records,
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
        return sha256(payload).hexdigest()

    @staticmethod
    def _canonical_record(snapshot: TradingRuleSnapshot) -> Mapping[str, object]:
        return {
            "connector_name": snapshot.connector_name,
            "trading_pair": snapshot.trading_pair,
            "effective_from": _timestamp_to_string(snapshot.effective_from),
            "effective_to": _timestamp_to_string(snapshot.effective_to),
            "min_base_amount_increment": _canonical_decimal(snapshot.min_base_amount_increment),
            "min_price_increment": _canonical_decimal(snapshot.min_price_increment),
            "min_order_size": _canonical_decimal(snapshot.min_order_size),
            "min_notional_size": _canonical_decimal(snapshot.min_notional_size),
            "reduce_only_min_notional_exempt": snapshot.reduce_only_min_notional_exempt,
            "source": snapshot.source,
            "captured_at": _timestamp_to_string(snapshot.captured_at),
        }


__all__ = [
    "RuleBook",
    "RulePolicy",
    "RuleSelection",
    "QuantizedOpen",
    "TradingRuleSnapshot",
    "quantize_open",
]
