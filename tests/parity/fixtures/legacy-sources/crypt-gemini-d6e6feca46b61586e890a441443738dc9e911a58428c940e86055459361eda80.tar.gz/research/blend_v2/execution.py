"""Causal long-only execution and daily sleeve ledger."""
from __future__ import annotations

from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from typing import Iterable, Literal, Sequence

import pandas as pd

from .data import SymbolBundle
from .types import (
    CausalLongRequest,
    ClosedTrade,
    CostModel,
    IntegrityError,
    LedgerEvent,
    LongPositionSnapshot,
    LongPositionState,
    PendingLongEntry,
    SleeveResult,
)


ONE = Decimal("1")
ZERO = Decimal("0")

_EXACT_DECIMAL_MAX_DIGITS = 2048
_EXACT_DECIMAL_MAX_ABS_EXPONENT = 1024
_EXACT_DECIMAL_MAX_ABS_ADJUSTED_EXPONENT = 2048
_EXACT_DECIMAL_MAX_EXPONENT_SPAN = 1024
_EXACT_DECIMAL_MAX_RESULT_BITS = 6805

# Treated as immutable; localcontext() copies it for each cost calculation so
# ambient precision, rounding, exponent limits, flags, and traps cannot leak in.
_FIXED_COST_CONTEXT = Context(
    prec=28,
    rounding=ROUND_HALF_EVEN,
    Emin=-999999,
    Emax=999999,
    capitals=1,
    clamp=0,
    flags=[],
    traps=[],
)


def _require_exact_decimal_domain(value: Decimal, name: str) -> Decimal:
    value_tuple = value.as_tuple()
    exponent = value_tuple.exponent
    coefficient_digits = len(value_tuple.digits)
    if (
        coefficient_digits > _EXACT_DECIMAL_MAX_DIGITS
        or abs(exponent) > _EXACT_DECIMAL_MAX_ABS_EXPONENT
        or (
            coefficient_digits
            and any(value_tuple.digits)
            and abs(exponent + coefficient_digits - 1)
            > _EXACT_DECIMAL_MAX_ABS_ADJUSTED_EXPONENT
        )
    ):
        raise IntegrityError(f"{name} is outside the exact Decimal domain")
    return value


def _decimal_from_coefficient_exponent(coefficient: int, exponent: int) -> Decimal:
    try:
        if abs(exponent) > _EXACT_DECIMAL_MAX_ABS_EXPONENT:
            raise ValueError("tuple exponent outside domain")
        if coefficient == 0:
            return Decimal((0, (0,), exponent))
        if abs(coefficient).bit_length() > _EXACT_DECIMAL_MAX_RESULT_BITS:
            raise ValueError("coefficient outside domain")
        text = str(abs(coefficient))
        if (
            len(text) > _EXACT_DECIMAL_MAX_DIGITS
            or abs(exponent + len(text) - 1)
            > _EXACT_DECIMAL_MAX_ABS_ADJUSTED_EXPONENT
        ):
            raise ValueError("result outside domain")
        result = Decimal(
            (1 if coefficient < 0 else 0, tuple(int(digit) for digit in text), exponent)
        )
        if not result.is_finite():
            raise ValueError("nonfinite result")
        return result
    except (ValueError, OverflowError) as exc:
        raise IntegrityError("exact Decimal domain violation") from exc


def _decimal_coefficient_exponent(value: Decimal) -> tuple[int, int]:
    value = _require_exact_decimal_domain(value, "exact decimal operand")
    value_tuple = value.as_tuple()
    coefficient = 0
    for digit in value_tuple.digits:
        coefficient = coefficient * 10 + digit
    if value_tuple.sign:
        coefficient = -coefficient
    return coefficient, value_tuple.exponent


def _exact_decimal_sum(values: Iterable[Decimal]) -> Decimal:
    values = tuple(values)
    if any(not isinstance(value, Decimal) or not value.is_finite() for value in values):
        raise IntegrityError("exact decimal arithmetic requires finite Decimal values")
    if not values:
        return ZERO

    for value in values:
        _require_exact_decimal_domain(value, "exact decimal sum operand")
    coefficients_exponents = tuple(
        _decimal_coefficient_exponent(value) for value in values
    )
    exponents = tuple(value_exponent for _, value_exponent in coefficients_exponents)
    exponent = min(exponents)
    if max(exponents) - exponent > _EXACT_DECIMAL_MAX_EXPONENT_SPAN:
        raise IntegrityError("exact decimal sum is outside the exact Decimal domain")
    for value, (_, value_exponent) in zip(values, coefficients_exponents):
        gap = value_exponent - exponent
        if len(value.as_tuple().digits) + gap > _EXACT_DECIMAL_MAX_DIGITS:
            raise IntegrityError("exact decimal sum is outside the exact Decimal domain")
    coefficient = sum(
        value_coefficient * 10 ** (value_exponent - exponent)
        for value_coefficient, value_exponent in coefficients_exponents
    )
    return _decimal_from_coefficient_exponent(coefficient, exponent)


def _exact_decimal_product(left: Decimal, right: Decimal) -> Decimal:
    if (
        not isinstance(left, Decimal)
        or not left.is_finite()
        or not isinstance(right, Decimal)
        or not right.is_finite()
    ):
        raise IntegrityError("exact decimal arithmetic requires finite Decimal values")
    _require_exact_decimal_domain(left, "exact decimal product left operand")
    _require_exact_decimal_domain(right, "exact decimal product right operand")
    left_coefficient, left_exponent = _decimal_coefficient_exponent(left)
    right_coefficient, right_exponent = _decimal_coefficient_exponent(right)
    exponent = left_exponent + right_exponent
    if abs(exponent) > _EXACT_DECIMAL_MAX_ABS_EXPONENT:
        raise IntegrityError("exact decimal product is outside the exact Decimal domain")
    coefficient = left_coefficient * right_coefficient
    return _decimal_from_coefficient_exponent(coefficient, exponent)


def _cost_terms(
    reference_price: Decimal,
    entry_reference_price: Decimal,
    exposure: Decimal,
    fee_rate: Decimal,
    slippage_rate: Decimal,
    *,
    entry: bool,
) -> tuple[Decimal, Decimal, Decimal]:
    """Compute rounded cost terms under the stable execution arithmetic contract."""
    with localcontext(_FIXED_COST_CONTEXT):
        fill = reference_price * (ONE + slippage_rate if entry else ONE - slippage_rate)
        fee = exposure * fee_rate * fill / entry_reference_price
        price_delta = fill - reference_price if entry else reference_price - fill
        slippage = exposure * price_delta / entry_reference_price
    return fill, fee, slippage


def _decimal(value: object) -> Decimal:
    result = Decimal(str(value))
    if not result.is_finite():
        raise IntegrityError("exact decimal arithmetic requires finite Decimal values")
    return _require_exact_decimal_domain(result, "decimal value")


def _timestamp(value: object, name: str) -> pd.Timestamp:
    try:
        result = pd.to_datetime(value, utc=True)
    except (TypeError, ValueError, OverflowError) as exc:
        raise IntegrityError(f"invalid {name} timestamp") from exc
    if not isinstance(result, pd.Timestamp) or pd.isna(result):
        raise IntegrityError(f"invalid {name} timestamp")
    return result


def _utc_timestamp(value: object, name: str) -> pd.Timestamp:
    try:
        result = pd.to_datetime(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise IntegrityError(f"invalid {name} timestamp") from exc
    if not isinstance(result, pd.Timestamp) or pd.isna(result) or result.tzinfo is None:
        raise IntegrityError(f"invalid {name} timestamp")
    return result.tz_convert("UTC")


def _decimal_input(value: object, name: str, *, positive: bool = False) -> Decimal:
    if not isinstance(value, Decimal) or not value.is_finite():
        raise IntegrityError(f"{name} must be a finite Decimal")
    value = _require_exact_decimal_domain(value, name)
    if positive and value <= ZERO:
        raise IntegrityError(f"{name} must be positive")
    return value


def _cost_rate(value: object, name: str) -> Decimal:
    rate = _decimal_input(value, name)
    if rate < ZERO or rate >= ONE:
        raise IntegrityError(f"{name} must satisfy 0 <= rate < 1")
    return rate


def _is_exact_hour(ts: pd.Timestamp) -> bool:
    return (
        ts.minute == 0
        and ts.second == 0
        and ts.microsecond == 0
        and ts.nanosecond == 0
    )


def _event(
    timestamp: pd.Timestamp,
    *,
    price_pnl: Decimal = ZERO,
    fee_cost: Decimal = ZERO,
    slippage_cost: Decimal = ZERO,
    funding_pnl: Decimal = ZERO,
) -> LedgerEvent:
    return LedgerEvent(
        timestamp=timestamp,
        price_pnl=price_pnl,
        fee_cost=fee_cost,
        slippage_cost=slippage_cost,
        funding_pnl=funding_pnl,
        net_pnl=_exact_decimal_sum(
            (
                price_pnl,
                funding_pnl,
                fee_cost.copy_negate(),
                slippage_cost.copy_negate(),
            )
        ),
    )


def _validate_legacy_execute_long_call_in_original_order(
    entry: PendingLongEntry,
    bundle: SymbolBundle,
    cost: CostModel,
    planned_exit_time: pd.Timestamp,
    planned_reason: str,
) -> tuple[CausalLongRequest, pd.Timestamp, Decimal, Decimal]:
    entry_time = _timestamp(entry.execute_time, "execute_time")
    signal_time = _timestamp(entry.signal_time, "signal_time")
    exit_time = _timestamp(planned_exit_time, "planned_exit_time")

    if bundle.symbol != entry.symbol:
        raise IntegrityError(f"{entry.symbol}: entry and market-data symbols differ")
    if entry_time <= signal_time:
        raise IntegrityError(f"{entry.symbol}: execution must be after signal time")
    if exit_time < entry_time:
        raise IntegrityError(f"{entry.symbol}: planned exit precedes entry")
    if planned_reason not in ("expiry", "signal"):
        raise ValueError(f"unsupported planned exit reason: {planned_reason}")

    fee_rate = _cost_rate(cost.fee_rate, "fee_rate")
    slippage_rate = _cost_rate(cost.slippage_rate, "slippage_rate")
    _decimal_input(entry.target_exposure, "target_exposure", positive=True)

    if entry.hold_days is not None and (
        isinstance(entry.hold_days, bool)
        or not isinstance(entry.hold_days, int)
        or entry.hold_days <= 0
    ):
        raise IntegrityError("hold_days must be None or a positive non-bool int")

    if not _is_exact_hour(entry_time) or entry_time.hour not in (0, 12):
        raise IntegrityError(f"{entry.symbol}: execution must be on a 12h boundary")

    bundle.require_hourly_coverage(entry_time, exit_time)
    entry_open = _decimal(bundle.hourly.at[entry_time, "open"])
    if entry_time.hour == 0:
        if entry_time.normalize() not in bundle.daily.index:
            raise IntegrityError(f"{entry.symbol}: missing next daily open at {entry_time}")
        daily_open = _decimal(bundle.daily.at[entry_time.normalize(), "open"])
        if daily_open != entry_open:
            raise IntegrityError(f"{entry.symbol}: daily and hourly opens differ at {entry_time}")
    if not entry_open.is_finite() or entry_open <= ZERO:
        raise IntegrityError(f"{entry.symbol}: entry open must be finite and positive")
    entry_fill, _, _ = _cost_terms(
        entry_open, entry_open, entry.target_exposure, fee_rate, slippage_rate, entry=True
    )
    if not entry_fill.is_finite() or entry_fill <= ZERO:
        raise IntegrityError(f"{entry.symbol}: entry fill must be finite and positive")

    if (entry.stop_k is None) != (entry.signal_vol20 is None):
        raise IntegrityError(f"{entry.symbol}: stop_k and signal_vol20 must be supplied together")

    stop_k = None
    signal_vol20 = None
    stop_fraction: Decimal | None = None
    if entry.stop_k is not None:
        stop_k = _decimal_input(entry.stop_k, "stop_k", positive=True)
    if entry.signal_vol20 is not None:
        signal_vol20 = _decimal_input(entry.signal_vol20, "stop signal_vol20", positive=True)
    if stop_k is not None and signal_vol20 is not None:
        stop_fraction = stop_k * signal_vol20
        if not stop_fraction.is_finite() or stop_fraction <= ZERO or stop_fraction >= ONE:
            raise IntegrityError("stop fraction must satisfy 0 < stop_k * signal_vol20 < 1")

    request = CausalLongRequest(
        symbol=entry.symbol,
        decision_time=signal_time,
        execute_time=entry_time,
        target_exposure=entry.target_exposure,
        stop_fraction=stop_fraction,
    )

    if request.stop_fraction is not None:
        stop_price = entry_fill * (ONE - request.stop_fraction)
        if not stop_price.is_finite() or stop_price <= ZERO or stop_price >= entry_fill:
            raise IntegrityError(
                "computed stop must be finite, positive, and below entry fill"
            )
    return request, exit_time, fee_rate, slippage_rate


def _stop_candidate(
    state: LongPositionState,
    bar: pd.Series,
) -> tuple[Decimal | None, bool]:
    if state.stop_price is None:
        return None, False
    open_price = _decimal(bar["open"])
    if open_price <= state.stop_price:
        return open_price, True
    low = _decimal(bar["low"])
    if low <= state.stop_price:
        return state.stop_price, True
    return None, False


def _append_completed_daily_mark_if_due(
    state: LongPositionState,
    bar_open: pd.Timestamp,
    bar: pd.Series,
) -> None:
    if bar_open.hour != 23:
        return
    close_price = _decimal(bar["close"])
    if not close_price.is_finite():
        raise IntegrityError(f"{state.request.symbol}: invalid hourly close")
    state.ledger.append(
        _event(
            bar_open,
            price_pnl=state.request.target_exposure
            * (close_price - state.previous_mark)
            / state.entry_reference_price,
        )
    )
    state.previous_mark = close_price


def _append_resolved_funding_events(
    state: LongPositionState,
    bundle: SymbolBundle,
    *,
    through: pd.Timestamp,
) -> None:
    through_ts = _utc_timestamp(through, "through")
    if through_ts <= state.last_processed_funding_time:
        return
    funding_rows = bundle.funding_rows_for_interval(
        state.last_processed_funding_time,
        through_ts,
    )
    rows = funding_rows[funding_rows.index < through_ts]
    for ts, row in rows.iterrows():
        state.ledger.append(
            _event(ts, funding_pnl=-state.request.target_exposure * _decimal(row["funding_rate"]))
        )
        state.last_processed_funding_time = ts


def _finalize_long(
    state: LongPositionState,
    bundle: SymbolBundle,
    actual_exit_time: pd.Timestamp,
    actual_exit_reference: Decimal,
    actual_exit_reason: Literal["stop", "expiry", "signal", "controller"],
) -> ClosedTrade:
    if state.closed_trade is not None:
        return state.closed_trade
    if actual_exit_reference is None:
        raise IntegrityError(f"{state.request.symbol}: exit reference missing")
    if not _is_exact_hour(actual_exit_time):
        raise IntegrityError(f"{state.request.symbol}: final exit must be an exact hourly open")

    funding_rows = bundle.funding_rows_for_interval(
        state.request.execute_time,
        actual_exit_time,
    )
    for ts, row in funding_rows.loc[funding_rows.index < actual_exit_time].iterrows():
        if ts <= state.last_processed_funding_time:
            continue
        state.ledger.append(
            _event(ts, funding_pnl=-state.request.target_exposure * _decimal(row["funding_rate"]))
        )
        state.last_processed_funding_time = ts

    exit_fill, exit_fee, exit_slippage = _cost_terms(
        actual_exit_reference,
        state.entry_reference_price,
        state.request.target_exposure,
        state.cost_model.fee_rate,
        state.cost_model.slippage_rate,
        entry=False,
    )
    state.ledger.append(
        _event(
            actual_exit_time,
            price_pnl=state.request.target_exposure * (actual_exit_reference - state.previous_mark)
            / state.entry_reference_price,
            fee_cost=exit_fee,
            slippage_cost=exit_slippage,
        )
    )
    for ts, row in funding_rows.loc[funding_rows.index == actual_exit_time].iterrows():
        if ts <= state.last_processed_funding_time:
            continue
        state.ledger.append(
            _event(ts, funding_pnl=-state.request.target_exposure * _decimal(row["funding_rate"]))
        )
        state.last_processed_funding_time = ts

    gross_pnl = _exact_decimal_sum(event.price_pnl for event in state.ledger)
    fee_cost = _exact_decimal_sum(event.fee_cost for event in state.ledger)
    slippage_cost = _exact_decimal_sum(event.slippage_cost for event in state.ledger)
    funding_pnl = _exact_decimal_sum(event.funding_pnl for event in state.ledger)
    net_pnl = _exact_decimal_sum(event.net_pnl for event in state.ledger)

    state.closed_trade = ClosedTrade(
        symbol=state.request.symbol,
        entry_time=state.request.execute_time,
        exit_time=actual_exit_time,
        entry_price=state.entry_fill_price,
        exit_price=exit_fill,
        entry_reference_price=state.entry_reference_price,
        exit_reference_price=actual_exit_reference,
        exposure=state.request.target_exposure,
        gross_pnl=gross_pnl,
        fee_cost=fee_cost,
        slippage_cost=slippage_cost,
        funding_pnl=funding_pnl,
        net_pnl=net_pnl,
        exit_reason=actual_exit_reason,
        ledger=tuple(state.ledger),
        cost_model=state.cost_model,
    )
    return state.closed_trade


def _finalize_scheduled_open_with_pessimistic_same_bucket_stop(
    state: LongPositionState,
    bundle: SymbolBundle,
) -> ClosedTrade:
    scheduled_open = state.scheduled_exit_time
    if scheduled_open is None:
        raise IntegrityError(f"{state.request.symbol}: no scheduled exit")
    if scheduled_open not in bundle.hourly.index:
        raise IntegrityError(f"{state.request.symbol}: missing hourly coverage at {scheduled_open}")

    row = bundle.hourly.loc[scheduled_open]
    exit_reference, exit_triggered = _stop_candidate(state, row)
    if exit_reference is None:
        exit_reference = _decimal(row["open"])
    exit_reason: Literal["stop", "expiry", "signal", "controller"]
    if exit_triggered:
        exit_reason = "stop"
    else:
        exit_reason = (
            state.scheduled_exit_reason
            if state.scheduled_exit_reason is not None
            else "expiry"
        )
    return _finalize_long(state, bundle, scheduled_open, exit_reference, exit_reason)


def _advance_to(
    state: LongPositionState,
    bundle: SymbolBundle,
    through: pd.Timestamp,
    *,
    finalize: bool = True,
) -> ClosedTrade | None:
    through_ts = _utc_timestamp(through, "through")
    if bundle.symbol != state.request.symbol:
        raise IntegrityError(f"{state.request.symbol}: entry and market-data symbols differ")
    if through_ts < state.request.execute_time:
        raise IntegrityError(f"{state.request.symbol}: progress must be at/after entry")
    if state.closed_trade is not None:
        return state.closed_trade if through_ts >= state.closed_trade.exit_time else state.closed_trade

    first_complete = (
        state.request.execute_time
        if state.last_processed_bar_open is None
        else state.last_processed_bar_open + pd.Timedelta(hours=1)
    )
    last_complete = through_ts.floor("1h") - pd.Timedelta(hours=1)
    if state.scheduled_exit_time is not None and state.scheduled_exit_time <= through_ts:
        last_complete = min(last_complete, state.scheduled_exit_time - pd.Timedelta(hours=1))

    if first_complete <= last_complete:
        for bar_open in pd.date_range(first_complete, last_complete, freq="1h"):
            if bar_open not in bundle.hourly.index:
                raise IntegrityError(
                    f"{state.request.symbol}: missing hourly coverage at {bar_open}"
                )
            bar = bundle.hourly.loc[bar_open]
            stop_reference, _ = _stop_candidate(state, bar)
            if stop_reference is None:
                _append_completed_daily_mark_if_due(state, bar_open, bar)
            if stop_reference is not None:
                return _finalize_long(state, bundle, bar_open, stop_reference, "stop")
            _append_resolved_funding_events(
                state,
                bundle,
                through=bar_open + pd.Timedelta(hours=1),
            )
            state.last_processed_bar_open = bar_open

    if state.scheduled_exit_time is not None and state.scheduled_exit_time <= through_ts and finalize:
        return _finalize_scheduled_open_with_pessimistic_same_bucket_stop(state, bundle)
    return None


def open_long(
    request: CausalLongRequest,
    bundle: SymbolBundle,
    cost: CostModel,
) -> LongPositionState:
    entry_time = _timestamp(request.execute_time, "execute_time")
    decision_time = _timestamp(request.decision_time, "decision_time")
    if bundle.symbol != request.symbol:
        raise IntegrityError(f"{request.symbol}: entry and market-data symbols differ")
    if decision_time >= entry_time:
        raise IntegrityError(f"{request.symbol}: execution must be after signal time")
    if not _is_exact_hour(entry_time):
        raise IntegrityError(f"{request.symbol}: execution must be on an exact hourly boundary")
    fee_rate = _cost_rate(cost.fee_rate, "fee_rate")
    slippage_rate = _cost_rate(cost.slippage_rate, "slippage_rate")
    exposure = _decimal_input(request.target_exposure, "target_exposure", positive=True)
    stop_fraction = request.stop_fraction

    if not stop_fraction is None:
        stop_fraction = _decimal_input(stop_fraction, "stop_fraction", positive=True)
        if stop_fraction >= ONE:
            raise IntegrityError("stop fraction must satisfy 0 < stop_fraction < 1")

    if entry_time not in bundle.hourly.index:
        raise IntegrityError(f"{request.symbol}: missing hourly coverage at {entry_time}")
    entry_open = _decimal(bundle.hourly.at[entry_time, "open"])
    if not entry_open.is_finite() or entry_open <= ZERO:
        raise IntegrityError(f"{request.symbol}: entry open must be finite and positive")
    if entry_time.hour == 0:
        if entry_time.normalize() not in bundle.daily.index:
            raise IntegrityError(f"{request.symbol}: missing next daily open at {entry_time}")
        daily_open = _decimal(bundle.daily.at[entry_time.normalize(), "open"])
        if daily_open != entry_open:
            raise IntegrityError(
                f"{request.symbol}: daily and hourly opens differ at {entry_time}"
            )

    entry_fill, entry_fee, entry_slippage = _cost_terms(
        entry_open, entry_open, exposure, fee_rate, slippage_rate, entry=True
    )
    if not entry_fill.is_finite() or entry_fill <= ZERO:
        raise IntegrityError(f"{request.symbol}: entry fill must be finite and positive")
    stop_price: Decimal | None = None
    if stop_fraction is not None:
        stop_price = entry_fill * (ONE - stop_fraction)
        if not stop_price.is_finite() or stop_price <= ZERO or stop_price >= entry_fill:
            raise IntegrityError("computed stop must be finite, positive, and below entry fill")
    return LongPositionState(
        request=CausalLongRequest(
            symbol=request.symbol,
            decision_time=decision_time,
            execute_time=entry_time,
            target_exposure=exposure,
            stop_fraction=stop_fraction,
        ),
        cost_model=CostModel(fee_rate=fee_rate, slippage_rate=slippage_rate),
        entry_reference_price=entry_open,
        entry_fill_price=entry_fill,
        stop_price=stop_price,
        previous_mark=entry_open,
        last_processed_bar_open=None,
        last_processed_funding_time=entry_time,
        scheduled_exit_time=None,
        scheduled_exit_reason=None,
        ledger=[
            _event(
                entry_time,
                fee_cost=entry_fee,
                slippage_cost=entry_slippage,
            )
        ],
    )


def schedule_long_exit(
    state: LongPositionState,
    exit_time: pd.Timestamp,
    reason: Literal["expiry", "signal", "controller"],
) -> None:
    requested_exit = _timestamp(exit_time, "planned_exit_time")
    if not _is_exact_hour(requested_exit):
        raise IntegrityError(f"{state.request.symbol}: scheduled exit must be an exact hourly boundary")
    if requested_exit < state.request.execute_time:
        raise IntegrityError(f"{state.request.symbol}: scheduled exit precedes entry")
    if reason not in ("expiry", "signal", "controller"):
        raise IntegrityError(f"{state.request.symbol}: unsupported scheduled exit reason: {reason}")

    if state.scheduled_exit_time is None or requested_exit < state.scheduled_exit_time:
        state.scheduled_exit_time = requested_exit
        state.scheduled_exit_reason = reason


def advance_long(
    state: LongPositionState,
    bundle: SymbolBundle,
    through: pd.Timestamp,
) -> ClosedTrade | None:
    return _advance_to(state, bundle, through=through, finalize=True)


def snapshot_long(
    state: LongPositionState,
    bundle: SymbolBundle,
    at: pd.Timestamp,
) -> LongPositionSnapshot:
    snapshot_time = _utc_timestamp(at, "at")
    if snapshot_time < state.request.execute_time:
        raise IntegrityError(f"{state.request.symbol}: snapshot time precedes entry")
    if bundle.symbol != state.request.symbol:
        raise IntegrityError(f"{state.request.symbol}: entry and market-data symbols differ")
    if state.closed_trade is not None and snapshot_time >= state.closed_trade.exit_time:
        trade = state.closed_trade
        return LongPositionSnapshot(
            timestamp=snapshot_time,
            is_active=False,
            net_pnl=trade.net_pnl,
            gross_pnl=trade.gross_pnl,
            fee_cost=trade.fee_cost,
            slippage_cost=trade.slippage_cost,
            funding_pnl=trade.funding_pnl,
        )

    last_complete_open = snapshot_time.floor("1h") - pd.Timedelta(hours=1)
    if last_complete_open >= state.request.execute_time:
        bundle.require_hourly_coverage(
            state.request.execute_time,
            last_complete_open,
        )
        if last_complete_open not in bundle.hourly.index:
            raise IntegrityError(f"{state.request.symbol}: missing hourly coverage at {last_complete_open}")
        reference_price = _decimal(bundle.hourly.at[last_complete_open, "close"])
        if not reference_price.is_finite() or reference_price <= ZERO:
            raise IntegrityError(f"{state.request.symbol}: invalid hourly close")
    else:
        reference_price = state.entry_reference_price

    gross_pnl = state.request.target_exposure * (
        reference_price - state.entry_reference_price
    ) / state.entry_reference_price
    fee_cost = ZERO
    slippage_cost = ZERO
    funding_pnl = ZERO
    complete_cutoff = snapshot_time
    for event in state.ledger:
        if event.timestamp > snapshot_time:
            continue
        fee_cost += event.fee_cost
        slippage_cost += event.slippage_cost
        if event.timestamp.floor("1h") + pd.Timedelta(hours=1) <= complete_cutoff:
            funding_pnl += event.funding_pnl
    net_pnl = gross_pnl + funding_pnl - fee_cost - slippage_cost

    return LongPositionSnapshot(
        timestamp=snapshot_time,
        is_active=True,
        net_pnl=net_pnl,
        gross_pnl=gross_pnl,
        fee_cost=fee_cost,
        slippage_cost=slippage_cost,
        funding_pnl=funding_pnl,
    )


def _find_planned_stop_before_time(
    state: LongPositionState,
    bundle: SymbolBundle,
    planned_exit_time: pd.Timestamp,
) -> pd.Timestamp | None:
    if state.stop_price is None:
        return None
    stop_scan_end = planned_exit_time.floor("1h")
    for bar_open in pd.date_range(state.request.execute_time, stop_scan_end, freq="1h"):
        bar = bundle.hourly.loc[bar_open]
        stop_reference, _ = _stop_candidate(state, bar)
        if stop_reference is not None:
            return bar_open
    return None


def execute_long(
    entry: PendingLongEntry,
    bundle: SymbolBundle,
    cost: CostModel,
    planned_exit_time: pd.Timestamp,
    *,
    planned_reason: Literal["expiry", "signal"] = "expiry",
) -> ClosedTrade:
    """Execute one long using only opens and fully known funding."""
    request, planned_exit_time, fee_rate, slippage_rate = (
        _validate_legacy_execute_long_call_in_original_order(
            entry, bundle, cost, planned_exit_time, planned_reason,
        )
    )
    state = open_long(request, bundle, CostModel(fee_rate=fee_rate, slippage_rate=slippage_rate))
    if not _is_exact_hour(planned_exit_time):
        stop_open = _find_planned_stop_before_time(state, bundle, planned_exit_time)
        if stop_open is None:
            raise IntegrityError(f"{entry.symbol}: planned exit was not executable")
        trade = advance_long(state, bundle, through=stop_open + pd.Timedelta(hours=1))
        if trade is None:
            raise IntegrityError(f"{entry.symbol}: planned exit was not executable")
        return trade

    schedule_long_exit(state, planned_exit_time, planned_reason)
    trade = advance_long(state, bundle, through=planned_exit_time)
    if trade is None:
        raise IntegrityError(f"{entry.symbol}: planned exit was not executable")
    return trade


def trades_to_sleeve_result(
    trades: Iterable[ClosedTrade],
    calendar: pd.DatetimeIndex,
    symbols: Sequence[str],
    cost_model: CostModel | None = None,
) -> SleeveResult:
    """Aggregate immutable trade ledger events by UTC day."""
    ordered_trades = tuple(trades)
    if cost_model is None:
        cost_model = (ordered_trades[0].cost_model if ordered_trades
                      else CostModel(Decimal("0"), Decimal("0")))
    dates = pd.DatetimeIndex(pd.to_datetime(calendar, utc=True))
    if dates.tz is None or str(dates.tz) != "UTC" or not dates.equals(dates.normalize()):
        raise IntegrityError("sleeve calendar must be exact UTC midnight")
    if dates.has_duplicates or not dates.is_monotonic_increasing:
        raise IntegrityError("sleeve calendar must be unique and increasing")
    if len(dates) > 1 and not dates.equals(pd.date_range(dates[0], dates[-1], freq="1D", tz="UTC")):
        raise IntegrityError("sleeve calendar must be continuous daily")
    symbol_list = list(symbols)
    if (
        any(not isinstance(symbol, str) or not symbol.strip() for symbol in symbol_list)
        or len(set(symbol_list)) != len(symbol_list)
    ):
        raise IntegrityError("sleeve symbols must be unique non-empty strings")
    positions = pd.DataFrame(0.0, index=dates, columns=symbol_list)
    returns = pd.Series(0.0, index=dates, name="returns")
    fee_cost = pd.Series(0.0, index=dates, name="fee_cost")
    slippage_cost = pd.Series(0.0, index=dates, name="slippage_cost")
    funding_pnl = pd.Series(0.0, index=dates, name="funding_pnl")

    for trade in ordered_trades:
        if trade.cost_model != cost_model:
            raise IntegrityError("trade cost model differs from sleeve cost model")
        if trade.symbol not in positions.columns:
            raise IntegrityError(f"{trade.symbol}: trade symbol absent from sleeve symbols")
        entry_day = pd.to_datetime(trade.entry_time, utc=True).normalize()
        exit_day = pd.to_datetime(trade.exit_time, utc=True).normalize()
        if entry_day not in dates or exit_day not in dates:
            raise IntegrityError(f"{trade.symbol}: trade lies outside sleeve calendar")
        for day in dates:
            next_day = day + pd.Timedelta("1D")
            if trade.entry_time < next_day and trade.exit_time >= next_day:
                positions.loc[day, trade.symbol] += float(trade.exposure)
        for event in trade.ledger:
            event_day = pd.to_datetime(event.timestamp, utc=True).normalize()
            if event_day not in dates:
                raise IntegrityError(f"{trade.symbol}: ledger event lies outside sleeve calendar")
            returns.loc[event_day] += float(event.net_pnl)
            fee_cost.loc[event_day] += float(event.fee_cost)
            slippage_cost.loc[event_day] += float(event.slippage_cost)
            funding_pnl.loc[event_day] += float(event.funding_pnl)

    return SleeveResult(
        returns=returns,
        positions=positions,
        trades=ordered_trades,
        fee_cost=fee_cost,
        slippage_cost=slippage_cost,
        funding_pnl=funding_pnl,
        integrity_findings=(),
        cost_model=cost_model,
    )
