from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any
import csv
import heapq
import io
import json
import re
import shutil
import zipfile

from .contracts import (
    BookTicker,
    DataIntegrityError,
    DateWindow,
    DownloadReceipt,
    FundingPageReceipt,
    FundingRate,
    ManifestFile,
    MarketManifest,
    RawBundleReceipt,
    VerifiedBundle,
    canonical_sha256,
)
from .fetch import KINDS
from .exchange_rules import load_exchange_rule_snapshot
from .partitioned_bundle import write_jsonl_partition
from ..microstructure.events import TradePrint

DECIMAL_RE = re.compile(r"^-?(?:0|[1-9]\d*)(?:\.\d+)?$")
INT_RE = re.compile(r"^(?:0|[1-9]\d*)$")

DATA_L1_SYMBOL = "ETHUSDT"
DATA_L1_TRADE_SYMBOL = "ETH-USDT"
DATA_L1_AUTHORIZE_FLAGS = MappingProxyType(
    {
        "decision_grade_eligible": False,
        "paper_trading_authorized": False,
        "live_trading_authorized": False,
    }
)
LEGACY_SCHEMA_VERSION = 1
SCHEMA_VERSION = 2

MAX_BOOK_AGE_MS = 5_000
MAX_JOINT_SILENCE_MS = 60_000

BOOK_TICKER_FIELDS = (
    "update_id",
    "best_bid_price",
    "best_bid_qty",
    "best_ask_price",
    "best_ask_qty",
    "transaction_time_ms",
    "event_time_ms",
)

AGG_TRADE_FIELDS = (
    "sequence",
    "price",
    "quantity",
    "first_trade_id",
    "last_trade_id",
    "event_time_ms",
    "buyer_is_maker",
)

BOOK_TICKER_HEADER_ALIASES = {
    "updateid": "update_id",
    "update_id": "update_id",
    "bestbidprice": "best_bid_price",
    "bestbidqty": "best_bid_qty",
    "bestaskprice": "best_ask_price",
    "bestaskqty": "best_ask_qty",
    "transactiontime": "transaction_time_ms",
    "eventtime": "event_time_ms",
    "event_time_ms": "event_time_ms",
    "transaction_time_ms": "transaction_time_ms",
}

AGG_TRADE_HEADER_ALIASES = {
    "aggtradeid": "sequence",
    "aggregate_trade_id": "sequence",
    "agg_trade_id": "sequence",
    "price": "price",
    "quantity": "quantity",
    "firsttradeid": "first_trade_id",
    "first_underlying_trade_id": "first_trade_id",
    "lasttradeid": "last_trade_id",
    "last_underlying_trade_id": "last_trade_id",
    "timestamp": "event_time_ms",
    "transacttime": "event_time_ms",
    "isbuyermaker": "buyer_is_maker",
    "istrademaker": "buyer_is_maker",
}


@dataclass(frozen=True)
class _BookRecord:
    update_id: int
    event_time_ms: int
    transaction_time_ms: int
    best_bid_price: Decimal
    best_bid_qty: Decimal
    best_ask_price: Decimal
    best_ask_qty: Decimal
    best_bid_price_text: str
    best_bid_qty_text: str
    best_ask_price_text: str
    best_ask_qty_text: str
    source_line: int
    source_fields: tuple[str, ...]


@dataclass(frozen=True)
class _AggRecord:
    sequence: int
    event_time_ms: int
    first_trade_id: int
    last_trade_id: int
    price: Decimal
    quantity: Decimal
    buyer_is_maker: bool
    price_text: str
    quantity_text: str
    source_line: int
    source_fields: tuple[str, ...]


def _canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _to_epoch_ms(day: date, endpoint: str) -> int:
    start = datetime.combine(day, datetime.min.time(), tzinfo=timezone.utc)
    if endpoint == "start":
        return int(start.timestamp() * 1000)
    if endpoint == "end":
        end = start + timedelta(days=1) - timedelta(milliseconds=1)
        return int(end.timestamp() * 1000)
    raise ValueError(f"unknown endpoint: {endpoint}")


def _iter_days(window: DateWindow) -> Iterable[date]:
    current = window.start_date
    while current <= window.end_date:
        yield current
        current += timedelta(days=1)


def _validate_int(value: object, label: str) -> int:
    text = value if isinstance(value, str) else str(value)
    text = text.strip()
    if not text:
        raise DataIntegrityError(f"{label}: empty integer")
    if not INT_RE.fullmatch(text):
        raise DataIntegrityError(f"{label}: invalid integer")
    return int(text)


def _validate_positive_int(value: object, label: str) -> int:
    value_int = _validate_int(value, label)
    if value_int < 0:
        raise DataIntegrityError(f"{label}: invalid integer")
    return value_int


def _validate_decimal(value: object, label: str, *, allow_zero: bool = False) -> tuple[Decimal, str]:
    text = value if isinstance(value, str) else str(value)
    if isinstance(value, float):
        raise DataIntegrityError(f"{label}: decimal must be serialized as string")
    text = text.strip()
    if not text:
        raise DataIntegrityError(f"{label}: empty decimal")
    if not DECIMAL_RE.fullmatch(text):
        raise DataIntegrityError(f"{label}: invalid decimal")
    number = Decimal(text)
    if not number.is_finite():
        raise DataIntegrityError(f"{label}: invalid decimal")
    if not allow_zero and number <= 0:
        raise DataIntegrityError(f"{label}: invalid decimal")
    return number, text


def _normalize_header(cell: str, aliases: dict[str, str]) -> str | None:
    normalized = re.sub(r"[^0-9a-z]", "", cell.lower())
    return aliases.get(normalized)


def _parse_header_row(fields: list[str], aliases: dict[str, str], expected: tuple[str, ...], kind: str) -> list[str]:
    if len(fields) != len(expected):
        raise DataIntegrityError(f"{kind} header must include seven columns")
    normalized = [_normalize_header(field, aliases) for field in fields]
    if any(item is None for item in normalized):
        raise DataIntegrityError(f"{kind} header has unsupported columns")
    if sorted(normalized) != sorted(expected):
        raise DataIntegrityError(f"{kind} header missing required columns")
    return normalized


def _row_is_header(row: tuple[str, ...], aliases: dict[str, str], expected: tuple[str, ...], kind: str) -> bool:
    has_alpha = any(re.search(r"[a-zA-Z]", cell) for cell in row)
    if not has_alpha:
        return False
    normalized = [_normalize_header(cell, aliases) for cell in row]
    if any(item is None for item in normalized):
        if any(INT_RE.fullmatch(value) for value in row):
            return False
        raise DataIntegrityError(f"malformed {kind} header")
    if sorted(normalized) != sorted(expected):
        raise DataIntegrityError(f"{kind} header missing required columns")
    return True


def _read_csv_rows(lines: Iterable[str]) -> Iterator[tuple[int, tuple[str, ...]]]:
    for line_no, row in enumerate(csv.reader(lines), 1):
        values = tuple(cell.strip() for cell in row)
        if not values or all(not cell for cell in values):
            continue
        if len(values) != 7:
            raise DataIntegrityError(f"expected 7 columns, got {len(values)}")
        yield line_no, values


def _read_csv_file_rows(path: Path) -> Iterator[tuple[int, tuple[str, ...]]]:
    try:
        with path.open("r", encoding="utf-8", newline="") as handle:
            yield from _read_csv_rows(handle)
    except UnicodeDecodeError as exc:
        raise DataIntegrityError(f"malformed csv file: {path}") from exc


def _read_zip_csv_rows(path: Path) -> Iterator[tuple[int, tuple[str, ...]]]:
    if not path.exists():
        raise DataIntegrityError(f"missing archive: {path}")

    try:
        archive = zipfile.ZipFile(path, "r")
    except zipfile.BadZipFile as exc:
        raise DataIntegrityError(f"bad zip file: {path}") from exc

    with archive:
        entries = [entry for entry in archive.infolist() if not entry.is_dir()]
        if len(entries) != 1:
            raise DataIntegrityError("ambiguous zip members")

        info = entries[0]
        if info.filename.startswith("/") or info.filename.startswith("."):
            raise DataIntegrityError("path traversal")
        if ".." in info.filename.split("/"):
            raise DataIntegrityError("path traversal")
        if "\\" in info.filename:
            raise DataIntegrityError("path traversal")
        if info.flag_bits & 0x1:
            raise DataIntegrityError("encrypted zip entry")

        try:
            with archive.open(info, "r") as raw:
                with io.TextIOWrapper(raw, encoding="utf-8", newline="") as reader:
                    yield from _read_csv_rows(reader)
        except UnicodeDecodeError as exc:
            raise DataIntegrityError(f"malformed csv file in zip: {path}") from exc


def _safe_relpath(root: Path, target: Path) -> str:
    root_resolved = root.resolve()
    target_resolved = target.resolve()
    if not target_resolved.is_relative_to(root_resolved):
        raise DataIntegrityError("path is outside bundle")
    relative = target_resolved.relative_to(root_resolved)
    return str(relative.as_posix())


def _copy_file_into_bundle(source: Path, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    source_resolved = source.resolve()
    if destination.exists() and destination.resolve() == source_resolved:
        return destination
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    try:
        with source.open("rb") as source_handle:
            with temporary.open("wb") as destination_handle:
                shutil.copyfileobj(source_handle, destination_handle, length=1024 * 1024)
        temporary.replace(destination)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return destination


def _parse_book_fields(values: dict[str, str], source_line: int) -> _BookRecord:
    update_id = _validate_positive_int(values["update_id"], f"bookTicker line {source_line} update_id")
    event_time_ms = _validate_int(values["event_time_ms"], f"bookTicker line {source_line} event_time")
    transaction_time_ms = _validate_int(values["transaction_time_ms"], f"bookTicker line {source_line} transaction_time")

    bid_price, bid_price_text = _validate_decimal(values["best_bid_price"], f"bookTicker line {source_line} best_bid_price")
    bid_qty, bid_qty_text = _validate_decimal(values["best_bid_qty"], f"bookTicker line {source_line} best_bid_qty")
    ask_price, ask_price_text = _validate_decimal(values["best_ask_price"], f"bookTicker line {source_line} best_ask_price")
    ask_qty, ask_qty_text = _validate_decimal(values["best_ask_qty"], f"bookTicker line {source_line} best_ask_qty")
    if bid_price > ask_price:
        raise DataIntegrityError(f"crossed book at line {source_line}")

    source_fields = (
        str(update_id),
        bid_price_text,
        bid_qty_text,
        ask_price_text,
        ask_qty_text,
        str(transaction_time_ms),
        str(event_time_ms),
    )
    return _BookRecord(
        update_id=update_id,
        event_time_ms=event_time_ms,
        transaction_time_ms=transaction_time_ms,
        best_bid_price=bid_price,
        best_bid_qty=bid_qty,
        best_ask_price=ask_price,
        best_ask_qty=ask_qty,
        best_bid_price_text=bid_price_text,
        best_bid_qty_text=bid_qty_text,
        best_ask_price_text=ask_price_text,
        best_ask_qty_text=ask_qty_text,
        source_line=source_line,
        source_fields=source_fields,
    )


def _parse_agg_fields(values: dict[str, str], source_line: int) -> _AggRecord:
    sequence = _validate_positive_int(values["sequence"], f"aggTrade line {source_line} aggregate_trade_id")
    first_trade_id = _validate_int(values["first_trade_id"], f"aggTrade line {source_line} first_trade_id")
    last_trade_id = _validate_int(values["last_trade_id"], f"aggTrade line {source_line} last_trade_id")
    if last_trade_id < first_trade_id:
        raise DataIntegrityError(f"aggTrade line {source_line}: last trade id before first")

    event_time_ms = _validate_int(values["event_time_ms"], f"aggTrade line {source_line} event_time")
    price, price_text = _validate_decimal(values["price"], f"aggTrade line {source_line} price")
    quantity, quantity_text = _validate_decimal(values["quantity"], f"aggTrade line {source_line} quantity")

    raw_bool = values["buyer_is_maker"].strip().lower()
    if raw_bool in {"1", "true", "t", "yes", "y"}:
        buyer_is_maker = True
    elif raw_bool in {"0", "false", "f", "no", "n"}:
        buyer_is_maker = False
    else:
        raise DataIntegrityError(f"aggTrade line {source_line}: invalid buyer_is_maker")

    source_fields = (
        str(sequence),
        price_text,
        quantity_text,
        str(first_trade_id),
        str(last_trade_id),
        str(event_time_ms),
        "true" if buyer_is_maker else "false",
    )

    return _AggRecord(
        sequence=sequence,
        event_time_ms=event_time_ms,
        first_trade_id=first_trade_id,
        last_trade_id=last_trade_id,
        price=price,
        quantity=quantity,
        buyer_is_maker=buyer_is_maker,
        price_text=price_text,
        quantity_text=quantity_text,
        source_line=source_line,
        source_fields=source_fields,
    )


def _parse_agg_bool(value: object, label: str) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"1", "true", "t", "yes", "y"}:
        return True
    if text in {"0", "false", "f", "no", "n"}:
        return False
    raise DataIntegrityError(f"{label}: invalid buyer_is_maker")


def _parse_normalized_book_row(row: Mapping[str, object], source_line: int) -> _BookRecord:
    return _parse_book_fields(
        {
            "update_id": row.get("update_id"),
            "event_time_ms": row.get("event_time_ms"),
            "transaction_time_ms": row.get("transaction_time_ms"),
            "best_bid_price": row.get("best_bid_price"),
            "best_bid_qty": row.get("best_bid_qty"),
            "best_ask_price": row.get("best_ask_price"),
            "best_ask_qty": row.get("best_ask_qty"),
        }, source_line)


def _parse_normalized_agg_row(row: Mapping[str, object], source_line: int) -> _AggRecord:
    sequence = _validate_positive_int(row.get("sequence"), f"aggTrade line {source_line} aggregate_trade_id")
    first_trade_id = _validate_int(row.get("first_trade_id"), f"aggTrade line {source_line} first_trade_id")
    last_trade_id = _validate_int(row.get("last_trade_id"), f"aggTrade line {source_line} last_trade_id")
    if last_trade_id < first_trade_id:
        raise DataIntegrityError(f"aggTrade line {source_line}: last trade id before first")

    event_time_ms = _validate_int(row.get("event_time_ms"), f"aggTrade line {source_line} event_time")
    price, price_text = _validate_decimal(row.get("price"), f"aggTrade line {source_line} price")
    quantity, quantity_text = _validate_decimal(row.get("quantity"), f"aggTrade line {source_line} quantity")
    buyer_is_maker = _parse_agg_bool(row.get("buyer_is_maker"), f"aggTrade line {source_line} buyer_is_maker")

    return _AggRecord(
        sequence=sequence,
        event_time_ms=event_time_ms,
        first_trade_id=first_trade_id,
        last_trade_id=last_trade_id,
        price=price,
        quantity=quantity,
        buyer_is_maker=buyer_is_maker,
        price_text=price_text,
        quantity_text=quantity_text,
        source_line=source_line,
        source_fields=(str(sequence), price_text, quantity_text, str(first_trade_id), str(last_trade_id), str(event_time_ms), "true" if buyer_is_maker else "false"),
    )


def _parse_book_rows_from_csv(rows: Iterable[tuple[int, tuple[str, ...]]]) -> Iterator[_BookRecord]:
    iterator = iter(rows)
    first = next(iterator, None)
    if first is None:
        raise DataIntegrityError("empty bookTicker file")

    first_line, first_fields = first
    if _row_is_header(first_fields, BOOK_TICKER_HEADER_ALIASES, BOOK_TICKER_FIELDS, "bookTicker"):
        headers = _parse_header_row(list(first_fields), BOOK_TICKER_HEADER_ALIASES, BOOK_TICKER_FIELDS, "bookTicker")
    else:
        headers = list(BOOK_TICKER_FIELDS)
        yield _parse_book_fields(dict(zip(headers, first_fields)), first_line)

    for line_no, fields in iterator:
        yield _parse_book_fields(dict(zip(headers, fields)), line_no)


def _parse_agg_rows_from_csv(rows: Iterable[tuple[int, tuple[str, ...]]]) -> Iterator[_AggRecord]:
    iterator = iter(rows)
    first = next(iterator, None)
    if first is None:
        raise DataIntegrityError("empty aggTrade file")

    first_line, first_fields = first
    if _row_is_header(first_fields, AGG_TRADE_HEADER_ALIASES, AGG_TRADE_FIELDS, "aggTrade"):
        headers = _parse_header_row(list(first_fields), AGG_TRADE_HEADER_ALIASES, AGG_TRADE_FIELDS, "aggTrade")
    else:
        headers = list(AGG_TRADE_FIELDS)
        yield _parse_agg_fields(dict(zip(headers, first_fields)), first_line)

    for line_no, fields in iterator:
        yield _parse_agg_fields(dict(zip(headers, fields)), line_no)


def parse_book_ticker_rows(path: str | Path) -> Iterator[BookTicker]:
    for record in _parse_book_rows_from_csv(_read_csv_file_rows(Path(path))):
        yield BookTicker(
            update_id=record.update_id,
            event_time_ms=record.event_time_ms,
            transaction_time_ms=record.transaction_time_ms,
            bid_price=record.best_bid_price,
            bid_quantity=record.best_bid_qty,
            ask_price=record.best_ask_price,
            ask_quantity=record.best_ask_qty,
        )


def parse_agg_trade_rows(path: str | Path) -> Iterator[TradePrint]:
    for record in _parse_agg_rows_from_csv(_read_csv_file_rows(Path(path))):
        yield TradePrint(
            venue="binance",
            market="perpetual",
            symbol=DATA_L1_TRADE_SYMBOL,
            event_time_ms=record.event_time_ms,
            receive_time_ms=record.event_time_ms,
            sequence=record.sequence,
            price=record.price,
            quantity=record.quantity,
            buyer_is_maker=record.buyer_is_maker,
        )


def _dedupe_book(records: Iterable[_BookRecord]) -> tuple[int, dict[str, int], list[_BookRecord]]:
    seen: dict[int, tuple[str, ...]] = {}
    duplicate_counts: dict[str, int] = {}
    exact_duplicates = 0
    cleaned: list[_BookRecord] = []
    previous_update_id: int | None = None

    for item in records:
        if previous_update_id is not None and item.update_id < previous_update_id:
            raise DataIntegrityError("identifier regressed")
        previous_update_id = item.update_id

        signature = item.source_fields
        signature_key = "/".join(signature)
        signature_hash = sha256(signature_key.encode("utf-8")).hexdigest()

        if item.update_id in seen:
            if seen[item.update_id] == signature:
                exact_duplicates += 1
                duplicate_counts[signature_hash] = duplicate_counts.get(signature_hash, 0) + 1
                continue
            raise DataIntegrityError("conflicting duplicate")

        seen[item.update_id] = signature
        cleaned.append(item)

    return exact_duplicates, duplicate_counts, cleaned


def _dedupe_agg(records: Iterable[_AggRecord]) -> tuple[int, dict[str, int], list[_AggRecord]]:
    seen: dict[int, tuple[str, ...]] = {}
    duplicate_counts: dict[str, int] = {}
    exact_duplicates = 0
    cleaned: list[_AggRecord] = []
    previous_sequence: int | None = None

    for item in records:
        if previous_sequence is not None and item.sequence < previous_sequence:
            raise DataIntegrityError("identifier regressed")
        previous_sequence = item.sequence

        signature = item.source_fields
        signature_key = "/".join(signature)
        signature_hash = sha256(signature_key.encode("utf-8")).hexdigest()

        if item.sequence in seen:
            if seen[item.sequence] == signature:
                exact_duplicates += 1
                duplicate_counts[signature_hash] = duplicate_counts.get(signature_hash, 0) + 1
                continue
            raise DataIntegrityError("conflicting duplicate")

        seen[item.sequence] = signature
        cleaned.append(item)

    return exact_duplicates, duplicate_counts, cleaned


def parse_funding_pages(pages: tuple[FundingPageReceipt, ...]) -> tuple[FundingRate, ...]:
    if not pages:
        raise DataIntegrityError("no funding pages")

    funding: list[FundingRate] = []
    previous_time: int | None = None

    for page in pages:
        request_params = tuple(page.request_params)
        if request_params != tuple(sorted(request_params)):
            raise DataIntegrityError("request parameters are not sorted")
        if canonical_sha256(request_params) != page.request_params_sha256:
            raise DataIntegrityError("request parameter hash mismatch")

        response_path = Path(page.response_path)
        if not response_path.exists():
            raise DataIntegrityError("missing funding response path")
        response_bytes = response_path.read_bytes()
        if sha256(response_bytes).hexdigest() != page.response_sha256:
            raise DataIntegrityError("funding response hash mismatch")

        receipt_path = Path(page.receipt_path)
        if not receipt_path.exists():
            raise DataIntegrityError("missing funding receipt path")
        receipt_text = receipt_path.read_text(encoding="utf-8").strip()
        try:
            receipt_payload = json.loads(receipt_text)
        except json.JSONDecodeError as exc:
            raise DataIntegrityError("malformed funding receipt") from exc
        if _canonical_json(receipt_payload) != receipt_text:
            raise DataIntegrityError("non-canonical funding receipt")

        if receipt_payload.get("request_start_ms") != page.request_start_ms:
            raise DataIntegrityError("funding request metadata mismatch")
        if receipt_payload.get("request_end_ms") != page.request_end_ms:
            raise DataIntegrityError("funding request metadata mismatch")
        if receipt_payload.get("request_limit") != page.request_limit:
            raise DataIntegrityError("funding request metadata mismatch")
        if receipt_payload.get("response_sha256") != page.response_sha256:
            raise DataIntegrityError("funding response hash mismatch")
        if receipt_payload.get("response_count") != page.response_count:
            raise DataIntegrityError("response count")
        if receipt_payload.get("last_funding_time_ms") != page.last_funding_time_ms:
            raise DataIntegrityError("funding response metadata mismatch")

        if page.response_count <= 0:
            raise DataIntegrityError("response count")

        try:
            rows = json.loads(response_bytes.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise DataIntegrityError("malformed funding response") from exc
        if not isinstance(rows, list):
            raise DataIntegrityError("funding response must be a list")
        if len(rows) != page.response_count:
            raise DataIntegrityError("response count")

        if not rows:
            raise DataIntegrityError("response count")

        for row in rows:
            if not isinstance(row, dict):
                raise DataIntegrityError("malformed funding item")
            if "fundingTime" not in row or "fundingRate" not in row:
                raise DataIntegrityError("malformed funding item")
            funding_time = row["fundingTime"]
            if not isinstance(funding_time, int):
                raise DataIntegrityError("funding timestamp must be integer")
            if funding_time < 0:
                raise DataIntegrityError("funding timestamp must be non-negative")
            if previous_time is not None and funding_time <= previous_time:
                raise DataIntegrityError("non-monotonic funding timestamps")
            previous_time = funding_time

            rate, _ = _validate_decimal(row["fundingRate"], f"funding rate at {funding_time}", allow_zero=True)
            funding.append(FundingRate(funding_time_ms=funding_time, funding_rate=rate))

        last_funding = rows[-1].get("fundingTime")
        if not isinstance(last_funding, int):
            raise DataIntegrityError("malformed funding item")
        if last_funding != page.last_funding_time_ms:
            raise DataIntegrityError("funding response metadata mismatch")

    return tuple(funding)


def _hash_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_checksum(path: Path, expected_sha: str) -> None:
    raw = path.read_text(encoding="utf-8").strip().split()
    if not raw:
        raise DataIntegrityError(f"empty checksum file: {path}")
    if raw[0] != expected_sha:
        raise DataIntegrityError(f"checksum mismatch: {path}")


def _write_jsonl_atomic(path: Path, rows: Iterable[dict[str, Any]]) -> int:
    payload = "".join(_canonical_json(row) + "\n" for row in rows)
    if not payload:
        raise DataIntegrityError("normalized file would be empty")
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(payload, encoding="utf-8")
    temp.replace(path)
    return len(payload.encode("utf-8"))


def _compute_coverage(books: list[_BookRecord], trades: list[_AggRecord]) -> dict[str, int]:
    events = sorted(
        {(item.event_time_ms, 0) for item in books}
        | {(item.event_time_ms, 1) for item in trades}
    )

    source_gap_count = 0
    source_gap_duration_ms = 0
    for previous, current in zip(events, events[1:]):
        gap = current[0] - previous[0]
        if gap > MAX_JOINT_SILENCE_MS:
            source_gap_count += 1
            source_gap_duration_ms += gap - MAX_JOINT_SILENCE_MS

    book_times = sorted(item.event_time_ms for item in books)
    stale_book_count = 0
    stale_book_duration_ms = 0
    for previous, current in zip(book_times, book_times[1:]):
        gap = current - previous
        if gap > MAX_BOOK_AGE_MS:
            stale_book_count += 1
            stale_book_duration_ms += gap - MAX_BOOK_AGE_MS

    return {
        "source_gap_count": source_gap_count,
        "source_gap_duration_ms": source_gap_duration_ms,
        "stale_book_count": stale_book_count,
        "stale_book_duration_ms": stale_book_duration_ms,
    }


def _manifest_entry(kind: str, category: str, path: Path, value_root: Path, **extra: Any) -> dict[str, Any]:
    item = {
        "kind": kind,
        "category": category,
        "path": _safe_relpath(value_root, path),
        "sha256": _hash_file(path),
        "byte_count": path.stat().st_size,
    }
    item.update(extra)
    return item


@dataclass
class _KindStreamState:
    previous_identifier: int | None = None
    previous_signature: tuple[str, ...] | None = None
    previous_order_key: tuple[int, int] | None = None
    exact_duplicates: int = 0
    source_hashes: dict[str, int] = field(default_factory=dict)


@dataclass
class _PartitionSourceStats:
    row_count: int = 0
    min_event_time_ms: int | None = None
    max_event_time_ms: int | None = None

    def observe(self, event_time_ms: int) -> None:
        self.row_count += 1
        if self.min_event_time_ms is None:
            self.min_event_time_ms = event_time_ms
        self.max_event_time_ms = event_time_ms


def _observe_identifier(
    *,
    identifier: int,
    event_time_ms: int,
    signature: tuple[str, ...],
    state: _KindStreamState,
) -> bool:
    if state.previous_identifier is not None:
        if identifier < state.previous_identifier:
            raise DataIntegrityError("identifier regressed")
        if identifier == state.previous_identifier:
            if signature != state.previous_signature:
                raise DataIntegrityError("conflicting duplicate")
            signature_hash = sha256("/".join(signature).encode("utf-8")).hexdigest()
            state.source_hashes[signature_hash] = state.source_hashes.get(signature_hash, 0) + 1
            state.exact_duplicates += 1
            return False

    order_key = (event_time_ms, identifier)
    if state.previous_order_key is not None and order_key < state.previous_order_key:
        raise DataIntegrityError("cross-partition ordering regression")
    state.previous_identifier = identifier
    state.previous_signature = signature
    state.previous_order_key = order_key
    return True


def _stream_book_partition(
    records: Iterable[_BookRecord],
    state: _KindStreamState,
    source_stats: _PartitionSourceStats,
) -> Iterator[tuple[int, dict[str, Any]]]:
    for row in records:
        source_stats.observe(row.event_time_ms)
        if not _observe_identifier(
            identifier=row.update_id,
            event_time_ms=row.event_time_ms,
            signature=row.source_fields,
            state=state,
        ):
            continue
        yield row.event_time_ms, {
            "kind": "bookTicker",
            "update_id": row.update_id,
            "event_time_ms": row.event_time_ms,
            "transaction_time_ms": row.transaction_time_ms,
            "receive_time_ms": row.transaction_time_ms,
            "best_bid_price": row.best_bid_price_text,
            "best_bid_qty": row.best_bid_qty_text,
            "best_ask_price": row.best_ask_price_text,
            "best_ask_qty": row.best_ask_qty_text,
        }


def _stream_agg_partition(
    records: Iterable[_AggRecord],
    state: _KindStreamState,
    source_stats: _PartitionSourceStats,
) -> Iterator[tuple[int, dict[str, Any]]]:
    for row in records:
        source_stats.observe(row.event_time_ms)
        if not _observe_identifier(
            identifier=row.sequence,
            event_time_ms=row.event_time_ms,
            signature=row.source_fields,
            state=state,
        ):
            continue
        yield row.event_time_ms, {
            "kind": "aggTrade",
            "symbol": DATA_L1_TRADE_SYMBOL,
            "sequence": row.sequence,
            "event_time_ms": row.event_time_ms,
            "receive_time_ms": row.event_time_ms,
            "first_trade_id": row.first_trade_id,
            "last_trade_id": row.last_trade_id,
            "price": row.price_text,
            "quantity": row.quantity_text,
            "buyer_is_maker": row.buyer_is_maker,
        }


def _iter_partition_event_times(paths: Iterable[Path]) -> Iterator[int]:
    for path in paths:
        try:
            with path.open("r", encoding="utf-8") as handle:
                for source_line, line in enumerate(handle, 1):
                    if not line.strip():
                        continue
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError as exc:
                        raise DataIntegrityError(
                            f"malformed normalized json at {path}:{source_line}"
                        ) from exc
                    event_time_ms = row.get("event_time_ms")
                    if not isinstance(event_time_ms, int):
                        raise DataIntegrityError("normalized event time must be integer")
                    yield event_time_ms
        except UnicodeDecodeError as exc:
            raise DataIntegrityError(f"malformed normalized partition: {path}") from exc


def _streaming_coverage(
    book_paths: tuple[Path, ...],
    trade_paths: tuple[Path, ...],
) -> dict[str, int]:
    source_gap_count = 0
    source_gap_duration_ms = 0
    previous_joint: int | None = None
    for current in heapq.merge(
        _iter_partition_event_times(book_paths),
        _iter_partition_event_times(trade_paths),
    ):
        if previous_joint is not None:
            gap = current - previous_joint
            if gap > MAX_JOINT_SILENCE_MS:
                source_gap_count += 1
                source_gap_duration_ms += gap - MAX_JOINT_SILENCE_MS
        previous_joint = current

    stale_book_count = 0
    stale_book_duration_ms = 0
    previous_book: int | None = None
    for current in _iter_partition_event_times(book_paths):
        if previous_book is not None:
            gap = current - previous_book
            if gap > MAX_BOOK_AGE_MS:
                stale_book_count += 1
                stale_book_duration_ms += gap - MAX_BOOK_AGE_MS
        previous_book = current

    return {
        "source_gap_count": source_gap_count,
        "source_gap_duration_ms": source_gap_duration_ms,
        "stale_book_count": stale_book_count,
        "stale_book_duration_ms": stale_book_duration_ms,
    }


def _copy_exchange_rule_snapshots(
    window: DateWindow,
    exchange_rules_dir: str | Path | None,
    output_root: Path,
) -> list[dict[str, Any]]:
    if exchange_rules_dir is None:
        return []

    source_root = Path(exchange_rules_dir)
    expected_days = tuple(_iter_days(window))
    expected_names = {f"{day.isoformat()}.json" for day in expected_days}
    try:
        actual_names = {path.name for path in source_root.iterdir() if path.suffix == ".json"}
    except OSError as exc:
        raise DataIntegrityError("exchange rule snapshot day set mismatch") from exc
    if actual_names != expected_names:
        raise DataIntegrityError("exchange rule snapshot day set mismatch")

    entries: list[dict[str, Any]] = []
    for day in expected_days:
        source = source_root / f"{day.isoformat()}.json"
        snapshot = load_exchange_rule_snapshot(source)
        day_start_ms = _to_epoch_ms(day, "start")
        day_end_ms = _to_epoch_ms(day, "end")
        if (
            snapshot.symbol != DATA_L1_SYMBOL
            or snapshot.effective_from_ms > day_start_ms
            or snapshot.effective_to_ms < day_end_ms
        ):
            raise DataIntegrityError(
                f"exchange rule snapshot does not cover manifest day: {day.isoformat()}"
            )
        target = output_root / "normalized" / "exchange_rules" / source.name
        _copy_file_into_bundle(source, target)
        entries.append(
            _manifest_entry(
                "exchange_rules",
                "normalized",
                target,
                output_root,
                date=day.isoformat(),
            )
        )
    return entries


def prepare_bundle(
    receipt: RawBundleReceipt,
    output_dir: str | Path,
    *,
    exchange_rules_dir: str | Path | None = None,
) -> MarketManifest:
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    archives: dict[str, list[DownloadReceipt]] = {kind: [] for kind in KINDS}
    for archive in receipt.archive_downloads:
        if archive.kind not in KINDS:
            raise DataIntegrityError(f"unexpected archive kind: {archive.kind}")
        archives[archive.kind].append(archive)

    window_days = tuple(_iter_days(receipt.window))
    for kind in KINDS:
        archives[kind].sort(key=lambda item: item.date)
        if len(archives[kind]) != len(window_days):
            raise DataIntegrityError(f"missing {kind} archive")
        for archived, expected_day in zip(archives[kind], window_days):
            if archived.date != expected_day:
                raise DataIntegrityError(f"missing {kind} archive for {expected_day}")

    raw_entries: list[dict[str, Any]] = []
    normalized_entries: list[dict[str, Any]] = []
    normalized_paths: dict[str, list[Path]] = {kind: [] for kind in KINDS}
    states = {kind: _KindStreamState() for kind in KINDS}

    for kind in KINDS:
        for download in archives[kind]:
            raw_path = Path(download.raw_path)
            checksum_path = Path(download.checksum_path)
            if not raw_path.is_file():
                raise DataIntegrityError(f"missing archive: {raw_path}")
            if not checksum_path.is_file():
                raise DataIntegrityError(f"missing checksum file: {checksum_path}")
            downloaded_sha = _hash_file(raw_path)
            if downloaded_sha not in {
                download.expected_sha256,
                download.actual_sha256,
            } or download.expected_sha256 != download.actual_sha256:
                raise DataIntegrityError("checksum mismatch")
            if raw_path.stat().st_size != download.byte_count:
                raise DataIntegrityError("archive byte_count mismatch")
            _validate_checksum(checksum_path, download.expected_sha256)

            source_stats = _PartitionSourceStats()
            day_text = download.date.isoformat()
            normalized_kind = "book_ticker" if kind == "bookTicker" else "agg_trades"
            normalized_path = (
                output_root / "normalized" / kind / f"{day_text}.ndjson"
            )
            source_rows = _read_zip_csv_rows(raw_path)
            if kind == "bookTicker":
                normalized_rows = _stream_book_partition(
                    _parse_book_rows_from_csv(source_rows),
                    states[kind],
                    source_stats,
                )
            else:
                normalized_rows = _stream_agg_partition(
                    _parse_agg_rows_from_csv(source_rows),
                    states[kind],
                    source_stats,
                )
            partition = write_jsonl_partition(normalized_path, normalized_rows)
            if (
                source_stats.row_count == 0
                or source_stats.min_event_time_ms is None
                or source_stats.max_event_time_ms is None
            ):
                raise DataIntegrityError("raw archive is empty")
            normalized_paths[kind].append(normalized_path)

            raw_copy = output_root / "raw" / kind / f"{day_text}.zip"
            checksum_copy = output_root / "raw" / kind / f"{day_text}.zip.CHECKSUM"
            _copy_file_into_bundle(raw_path, raw_copy)
            _copy_file_into_bundle(checksum_path, checksum_copy)
            raw_entries.extend(
                (
                    _manifest_entry(
                        kind=kind,
                        category="raw_archive",
                        path=raw_copy,
                        value_root=output_root,
                        date=day_text,
                        source_row_count=source_stats.row_count,
                        source_min_event_time_ms=source_stats.min_event_time_ms,
                        source_max_event_time_ms=source_stats.max_event_time_ms,
                    ),
                    _manifest_entry(
                        kind=f"{kind}_checksum",
                        category="raw_archive_checksum",
                        path=checksum_copy,
                        value_root=output_root,
                        date=day_text,
                    ),
                )
            )
            normalized_entries.append(
                {
                    "kind": normalized_kind,
                    "category": "normalized_partition",
                    "path": _safe_relpath(output_root, normalized_path),
                    "sha256": partition.sha256,
                    "byte_count": partition.byte_count,
                    "row_count": partition.row_count,
                    "date": day_text,
                    "source_min_event_time_ms": partition.min_event_time_ms,
                    "source_max_event_time_ms": partition.max_event_time_ms,
                }
            )

    funding_rates = parse_funding_pages(receipt.funding_pages)
    required_start_ms = _to_epoch_ms(receipt.window.start_date, "start")
    required_end_ms = _to_epoch_ms(receipt.window.end_date, "end")
    if funding_rates[0].funding_time_ms > required_start_ms:
        raise DataIntegrityError("funding coverage does not bracket interval")
    if funding_rates[-1].funding_time_ms < required_end_ms:
        raise DataIntegrityError("funding coverage does not bracket interval")

    funding_path = output_root / "normalized" / "funding" / "funding.ndjson"
    funding_path.parent.mkdir(parents=True, exist_ok=True)
    _write_jsonl_atomic(
        funding_path,
        (
            {
                "kind": "funding",
                "funding_time_ms": item.funding_time_ms,
                "funding_rate": str(item.funding_rate),
            }
            for item in funding_rates
        ),
    )
    normalized_entries.append(
        _manifest_entry(
            "funding",
            "normalized",
            funding_path,
            output_root,
            row_count=len(funding_rates),
        )
    )

    for index, page in enumerate(receipt.funding_pages):
        funding_copy = output_root / "funding" / f"funding-{index:04d}.json"
        funding_receipt_copy = (
            output_root / "funding" / f"funding-{index:04d}.receipt.json"
        )
        _copy_file_into_bundle(Path(page.response_path), funding_copy)
        _copy_file_into_bundle(Path(page.receipt_path), funding_receipt_copy)
        raw_entries.extend(
            (
                {
                    "kind": "funding_page",
                    "category": "funding_response",
                    "page_index": index,
                    "request_params": list(page.request_params),
                    "request_start_ms": page.request_start_ms,
                    "request_end_ms": page.request_end_ms,
                    "request_limit": page.request_limit,
                    "request_params_sha256": page.request_params_sha256,
                    "path": _safe_relpath(output_root, funding_copy),
                    "sha256": page.response_sha256,
                    "byte_count": funding_copy.stat().st_size,
                    "response_count": page.response_count,
                    "last_funding_time_ms": page.last_funding_time_ms,
                    "row_count": page.response_count,
                },
                {
                    "kind": "funding_page_receipt",
                    "category": "funding_receipt",
                    "page_index": index,
                    "path": _safe_relpath(output_root, funding_receipt_copy),
                    "sha256": _hash_file(funding_receipt_copy),
                    "byte_count": funding_receipt_copy.stat().st_size,
                },
            )
        )

    coverage = _streaming_coverage(
        tuple(normalized_paths["bookTicker"]),
        tuple(normalized_paths["aggTrades"]),
    )
    exact_duplicates = {
        kind: states[kind].exact_duplicates
        for kind in KINDS
    }
    source_hashes = {
        kind: states[kind].source_hashes
        for kind in KINDS
    }
    exchange_rule_entries = _copy_exchange_rule_snapshots(
        receipt.window,
        exchange_rules_dir,
        output_root,
    )
    manifest_payload: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "grade": "engineering_replay",
        "symbol": DATA_L1_SYMBOL,
        "window": {
            "start_date": receipt.window.start_date.isoformat(),
            "end_date": receipt.window.end_date.isoformat(),
        },
        "files": sorted(
            raw_entries + normalized_entries + exchange_rule_entries,
            key=lambda item: item["path"],
        ),
        "exact_duplicates": exact_duplicates,
        "source_hashes": source_hashes,
        "max_book_age_ms": MAX_BOOK_AGE_MS,
        "max_joint_silence_ms": MAX_JOINT_SILENCE_MS,
        "coverage": coverage,
        "authorization": dict(DATA_L1_AUTHORIZE_FLAGS),
        "funding_bounds": {
            "required_start_ms": required_start_ms,
            "required_end_ms": required_end_ms,
            "first_funding_time_ms": funding_rates[0].funding_time_ms,
            "last_funding_time_ms": funding_rates[-1].funding_time_ms,
        },
    }
    manifest_payload["manifest_sha256"] = canonical_sha256(manifest_payload)
    manifest_path = output_root / "market_manifest.json"
    temporary_manifest = manifest_path.with_suffix(".tmp")
    temporary_manifest.write_text(
        _canonical_json(manifest_payload),
        encoding="utf-8",
    )
    temporary_manifest.replace(manifest_path)

    return MarketManifest(
        symbol=DATA_L1_SYMBOL,
        window=receipt.window,
        files=tuple(
            ManifestFile(
                kind=item["kind"],
                date=date.fromisoformat(item["date"]),
                path=item["path"],
                sha256=item["sha256"],
            )
            for item in manifest_payload["files"]
            if item.get("category")
            in {"raw_archive", "normalized_partition", "normalized"}
            and item.get("kind") != "funding"
            and "date" in item
        ),
        exact_duplicates=exact_duplicates,
        max_book_age_ms=MAX_BOOK_AGE_MS,
        max_joint_silence_ms=MAX_JOINT_SILENCE_MS,
        grade="engineering_replay",
        authorization=manifest_payload["authorization"],
        coverage=coverage,
        funding_bounds=manifest_payload["funding_bounds"],
    )


def _prepare_legacy_bundle(receipt: RawBundleReceipt, output_dir: str | Path) -> MarketManifest:
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    archives: dict[str, list[DownloadReceipt]] = {kind: [] for kind in KINDS}
    for archive in receipt.archive_downloads:
        if archive.kind not in KINDS:
            raise DataIntegrityError(f"unexpected archive kind: {archive.kind}")
        archives[archive.kind].append(archive)

    window_days = tuple(_iter_days(receipt.window))

    for kind in KINDS:
        archives[kind].sort(key=lambda item: item.date)
        if len(archives[kind]) != len(window_days):
            raise DataIntegrityError(f"missing {kind} archive")
        for archived, expected_day in zip(archives[kind], window_days):
            if archived.date != expected_day:
                raise DataIntegrityError(f"missing {kind} archive for {expected_day}")

    exact_duplicates: dict[str, int] = {"bookTicker": 0, "aggTrades": 0}
    source_hashes: dict[str, dict[str, int]] = {"bookTicker": {}, "aggTrades": {}}
    raw_entries: list[dict[str, Any]] = []

    all_book_rows: list[_BookRecord] = []
    all_agg_rows: list[_AggRecord] = []

    for kind in KINDS:
        for download in archives[kind]:
            raw_path = Path(download.raw_path)
            checksum_path = Path(download.checksum_path)

            if not raw_path.exists():
                raise DataIntegrityError(f"missing archive: {raw_path}")
            if not checksum_path.exists():
                raise DataIntegrityError(f"missing checksum file: {checksum_path}")

            downloaded_sha = _hash_file(raw_path)
            if downloaded_sha != download.expected_sha256:
                raise DataIntegrityError("checksum mismatch")
            if downloaded_sha != download.actual_sha256:
                raise DataIntegrityError("checksum mismatch")

            _validate_checksum(checksum_path, download.expected_sha256)

            source_rows = _read_zip_csv_rows(raw_path)
            if kind == "bookTicker":
                book_rows = list(_parse_book_rows_from_csv(source_rows))
                dupe_count, hash_counts, deduped = _dedupe_book(book_rows)
                exact_duplicates[kind] = exact_duplicates[kind] + dupe_count
                for signature_hash, count in hash_counts.items():
                    source_hashes[kind][signature_hash] = source_hashes[kind].get(signature_hash, 0) + count
                all_book_rows.extend(deduped)
            elif kind == "aggTrades":
                agg_rows = list(_parse_agg_rows_from_csv(source_rows))
                dupe_count, hash_counts, deduped = _dedupe_agg(agg_rows)
                exact_duplicates[kind] = exact_duplicates[kind] + dupe_count
                for signature_hash, count in hash_counts.items():
                    source_hashes[kind][signature_hash] = source_hashes[kind].get(signature_hash, 0) + count
                all_agg_rows.extend(deduped)
            else:
                raise DataIntegrityError(f"unexpected archive kind: {kind}")

            if kind == "bookTicker":
                source_events = [row.event_time_ms for row in book_rows]
                source_records = len(book_rows)
            else:
                source_events = [row.event_time_ms for row in agg_rows]
                source_records = len(agg_rows)

            raw_copy = output_root / "raw" / kind / f"{download.date.isoformat()}.zip"
            checksum_copy = output_root / "raw" / kind / f"{download.date.isoformat()}.zip.CHECKSUM"
            _copy_file_into_bundle(raw_path, raw_copy)
            _copy_file_into_bundle(checksum_path, checksum_copy)

            raw_entries.append(
                _manifest_entry(
                    kind=kind,
                    category="raw_archive",
                    path=raw_copy,
                    value_root=output_root,
                    date=download.date.isoformat(),
                    source_row_count=source_records,
                    source_min_event_time_ms=min(source_events),
                    source_max_event_time_ms=max(source_events),
                )
            )
            raw_entries.append(
                _manifest_entry(
                    kind=f"{kind}_checksum",
                    category="raw_archive_checksum",
                    path=checksum_copy,
                    value_root=output_root,
                    date=download.date.isoformat(),
                )
            )

    if not all_book_rows:
        raise DataIntegrityError("no bookTicker rows")
    if not all_agg_rows:
        raise DataIntegrityError("no aggTrade rows")

    all_book_rows.sort(key=lambda row: (row.event_time_ms, row.update_id, row.source_line))
    all_agg_rows.sort(key=lambda row: (row.event_time_ms, row.sequence, row.source_line))

    funding_rates = parse_funding_pages(receipt.funding_pages)
    required_start_ms = _to_epoch_ms(receipt.window.start_date, "start")
    required_end_ms = _to_epoch_ms(receipt.window.end_date, "end")
    if funding_rates[0].funding_time_ms > required_start_ms:
        raise DataIntegrityError("funding coverage does not bracket interval")
    if funding_rates[-1].funding_time_ms < required_end_ms:
        raise DataIntegrityError("funding coverage does not bracket interval")

    book_rows = [
        {
            "kind": "bookTicker",
            "update_id": row.update_id,
            "event_time_ms": row.event_time_ms,
            "transaction_time_ms": row.transaction_time_ms,
            "receive_time_ms": row.transaction_time_ms,
            "best_bid_price": row.best_bid_price_text,
            "best_bid_qty": row.best_bid_qty_text,
            "best_ask_price": row.best_ask_price_text,
            "best_ask_qty": row.best_ask_qty_text,
        }
        for row in all_book_rows
    ]
    trade_rows = [
        {
            "kind": "aggTrade",
            "symbol": DATA_L1_TRADE_SYMBOL,
            "sequence": row.sequence,
            "event_time_ms": row.event_time_ms,
            "receive_time_ms": row.event_time_ms,
            "first_trade_id": row.first_trade_id,
            "last_trade_id": row.last_trade_id,
            "price": row.price_text,
            "quantity": row.quantity_text,
            "buyer_is_maker": row.buyer_is_maker,
        }
        for row in all_agg_rows
    ]
    funding_rows = [
        {
            "kind": "funding",
            "funding_time_ms": item.funding_time_ms,
            "funding_rate": str(item.funding_rate),
        }
        for item in funding_rates
    ]

    book_path = output_root / "book_ticker.ndjson"
    agg_path = output_root / "agg_trades.ndjson"
    funding_path = output_root / "funding.ndjson"

    _write_jsonl_atomic(book_path, book_rows)
    _write_jsonl_atomic(agg_path, trade_rows)
    _write_jsonl_atomic(funding_path, funding_rows)

    funding_pages: list[tuple[FundingPageReceipt, dict[str, Any]]] = []
    for index, page in enumerate(receipt.funding_pages):
        funding_response_path = Path(page.response_path)
        funding_receipt_path = Path(page.receipt_path)
        funding_copy = output_root / "funding" / f"funding-{index:04d}.json"
        funding_receipt_copy = output_root / "funding" / f"funding-{index:04d}.receipt.json"
        _copy_file_into_bundle(funding_response_path, funding_copy)
        _copy_file_into_bundle(funding_receipt_path, funding_receipt_copy)
        funding_pages.append(
            (
                page,
                {
                    "path": _safe_relpath(output_root, funding_copy),
                    "sha256": page.response_sha256,
                    "byte_count": funding_copy.stat().st_size,
                    "response_count": page.response_count,
                    "last_funding_time_ms": page.last_funding_time_ms,
                    "row_count": page.response_count,
                    "request_params": list(page.request_params),
                    "request_start_ms": page.request_start_ms,
                    "request_end_ms": page.request_end_ms,
                    "request_limit": page.request_limit,
                    "request_params_sha256": page.request_params_sha256,
                },
            )
        )

    for index, (page, metadata) in enumerate(funding_pages):
        raw_entries.append(
            {
                "kind": "funding_page",
                "category": "funding_response",
                "page_index": index,
                "request_params": metadata["request_params"],
                "request_start_ms": metadata["request_start_ms"],
                "request_end_ms": metadata["request_end_ms"],
                "request_limit": metadata["request_limit"],
                "request_params_sha256": metadata["request_params_sha256"],
                "path": metadata["path"],
                "sha256": metadata["sha256"],
                "byte_count": metadata["byte_count"],
                "response_count": metadata["response_count"],
                "last_funding_time_ms": metadata["last_funding_time_ms"],
                "row_count": metadata["row_count"],
            }
        )
        raw_entries.append(
            {
                "kind": "funding_page_receipt",
                "category": "funding_receipt",
                "page_index": index,
                "path": _safe_relpath(output_root, output_root / "funding" / f"funding-{index:04d}.receipt.json"),
                "sha256": _hash_file(output_root / "funding" / f"funding-{index:04d}.receipt.json"),
                "byte_count": (output_root / "funding" / f"funding-{index:04d}.receipt.json").stat().st_size,
            }
        )

    normalized_entries = [
        _manifest_entry("book_ticker", "normalized", book_path, output_root, row_count=len(book_rows)),
        _manifest_entry("agg_trades", "normalized", agg_path, output_root, row_count=len(trade_rows)),
        _manifest_entry("funding", "normalized", funding_path, output_root, row_count=len(funding_rows)),
    ]

    coverage = _compute_coverage(all_book_rows, all_agg_rows)

    manifest_payload: dict[str, Any] = {
        "schema_version": LEGACY_SCHEMA_VERSION,
        "grade": "engineering_replay",
        "symbol": DATA_L1_SYMBOL,
        "window": {
            "start_date": receipt.window.start_date.isoformat(),
            "end_date": receipt.window.end_date.isoformat(),
        },
        "files": sorted(raw_entries + normalized_entries, key=lambda item: item["path"]),
        "exact_duplicates": exact_duplicates,
        "source_hashes": source_hashes,
        "max_book_age_ms": MAX_BOOK_AGE_MS,
        "max_joint_silence_ms": MAX_JOINT_SILENCE_MS,
        "coverage": coverage,
        "authorization": dict(DATA_L1_AUTHORIZE_FLAGS),
        "funding_bounds": {
            "required_start_ms": required_start_ms,
            "required_end_ms": required_end_ms,
            "first_funding_time_ms": funding_rates[0].funding_time_ms,
            "last_funding_time_ms": funding_rates[-1].funding_time_ms,
        },
    }
    manifest_payload["manifest_sha256"] = canonical_sha256({k: manifest_payload[k] for k in manifest_payload})
    manifest_path = output_root / "market_manifest.json"
    temp_manifest = manifest_path.with_suffix(".tmp")
    temp_manifest.write_text(_canonical_json(manifest_payload), encoding="utf-8")
    temp_manifest.replace(manifest_path)

    return MarketManifest(
        symbol=DATA_L1_SYMBOL,
        window=receipt.window,
        files=tuple(
            ManifestFile(
                kind=item["kind"],
                date=date.fromisoformat(item["date"]),
                path=item["path"],
                sha256=item["sha256"],
            )
            for item in manifest_payload["files"]
            if item.get("category") in {"raw_archive", "normalized"} and "date" in item
        ),
        exact_duplicates=manifest_payload["exact_duplicates"],
        max_book_age_ms=MAX_BOOK_AGE_MS,
        max_joint_silence_ms=MAX_JOINT_SILENCE_MS,
        grade="engineering_replay",
        authorization=manifest_payload["authorization"],
        coverage=manifest_payload["coverage"],
        funding_bounds=manifest_payload["funding_bounds"],
    )


def _safe_path(value: object, root: Path) -> Path:
    if not isinstance(value, str):
        raise DataIntegrityError("manifest paths must be strings")
    if value.startswith("/") or value.startswith("\\") or "\\" in value:
        raise DataIntegrityError("path")
    candidate = Path(value)
    if any(part in {"..", "."} for part in candidate.parts):
        raise DataIntegrityError("path")
    absolute = (root / candidate).resolve()
    if not absolute.is_relative_to(root.resolve()):
        raise DataIntegrityError("path")
    return absolute


def _validated_exchange_rule_entries(
    entries: Iterable[Mapping[str, Any]],
    window: DateWindow,
) -> tuple[Mapping[str, Any], ...]:
    rule_entries: list[Mapping[str, Any]] = []
    for entry in entries:
        if entry.get("kind") != "exchange_rules":
            continue
        if entry.get("category") != "normalized":
            raise DataIntegrityError("exchange rule manifest entry category invalid")
        raw_date = entry.get("date")
        if not isinstance(raw_date, str):
            raise DataIntegrityError("exchange rule manifest entry date invalid")
        try:
            entry_date = date.fromisoformat(raw_date)
        except ValueError as exc:
            raise DataIntegrityError("exchange rule manifest entry date invalid") from exc
        if entry_date.isoformat() != raw_date:
            raise DataIntegrityError("exchange rule manifest entry date invalid")
        if not window.start_date <= entry_date <= window.end_date:
            raise DataIntegrityError("exchange rule manifest entry date outside window")
        rule_entries.append(entry)
    return tuple(sorted(rule_entries, key=lambda entry: entry["date"]))


def _load_exchange_rule_paths(
    entries: Iterable[Mapping[str, Any]],
    root: Path,
    window: DateWindow,
) -> tuple[Path, ...]:
    rule_entries = _validated_exchange_rule_entries(entries, window)
    if not rule_entries:
        return ()
    expected_days = tuple(day.isoformat() for day in _iter_days(window))
    if tuple(entry.get("date") for entry in rule_entries) != expected_days:
        raise DataIntegrityError("exchange rule snapshot day set mismatch")

    paths: list[Path] = []
    for day, entry in zip(_iter_days(window), rule_entries):
        path = _safe_path(entry.get("path"), root)
        snapshot = load_exchange_rule_snapshot(path)
        if (
            snapshot.symbol != DATA_L1_SYMBOL
            or snapshot.effective_from_ms > _to_epoch_ms(day, "start")
            or snapshot.effective_to_ms < _to_epoch_ms(day, "end")
        ):
            raise DataIntegrityError(
                f"exchange rule snapshot does not cover manifest day: {day.isoformat()}"
            )
        paths.append(path)
    return tuple(paths)


def _require_object(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise DataIntegrityError(f"{label} must be object")
    return value


def _require_str(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise DataIntegrityError(f"{label} must be string")
    return value


def _require_int(value: object, label: str) -> int:
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise DataIntegrityError(f"{label} must be integer") from exc


def _require_request_params(raw_request_params: object) -> tuple[tuple[str, object], ...]:
    if not isinstance(raw_request_params, list):
        raise DataIntegrityError("funding request params malformed")

    request_params: list[tuple[str, object]] = []
    for item in raw_request_params:
        if not isinstance(item, (tuple, list)) or len(item) != 2:
            raise DataIntegrityError("funding request params malformed")
        name, value = item
        if not isinstance(name, str):
            raise DataIntegrityError("funding request params malformed")
        if isinstance(value, float) or isinstance(value, (Mapping, list, tuple)):
            raise DataIntegrityError("funding request params malformed")
        if value is not None and not isinstance(value, (str, int, bool)):
            raise DataIntegrityError("funding request params malformed")
        request_params.append((name, value))

    return tuple(request_params)


def _load_manifest_root_entries(manifest_file: Path, root: Path) -> dict[str, Any]:
    if not manifest_file.is_file():
        raise DataIntegrityError(f"missing manifest: {manifest_file}")

    try:
        raw_text = manifest_file.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError as exc:
        raise DataIntegrityError("manifest is not valid utf-8") from exc

    try:
        manifest_payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise DataIntegrityError("invalid manifest json") from exc

    if not isinstance(manifest_payload, dict):
        raise DataIntegrityError("manifest payload invalid")

    if _canonical_json(manifest_payload) != raw_text:
        raise DataIntegrityError("manifest is not canonical json")

    declared_sha = manifest_payload.get("manifest_sha256")
    if not isinstance(declared_sha, str):
        raise DataIntegrityError("manifest is missing manifest_sha256")

    return manifest_payload


def _load_funding_from_manifest(files: list[dict[str, Any]], root: Path) -> tuple[list[FundingPageReceipt], list[FundingRate]]:
    responses = {
        item.get("page_index"): item
        for item in files
        if isinstance(item, dict)
        and item.get("kind") == "funding_page"
        and item.get("category") == "funding_response"
    }
    receipts = {
        item.get("page_index"): item
        for item in files
        if isinstance(item, dict)
        and item.get("kind") == "funding_page_receipt"
        and item.get("category") == "funding_receipt"
    }

    if set(responses) != set(receipts):
        raise DataIntegrityError("funding manifest is incomplete")
    if not responses:
        raise DataIntegrityError("no funding manifest entries")
    page_indices = list(responses.keys())
    if not all(isinstance(page_index, int) for page_index in page_indices):
        raise DataIntegrityError("invalid funding page index")
    if sorted(page_indices) != list(range(len(responses))):
        raise DataIntegrityError("funding page indices must be contiguous")

    receipt_specs: list[FundingPageReceipt] = []
    for page_index in sorted(responses):
        response = responses[page_index]
        request_params = _require_request_params(response.get("request_params"))
        if not isinstance(response.get("sha256"), str):
            raise DataIntegrityError("funding response hash missing")
        if not isinstance(response.get("request_start_ms"), int):
            raise DataIntegrityError("funding request metadata missing")
        if not isinstance(response.get("request_end_ms"), int):
            raise DataIntegrityError("funding request metadata missing")
        if not isinstance(response.get("request_limit"), int):
            raise DataIntegrityError("funding request metadata missing")
        if not isinstance(response.get("request_params_sha256"), str):
            raise DataIntegrityError("funding request metadata missing")
        if not isinstance(response.get("response_count"), int) or response.get("response_count") <= 0:
            raise DataIntegrityError("response count")
        if not isinstance(response.get("last_funding_time_ms"), int):
            raise DataIntegrityError("funding response metadata mismatch")
        if not isinstance(response.get("path"), str):
            raise DataIntegrityError("funding path invalid")
        if not isinstance(receipts[page_index].get("path"), str):
            raise DataIntegrityError("funding receipt path invalid")
        if response.get("response_count") < 0:
            raise DataIntegrityError("response count")

        path = str(_safe_path(response["path"], root))
        receipt_path = str(_safe_path(receipts[page_index]["path"], root))
        receipt_specs.append(
            FundingPageReceipt(
                request_start_ms=response["request_start_ms"],
                request_end_ms=response["request_end_ms"],
                request_limit=response["request_limit"],
                request_params=request_params,
                request_params_sha256=response["request_params_sha256"],
                response_path=path,
                receipt_path=receipt_path,
                response_sha256=response["sha256"],
                response_count=response["response_count"],
                last_funding_time_ms=response["last_funding_time_ms"],
            )
        )

    funding = parse_funding_pages(tuple(receipt_specs))
    return receipt_specs, list(funding)


def _read_lines(path: Path, *, label: str) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except UnicodeDecodeError as exc:
        raise DataIntegrityError(f"malformed {label}") from exc
    return [line for line in lines if line.strip()]


def _load_legacy_verified_bundle(manifest_path: str | Path) -> VerifiedBundle:
    manifest_file = Path(manifest_path)
    manifest_payload = _load_manifest_root_entries(manifest_file, manifest_file.parent)
    root = manifest_file.parent

    if manifest_payload.get("schema_version") != LEGACY_SCHEMA_VERSION:
        raise DataIntegrityError("unsupported schema_version")
    if manifest_payload.get("grade") != "engineering_replay":
        raise DataIntegrityError("unsupported grade")
    if manifest_payload.get("symbol") != DATA_L1_SYMBOL:
        raise DataIntegrityError("unsupported symbol")

    if manifest_payload.get("max_book_age_ms") != MAX_BOOK_AGE_MS:
        raise DataIntegrityError("unsupported max_book_age_ms")
    if manifest_payload.get("max_joint_silence_ms") != MAX_JOINT_SILENCE_MS:
        raise DataIntegrityError("unsupported max_joint_silence_ms")
    if manifest_payload.get("authorization") != dict(DATA_L1_AUTHORIZE_FLAGS):
        raise DataIntegrityError("authorization flags mismatch")

    declared_manifest_sha = manifest_payload.get("manifest_sha256")
    if not isinstance(declared_manifest_sha, str):
        raise DataIntegrityError("manifest is missing manifest_sha256")
    computed_manifest_payload = dict(manifest_payload)
    computed_manifest_payload.pop("manifest_sha256")
    if canonical_sha256(computed_manifest_payload) != declared_manifest_sha:
        raise DataIntegrityError("manifest sha256 mismatch")

    window_payload = _require_object(manifest_payload.get("window"), "window")
    try:
        window = DateWindow(
            start_date=date.fromisoformat(_require_str(window_payload.get("start_date"), "window.start_date")),
            end_date=date.fromisoformat(_require_str(window_payload.get("end_date"), "window.end_date")),
        )
    except ValueError as exc:
        raise DataIntegrityError("window date malformed") from exc

    if window.start_date > window.end_date:
        raise DataIntegrityError("window is inverted")

    required_start_ms = _to_epoch_ms(window.start_date, "start")
    required_end_ms = _to_epoch_ms(window.end_date, "end")

    entries = [_require_object(item, "manifest file entry") for item in manifest_payload.get("files", [])]
    if not entries:
        raise DataIntegrityError("manifest files missing")
    _validated_exchange_rule_entries(entries, window)

    normalized_entries = {
        item.get("kind"): item
        for item in entries
        if item.get("category") == "normalized" and isinstance(item.get("kind"), str)
    }
    book_entry = normalized_entries.get("book_ticker")
    agg_entry = normalized_entries.get("agg_trades")
    funding_entry = normalized_entries.get("funding")
    if not book_entry or not agg_entry or not funding_entry:
        raise DataIntegrityError("manifest missing normalized entries")
    if not isinstance(book_entry.get("row_count"), int) or not isinstance(agg_entry.get("row_count"), int):
        raise DataIntegrityError("normalized row_count missing")
    if not isinstance(funding_entry.get("row_count"), int):
        raise DataIntegrityError("normalized funding row_count missing")

    raw_days = tuple(_iter_days(window))
    raw_entries = [item for item in entries if item.get("category") == "raw_archive"]
    checksum_entries = [item for item in entries if item.get("category") == "raw_archive_checksum"]
    funding_responses = sorted(
        [item for item in entries if item.get("category") == "funding_response"],
        key=lambda item: item.get("page_index"),
    )
    funding_receipts = sorted(
        [item for item in entries if item.get("category") == "funding_receipt"],
        key=lambda item: item.get("page_index"),
    )

    if len(raw_entries) != len(raw_days) * len(KINDS):
        raise DataIntegrityError("incomplete raw archive set")
    if len(checksum_entries) != len(raw_days) * len(KINDS):
        raise DataIntegrityError("incomplete raw checksum set")
    if len(funding_responses) != len(funding_receipts):
        raise DataIntegrityError("funding manifest is incomplete")

    if not all(isinstance(item.get("page_index"), int) for item in funding_responses + funding_receipts):
        raise DataIntegrityError("invalid funding page index")
    if [item.get("page_index") for item in funding_responses] != list(range(len(funding_responses))):
        raise DataIntegrityError("funding page indices must be contiguous")

    expected_paths = {manifest_file.name}
    seen_paths = set[str]()
    manifest_map: dict[tuple[str, str], set[object]] = {}
    for item in entries:
        if not isinstance(item.get("kind"), str) or not isinstance(item.get("category"), str):
            raise DataIntegrityError("manifest file entry missing kind/category")
        logical = manifest_map.setdefault((item["kind"], item["category"]), set())
        logical_key = item.get("date") if "date" in item else item.get("page_index")
        if logical_key in logical:
            raise DataIntegrityError("duplicate manifest logical entry")
        logical.add(logical_key)

        path = _safe_path(item.get("path"), root)
        if not path.is_file():
            raise DataIntegrityError(f"missing manifest file: {item.get('path')}")
        if not isinstance(item.get("byte_count"), int):
            raise DataIntegrityError("manifest file byte_count missing")
        if path.stat().st_size != item["byte_count"]:
            raise DataIntegrityError("manifest file byte_count mismatch")
        if _hash_file(path) != item["sha256"]:
            raise DataIntegrityError("sha256 mismatch")
        rel = _safe_relpath(root, path)
        if rel in seen_paths:
            raise DataIntegrityError("duplicate manifest paths")
        seen_paths.add(rel)
        expected_paths.add(rel)

    actual_files = {
        file.relative_to(root).as_posix()
        for file in root.rglob("*")
        if file.is_file()
    }
    if actual_files != expected_paths:
        raise DataIntegrityError("manifest path set mismatch")
    exchange_rule_paths = _load_exchange_rule_paths(entries, root, window)

    exact_duplicates_payload = _require_object(manifest_payload.get("exact_duplicates"), "exact_duplicates")
    source_hashes_payload = _require_object(manifest_payload.get("source_hashes"), "source_hashes")
    if not all(
        isinstance(exact_duplicates_payload.get(kind), int) for kind in ("bookTicker", "aggTrades")
    ):
        raise DataIntegrityError("exact duplicate metadata missing")
    if not all(isinstance(source_hashes_payload.get(kind), Mapping) for kind in ("bookTicker", "aggTrades")):
        raise DataIntegrityError("source hash metadata missing")
    if not all(
        isinstance(item, str) and isinstance(count, int)
        for payload in source_hashes_payload.values()
        for item, count in payload.items()
    ):
        raise DataIntegrityError("source hash metadata missing")

    funding_receipt_specs, funding_rates = _load_funding_from_manifest(entries, root)
    if not funding_rates:
        raise DataIntegrityError("no funding events")
    if funding_rates[0].funding_time_ms > required_start_ms:
        raise DataIntegrityError("funding coverage does not bracket interval")
    if funding_rates[-1].funding_time_ms < required_end_ms:
        raise DataIntegrityError("funding coverage does not bracket interval")

    funding_bounds = _require_object(manifest_payload.get("funding_bounds"), "funding_bounds")
    if funding_bounds.get("required_start_ms") != required_start_ms:
        raise DataIntegrityError("funding bounds drift")
    if funding_bounds.get("required_end_ms") != required_end_ms:
        raise DataIntegrityError("funding bounds drift")
    if funding_bounds.get("first_funding_time_ms") != funding_rates[0].funding_time_ms:
        raise DataIntegrityError("funding bounds drift")
    if funding_bounds.get("last_funding_time_ms") != funding_rates[-1].funding_time_ms:
        raise DataIntegrityError("funding bounds drift")

    book_path = _safe_path(book_entry["path"], root)
    agg_path = _safe_path(agg_entry["path"], root)
    funding_path = _safe_path(funding_entry["path"], root)

    book_lines = _read_lines(book_path, label="book_ticker file")
    if len(book_lines) != book_entry["row_count"]:
        raise DataIntegrityError("row count mismatch for book_ticker")

    trade_lines = _read_lines(agg_path, label="aggTrades file")
    if len(trade_lines) != agg_entry["row_count"]:
        raise DataIntegrityError("row count mismatch for agg_trades")

    funding_lines = _read_lines(funding_path, label="funding file")
    if len(funding_lines) != funding_entry["row_count"]:
        raise DataIntegrityError("row count mismatch for funding")

    books: list[_BookRecord] = []
    for source_line, line in enumerate(book_lines, 1):
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise DataIntegrityError("malformed book_ticker json") from exc
        if row.get("kind") != "bookTicker":
            raise DataIntegrityError("invalid book kind")
        books.append(_parse_normalized_book_row(row, source_line))

    _, _, _ = _dedupe_book(books)
    for index in range(1, len(books)):
        if (books[index].event_time_ms, books[index].update_id, books[index].source_line) < (
            books[index - 1].event_time_ms,
            books[index - 1].update_id,
            books[index - 1].source_line,
        ):
            raise DataIntegrityError("ordering regression")

    trades: list[_AggRecord] = []
    for source_line, line in enumerate(trade_lines, 1):
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise DataIntegrityError("malformed aggTrades json") from exc
        if row.get("kind") != "aggTrade":
            raise DataIntegrityError("invalid aggTrade kind")
        trades.append(_parse_normalized_agg_row(row, source_line))

    _, _, _ = _dedupe_agg(trades)
    for index in range(1, len(trades)):
        if (trades[index].event_time_ms, trades[index].sequence, trades[index].source_line) < (
            trades[index - 1].event_time_ms,
            trades[index - 1].sequence,
            trades[index - 1].source_line,
        ):
            raise DataIntegrityError("ordering regression")

    normalized_funding: list[FundingRate] = []
    last_funding_ms = None
    for source_line, line in enumerate(funding_lines, 1):
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise DataIntegrityError("malformed funding json") from exc
        if row.get("kind") != "funding":
            raise DataIntegrityError("invalid funding kind")
        funding_time_ms = _validate_int(row.get("funding_time_ms"), f"funding line {source_line}")
        funding_rate, _ = _validate_decimal(
            row.get("funding_rate"),
            f"funding line {source_line}",
            allow_zero=True,
        )
        if last_funding_ms is not None and funding_time_ms <= last_funding_ms:
            raise DataIntegrityError("non-monotonic funding")
        last_funding_ms = funding_time_ms
        normalized_funding.append(FundingRate(funding_time_ms=funding_time_ms, funding_rate=funding_rate))

    if [item.funding_time_ms for item in funding_rates] != [item.funding_time_ms for item in normalized_funding]:
        raise DataIntegrityError("funding rows do not match source")

    coverage = _compute_coverage(books, trades)
    if dict(coverage) != manifest_payload.get("coverage"):
        raise DataIntegrityError("coverage drift")

    source_duplicates = {"bookTicker": 0, "aggTrades": 0}
    source_hashes_actual: dict[str, dict[str, int]] = {"bookTicker": {}, "aggTrades": {}}
    for item in raw_entries:
        raw_path = _safe_path(item["path"], root)
        if item["kind"] == "bookTicker":
            rows = list(_parse_book_rows_from_csv(_read_zip_csv_rows(raw_path)))
            duplicate_count, hashes, _ = _dedupe_book(rows)
            source_duplicates["bookTicker"] += duplicate_count
            for signature_hash, count in hashes.items():
                source_hashes_actual["bookTicker"][signature_hash] = (
                    source_hashes_actual["bookTicker"].get(signature_hash, 0) + count
                )
            if item.get("source_row_count") != len(rows):
                raise DataIntegrityError("source row_count mismatch")
        elif item["kind"] == "aggTrades":
            rows = list(_parse_agg_rows_from_csv(_read_zip_csv_rows(raw_path)))
            duplicate_count, hashes, _ = _dedupe_agg(rows)
            source_duplicates["aggTrades"] += duplicate_count
            for signature_hash, count in hashes.items():
                source_hashes_actual["aggTrades"][signature_hash] = (
                    source_hashes_actual["aggTrades"].get(signature_hash, 0) + count
                )
            if item.get("source_row_count") != len(rows):
                raise DataIntegrityError("source row_count mismatch")
        else:
            raise DataIntegrityError("unexpected raw archive kind")

    if source_duplicates != exact_duplicates_payload:
        raise DataIntegrityError("duplicate count mismatch")
    if source_hashes_actual != source_hashes_payload:
        raise DataIntegrityError("source hash drift")

    for item in raw_entries:
        raw_path = _safe_path(item["path"], root)
        if item["kind"] == "bookTicker":
            raw_rows = list(_parse_book_rows_from_csv(_read_zip_csv_rows(raw_path)))
        elif item["kind"] == "aggTrades":
            raw_rows = list(_parse_agg_rows_from_csv(_read_zip_csv_rows(raw_path)))
        else:
            raise DataIntegrityError("unexpected raw archive kind")

        events = [row.event_time_ms for row in raw_rows]
        if not events:
            raise DataIntegrityError("raw archive is empty")
        if item.get("source_min_event_time_ms") != min(events):
            raise DataIntegrityError("source range metadata mismatch")
        if item.get("source_max_event_time_ms") != max(events):
            raise DataIntegrityError("source range metadata mismatch")

    return VerifiedBundle(
        manifest=MarketManifest(
            symbol=manifest_payload.get("symbol", DATA_L1_SYMBOL),
            window=window,
            files=tuple(
                ManifestFile(
                    kind=item["kind"],
                    date=date.fromisoformat(item["date"]),
                    path=item["path"],
                    sha256=item["sha256"],
                )
                for item in entries
                if item.get("category") in {"raw_archive", "normalized"}
                and isinstance(item.get("date"), str)
            ),
            exact_duplicates=manifest_payload.get("exact_duplicates", {}),
            max_book_age_ms=manifest_payload.get("max_book_age_ms", MAX_BOOK_AGE_MS),
            max_joint_silence_ms=manifest_payload.get("max_joint_silence_ms", MAX_JOINT_SILENCE_MS),
            grade=manifest_payload.get("grade", "engineering_replay"),
            authorization=manifest_payload.get("authorization", {}),
            coverage=manifest_payload.get("coverage", {}),
            funding_bounds=manifest_payload.get("funding_bounds", {}),
        ),
        book_tickers=tuple(
            BookTicker(
                update_id=item.update_id,
                event_time_ms=item.event_time_ms,
                transaction_time_ms=item.transaction_time_ms,
                bid_price=item.best_bid_price,
                bid_quantity=item.best_bid_qty,
                ask_price=item.best_ask_price,
                ask_quantity=item.best_ask_qty,
            )
            for item in books
        ),
        agg_trades=tuple(
            TradePrint(
                venue="binance",
                market="perpetual",
                symbol=DATA_L1_TRADE_SYMBOL,
                event_time_ms=item.event_time_ms,
                receive_time_ms=item.event_time_ms,
                sequence=item.sequence,
                price=item.price,
                quantity=item.quantity,
                buyer_is_maker=item.buyer_is_maker,
            )
            for item in trades
        ),
        funding=tuple(normalized_funding),
        book_path=book_path,
        trade_path=agg_path,
        funding_path=funding_path,
        exchange_rule_paths=exchange_rule_paths,
    )


def _iter_normalized_rows(path: Path, label: str) -> Iterator[tuple[int, Mapping[str, Any]]]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            for source_line, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise DataIntegrityError(f"malformed {label} json") from exc
                if not isinstance(row, dict):
                    raise DataIntegrityError(f"malformed {label} json")
                yield source_line, row
    except UnicodeDecodeError as exc:
        raise DataIntegrityError(f"malformed {label} file") from exc


def _iter_normalized_books(paths: tuple[Path, ...]) -> Iterator[BookTicker]:
    previous_key: tuple[int, int] | None = None
    previous_identifier: int | None = None
    for path in paths:
        for source_line, row in _iter_normalized_rows(path, "book_ticker"):
            if row.get("kind") != "bookTicker":
                raise DataIntegrityError("invalid book kind")
            record = _parse_normalized_book_row(row, source_line)
            key = (record.event_time_ms, record.update_id)
            if previous_identifier is not None and record.update_id <= previous_identifier:
                raise DataIntegrityError("normalized book identifier regression")
            if previous_key is not None and key < previous_key:
                raise DataIntegrityError("normalized book ordering regression")
            previous_identifier = record.update_id
            previous_key = key
            yield BookTicker(
                update_id=record.update_id,
                event_time_ms=record.event_time_ms,
                transaction_time_ms=record.transaction_time_ms,
                bid_price=record.best_bid_price,
                bid_quantity=record.best_bid_qty,
                ask_price=record.best_ask_price,
                ask_quantity=record.best_ask_qty,
            )


def _iter_normalized_trades(paths: tuple[Path, ...]) -> Iterator[TradePrint]:
    previous_key: tuple[int, int] | None = None
    previous_identifier: int | None = None
    for path in paths:
        for source_line, row in _iter_normalized_rows(path, "aggTrades"):
            if row.get("kind") != "aggTrade":
                raise DataIntegrityError("invalid aggTrade kind")
            record = _parse_normalized_agg_row(row, source_line)
            key = (record.event_time_ms, record.sequence)
            if previous_identifier is not None and record.sequence <= previous_identifier:
                raise DataIntegrityError("normalized aggTrade identifier regression")
            if previous_key is not None and key < previous_key:
                raise DataIntegrityError("normalized aggTrade ordering regression")
            previous_identifier = record.sequence
            previous_key = key
            yield TradePrint(
                venue="binance",
                market="perpetual",
                symbol=DATA_L1_TRADE_SYMBOL,
                event_time_ms=record.event_time_ms,
                receive_time_ms=record.event_time_ms,
                sequence=record.sequence,
                price=record.price,
                quantity=record.quantity,
                buyer_is_maker=record.buyer_is_maker,
            )


def _iter_normalized_funding(path: Path) -> Iterator[FundingRate]:
    previous_time: int | None = None
    for source_line, row in _iter_normalized_rows(path, "funding"):
        if row.get("kind") != "funding":
            raise DataIntegrityError("invalid funding kind")
        funding_time_ms = _validate_int(
            row.get("funding_time_ms"),
            f"funding line {source_line}",
        )
        funding_rate, _ = _validate_decimal(
            row.get("funding_rate"),
            f"funding line {source_line}",
            allow_zero=True,
        )
        if previous_time is not None and funding_time_ms <= previous_time:
            raise DataIntegrityError("non-monotonic funding")
        previous_time = funding_time_ms
        yield FundingRate(funding_time_ms=funding_time_ms, funding_rate=funding_rate)


def _validate_partition_rows(
    entries: tuple[Mapping[str, Any], ...],
    paths: tuple[Path, ...],
    *,
    kind: str,
) -> None:
    if len(entries) != len(paths):
        raise DataIntegrityError("normalized partition metadata mismatch")
    for entry, path in zip(entries, paths):
        row_count = 0
        minimum: int | None = None
        maximum: int | None = None
        for _source_line, row in _iter_normalized_rows(path, kind):
            event_time_ms = row.get("event_time_ms")
            if not isinstance(event_time_ms, int):
                raise DataIntegrityError("normalized event time must be integer")
            row_count += 1
            if minimum is None:
                minimum = event_time_ms
            maximum = event_time_ms
        if row_count != entry.get("row_count"):
            raise DataIntegrityError(f"row count mismatch for {kind}")
        if minimum != entry.get("source_min_event_time_ms"):
            raise DataIntegrityError("source range metadata mismatch")
        if maximum != entry.get("source_max_event_time_ms"):
            raise DataIntegrityError("source range metadata mismatch")


def _load_partitioned_verified_bundle(
    manifest_file: Path,
    manifest_payload: Mapping[str, Any],
) -> VerifiedBundle:
    root = manifest_file.parent
    if manifest_payload.get("grade") != "engineering_replay":
        raise DataIntegrityError("unsupported grade")
    if manifest_payload.get("symbol") != DATA_L1_SYMBOL:
        raise DataIntegrityError("unsupported symbol")
    if manifest_payload.get("max_book_age_ms") != MAX_BOOK_AGE_MS:
        raise DataIntegrityError("unsupported max_book_age_ms")
    if manifest_payload.get("max_joint_silence_ms") != MAX_JOINT_SILENCE_MS:
        raise DataIntegrityError("unsupported max_joint_silence_ms")
    if manifest_payload.get("authorization") != dict(DATA_L1_AUTHORIZE_FLAGS):
        raise DataIntegrityError("authorization flags mismatch")

    declared_manifest_sha = manifest_payload.get("manifest_sha256")
    if not isinstance(declared_manifest_sha, str):
        raise DataIntegrityError("manifest is missing manifest_sha256")
    computed = dict(manifest_payload)
    computed.pop("manifest_sha256")
    if canonical_sha256(computed) != declared_manifest_sha:
        raise DataIntegrityError("manifest sha256 mismatch")

    window_payload = _require_object(manifest_payload.get("window"), "window")
    try:
        window = DateWindow(
            start_date=date.fromisoformat(
                _require_str(window_payload.get("start_date"), "window.start_date")
            ),
            end_date=date.fromisoformat(
                _require_str(window_payload.get("end_date"), "window.end_date")
            ),
        )
    except ValueError as exc:
        raise DataIntegrityError("window date malformed") from exc
    if window.start_date > window.end_date:
        raise DataIntegrityError("window is inverted")

    raw_files = manifest_payload.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        raise DataIntegrityError("manifest files missing")
    entries = tuple(_require_object(item, "manifest file entry") for item in raw_files)
    _validated_exchange_rule_entries(entries, window)
    seen_paths: set[str] = set()
    expected_paths = {manifest_file.name}
    seen_logical: set[tuple[object, object, object]] = set()
    for entry in entries:
        kind = entry.get("kind")
        category = entry.get("category")
        if not isinstance(kind, str) or not isinstance(category, str):
            raise DataIntegrityError("manifest file entry missing kind/category")
        logical = (kind, category, entry.get("date", entry.get("page_index")))
        if logical in seen_logical:
            raise DataIntegrityError("duplicate manifest logical entry")
        seen_logical.add(logical)
        path = _safe_path(entry.get("path"), root)
        if not path.is_file():
            raise DataIntegrityError(f"missing manifest file: {entry.get('path')}")
        if not isinstance(entry.get("byte_count"), int):
            raise DataIntegrityError("manifest file byte_count missing")
        if path.stat().st_size != entry["byte_count"]:
            raise DataIntegrityError("manifest file byte_count mismatch")
        if _hash_file(path) != entry.get("sha256"):
            raise DataIntegrityError("sha256 mismatch")
        relative = _safe_relpath(root, path)
        if relative in seen_paths:
            raise DataIntegrityError("duplicate manifest paths")
        seen_paths.add(relative)
        expected_paths.add(relative)

    actual_paths = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file()
    }
    if actual_paths != expected_paths:
        raise DataIntegrityError("manifest path set mismatch")
    exchange_rule_paths = _load_exchange_rule_paths(entries, root, window)

    expected_days = tuple(day.isoformat() for day in _iter_days(window))
    book_entries = tuple(
        sorted(
            (
                entry
                for entry in entries
                if entry.get("category") == "normalized_partition"
                and entry.get("kind") == "book_ticker"
            ),
            key=lambda entry: entry.get("date"),
        )
    )
    trade_entries = tuple(
        sorted(
            (
                entry
                for entry in entries
                if entry.get("category") == "normalized_partition"
                and entry.get("kind") == "agg_trades"
            ),
            key=lambda entry: entry.get("date"),
        )
    )
    if tuple(entry.get("date") for entry in book_entries) != expected_days:
        raise DataIntegrityError("incomplete normalized book partition set")
    if tuple(entry.get("date") for entry in trade_entries) != expected_days:
        raise DataIntegrityError("incomplete normalized trade partition set")
    funding_entries = tuple(
        entry
        for entry in entries
        if entry.get("category") == "normalized"
        and entry.get("kind") == "funding"
    )
    if len(funding_entries) != 1:
        raise DataIntegrityError("manifest missing normalized funding")

    book_paths = tuple(_safe_path(entry["path"], root) for entry in book_entries)
    trade_paths = tuple(_safe_path(entry["path"], root) for entry in trade_entries)
    funding_path = _safe_path(funding_entries[0]["path"], root)
    _validate_partition_rows(book_entries, book_paths, kind="book_ticker")
    _validate_partition_rows(trade_entries, trade_paths, kind="agg_trades")
    for _ in _iter_normalized_books(book_paths):
        pass
    for _ in _iter_normalized_trades(trade_paths):
        pass

    normalized_funding = tuple(_iter_normalized_funding(funding_path))
    if len(normalized_funding) != funding_entries[0].get("row_count"):
        raise DataIntegrityError("row count mismatch for funding")
    _funding_receipts, source_funding = _load_funding_from_manifest(list(entries), root)
    if normalized_funding != tuple(source_funding):
        raise DataIntegrityError("funding rows do not match source")

    required_start_ms = _to_epoch_ms(window.start_date, "start")
    required_end_ms = _to_epoch_ms(window.end_date, "end")
    if (
        not normalized_funding
        or normalized_funding[0].funding_time_ms > required_start_ms
        or normalized_funding[-1].funding_time_ms < required_end_ms
    ):
        raise DataIntegrityError("funding coverage does not bracket interval")
    funding_bounds = _require_object(
        manifest_payload.get("funding_bounds"),
        "funding_bounds",
    )
    if funding_bounds != {
        "required_start_ms": required_start_ms,
        "required_end_ms": required_end_ms,
        "first_funding_time_ms": normalized_funding[0].funding_time_ms,
        "last_funding_time_ms": normalized_funding[-1].funding_time_ms,
    }:
        raise DataIntegrityError("funding bounds drift")

    coverage = _streaming_coverage(book_paths, trade_paths)
    if coverage != manifest_payload.get("coverage"):
        raise DataIntegrityError("coverage drift")

    raw_entries = tuple(
        sorted(
            (entry for entry in entries if entry.get("category") == "raw_archive"),
            key=lambda entry: (entry.get("kind"), entry.get("date")),
        )
    )
    if len(raw_entries) != len(expected_days) * len(KINDS):
        raise DataIntegrityError("incomplete raw archive set")
    raw_states = {kind: _KindStreamState() for kind in KINDS}
    for entry in raw_entries:
        kind = entry.get("kind")
        if kind not in KINDS:
            raise DataIntegrityError("unexpected raw archive kind")
        source_stats = _PartitionSourceStats()
        raw_path = _safe_path(entry["path"], root)
        rows = _read_zip_csv_rows(raw_path)
        if kind == "bookTicker":
            stream = _stream_book_partition(
                _parse_book_rows_from_csv(rows),
                raw_states[kind],
                source_stats,
            )
        else:
            stream = _stream_agg_partition(
                _parse_agg_rows_from_csv(rows),
                raw_states[kind],
                source_stats,
            )
        for _ in stream:
            pass
        if source_stats.row_count != entry.get("source_row_count"):
            raise DataIntegrityError("source row_count mismatch")
        if source_stats.min_event_time_ms != entry.get("source_min_event_time_ms"):
            raise DataIntegrityError("source range metadata mismatch")
        if source_stats.max_event_time_ms != entry.get("source_max_event_time_ms"):
            raise DataIntegrityError("source range metadata mismatch")

    exact_duplicates = _require_object(
        manifest_payload.get("exact_duplicates"),
        "exact_duplicates",
    )
    source_hashes = _require_object(
        manifest_payload.get("source_hashes"),
        "source_hashes",
    )
    if {
        kind: raw_states[kind].exact_duplicates
        for kind in KINDS
    } != exact_duplicates:
        raise DataIntegrityError("duplicate count mismatch")
    if {
        kind: raw_states[kind].source_hashes
        for kind in KINDS
    } != source_hashes:
        raise DataIntegrityError("source hash drift")

    manifest = MarketManifest(
        symbol=DATA_L1_SYMBOL,
        window=window,
        files=tuple(
            ManifestFile(
                kind=entry["kind"],
                date=date.fromisoformat(entry["date"]),
                path=entry["path"],
                sha256=entry["sha256"],
            )
            for entry in entries
            if entry.get("category")
            in {"raw_archive", "normalized_partition", "normalized"}
            and entry.get("kind") != "funding"
            and isinstance(entry.get("date"), str)
        ),
        exact_duplicates=exact_duplicates,
        max_book_age_ms=MAX_BOOK_AGE_MS,
        max_joint_silence_ms=MAX_JOINT_SILENCE_MS,
        grade="engineering_replay",
        authorization=manifest_payload.get("authorization", {}),
        coverage=coverage,
        funding_bounds=funding_bounds,
    )

    def book_factory() -> Iterator[BookTicker]:
        return _iter_normalized_books(book_paths)

    def trade_factory() -> Iterator[TradePrint]:
        return _iter_normalized_trades(trade_paths)

    def funding_factory() -> Iterator[FundingRate]:
        return _iter_normalized_funding(funding_path)

    return VerifiedBundle(
        manifest=manifest,
        book_tickers=(),
        agg_trades=(),
        funding=normalized_funding,
        book_path=root / "book_ticker.ndjson",
        trade_path=root / "agg_trades.ndjson",
        funding_path=funding_path,
        schema_version=SCHEMA_VERSION,
        book_ticker_factory=book_factory,
        agg_trade_factory=trade_factory,
        funding_factory=funding_factory,
        exchange_rule_paths=exchange_rule_paths,
    )


def load_verified_bundle(manifest_path: str | Path) -> VerifiedBundle:
    manifest_file = Path(manifest_path)
    manifest_payload = _load_manifest_root_entries(
        manifest_file,
        manifest_file.parent,
    )
    schema_version = manifest_payload.get("schema_version")
    if schema_version == LEGACY_SCHEMA_VERSION:
        return _load_legacy_verified_bundle(manifest_file)
    if schema_version == SCHEMA_VERSION:
        return _load_partitioned_verified_bundle(manifest_file, manifest_payload)
    raise DataIntegrityError("unsupported schema_version")
