from __future__ import annotations

from dataclasses import dataclass, fields
from decimal import (
    Context,
    Decimal,
    DivisionByZero,
    InvalidOperation,
    Overflow,
    ROUND_CEILING,
    ROUND_FLOOR,
    localcontext,
)
from hashlib import sha256
import json
from pathlib import Path
from typing import Mapping

from research.mm_l1_replay.contracts import BookTicker, DataIntegrityError, decimal_json


@dataclass(frozen=True)
class ExchangeRuleSnapshot:
    symbol: str
    effective_from_ms: int
    effective_to_ms: int
    tick_size: Decimal
    min_price: Decimal
    max_price: Decimal
    step_size: Decimal
    min_quantity: Decimal
    max_quantity: Decimal
    min_notional: Decimal
    max_notional: Decimal | None
    bid_multiplier_down: Decimal
    bid_multiplier_up: Decimal
    ask_multiplier_down: Decimal
    ask_multiplier_up: Decimal
    max_open_orders: int
    max_algo_orders: int
    source_sha256: str


@dataclass(frozen=True)
class ExchangeRuleBook:
    snapshots: tuple[ExchangeRuleSnapshot, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "snapshots",
            tuple(sorted(self.snapshots, key=lambda item: item.effective_from_ms)),
        )

    def for_event(self, event_time_ms: int) -> ExchangeRuleSnapshot:
        matches = tuple(
            snapshot
            for snapshot in self.snapshots
            if snapshot.effective_from_ms <= event_time_ms <= snapshot.effective_to_ms
        )
        if len(matches) != 1:
            if not matches:
                raise DataIntegrityError(f"missing exchange rules at {event_time_ms}")
            raise DataIntegrityError(f"ambiguous exchange rules at {event_time_ms}")
        return matches[0]


@dataclass(frozen=True)
class OrderCandidate:
    lane: str
    side: str
    execution: str
    price: Decimal
    quantity: Decimal
    reference_price: Decimal
    post_only: bool
    max_slippage_bps: Decimal
    is_algorithmic: bool = False


@dataclass(frozen=True)
class ConstrainedOrder:
    lane: str
    side: str
    execution: str
    price: Decimal
    quantity: Decimal


@dataclass(frozen=True)
class ConstraintDecision:
    order: ConstrainedOrder | None
    reason: str


_DECIMAL_FIELDS = {
    "tick_size",
    "min_price",
    "max_price",
    "step_size",
    "min_quantity",
    "max_quantity",
    "min_notional",
    "max_notional",
    "bid_multiplier_down",
    "bid_multiplier_up",
    "ask_multiplier_down",
    "ask_multiplier_up",
}

_DECIMAL_CONTEXT = Context(
    prec=50,
    Emin=-999_999,
    Emax=999_999,
    capitals=1,
    clamp=0,
)
_DECIMAL_CONTEXT.traps[InvalidOperation] = True
_DECIMAL_CONTEXT.traps[DivisionByZero] = True
_DECIMAL_CONTEXT.traps[Overflow] = True


def exchange_rules_are_valid(rules: object) -> bool:
    if not isinstance(rules, ExchangeRuleSnapshot):
        return False
    with localcontext(_DECIMAL_CONTEXT):
        decimals = (
            rules.tick_size,
            rules.min_price,
            rules.max_price,
            rules.step_size,
            rules.min_quantity,
            rules.max_quantity,
            rules.min_notional,
            rules.bid_multiplier_down,
            rules.bid_multiplier_up,
            rules.ask_multiplier_down,
            rules.ask_multiplier_up,
        )
        if any(
            type(value) is not Decimal or not value.is_finite()
            for value in decimals
        ):
            return False
        if rules.max_notional is not None and (
            type(rules.max_notional) is not Decimal
            or not rules.max_notional.is_finite()
        ):
            return False
        if rules.tick_size < 0 or rules.step_size <= 0:
            return False
        if rules.min_price < 0 or rules.max_price < 0:
            return False
        if (
            rules.min_price > 0
            and rules.max_price > 0
            and rules.max_price < rules.min_price
        ):
            return False
        if rules.min_quantity <= 0 or rules.max_quantity < rules.min_quantity:
            return False
        if rules.min_notional < 0:
            return False
        if rules.max_notional is not None and (
            rules.max_notional <= 0 or rules.max_notional < rules.min_notional
        ):
            return False
        for lower, upper in (
            (rules.bid_multiplier_down, rules.bid_multiplier_up),
            (rules.ask_multiplier_down, rules.ask_multiplier_up),
        ):
            if lower < 0 or upper <= 0 or lower > upper:
                return False

    if (
        type(rules.effective_from_ms) is not int
        or type(rules.effective_to_ms) is not int
        or rules.effective_from_ms < 0
        or rules.effective_to_ms < rules.effective_from_ms
    ):
        return False
    if (
        type(rules.max_open_orders) is not int
        or type(rules.max_algo_orders) is not int
        or rules.max_open_orders < 0
        or rules.max_algo_orders < 0
    ):
        return False
    if (
        not isinstance(rules.symbol, str)
        or not rules.symbol
        or rules.symbol.strip() != rules.symbol
    ):
        return False
    return (
        isinstance(rules.source_sha256, str)
        and len(rules.source_sha256) == 64
        and all(char in "0123456789abcdef" for char in rules.source_sha256)
    )


def load_exchange_rule_snapshot(path: str | Path) -> ExchangeRuleSnapshot:
    source = Path(path)
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise TypeError("snapshot must be a JSON object")
        decimal_json(payload)
        expected = {field.name for field in fields(ExchangeRuleSnapshot)}
        if set(payload) != expected:
            raise ValueError("snapshot fields do not match schema")
        normalized = {
            key: (
                Decimal(str(value))
                if key in _DECIMAL_FIELDS and value is not None
                else value
            )
            for key, value in payload.items()
        }
        normalized["effective_from_ms"] = int(normalized["effective_from_ms"])
        normalized["effective_to_ms"] = int(normalized["effective_to_ms"])
        normalized["max_open_orders"] = int(normalized["max_open_orders"])
        normalized["max_algo_orders"] = int(normalized["max_algo_orders"])
        snapshot = ExchangeRuleSnapshot(**normalized)
    except (OSError, json.JSONDecodeError, TypeError, ValueError, KeyError) as exc:
        raise DataIntegrityError(f"invalid exchange rule snapshot: {source}") from exc
    if not exchange_rules_are_valid(snapshot):
        raise DataIntegrityError(f"invalid exchange rule snapshot: {source}")
    return snapshot


def snapshot_from_exchange_info(
    payload: Mapping[str, object],
    *,
    symbol: str,
    fetched_at_ms: int,
) -> ExchangeRuleSnapshot:
    symbols = payload.get("symbols", [])
    rows = [
        row
        for row in symbols
        if isinstance(row, Mapping) and row.get("symbol") == symbol
    ]
    if len(rows) != 1:
        raise DataIntegrityError(f"missing exchange rules for {symbol}")
    try:
        raw_filters = rows[0].get("filters", [])
        if not isinstance(raw_filters, list):
            raise TypeError("filters must be a list")
        filters: dict[str, Mapping[str, object]] = {}
        for item in raw_filters:
            if not isinstance(item, Mapping):
                raise TypeError("filter must be an object")
            filter_type = item.get("filterType")
            if not isinstance(filter_type, str) or not filter_type:
                raise TypeError("filterType must be a nonempty string")
            if filter_type in filters:
                raise ValueError(f"duplicate filter: {filter_type}")
            filters[filter_type] = item
        price = filters["PRICE_FILTER"]
        lot = filters["LOT_SIZE"]
        notional = filters.get("NOTIONAL", filters.get("MIN_NOTIONAL"))
        if notional is None:
            raise KeyError("NOTIONAL")
        (
            bid_multiplier_down,
            bid_multiplier_up,
            ask_multiplier_down,
            ask_multiplier_up,
        ) = _percent_price_multipliers(filters)
        source_sha256 = sha256(decimal_json(payload).encode("utf-8")).hexdigest()
        return ExchangeRuleSnapshot(
            symbol=symbol,
            effective_from_ms=fetched_at_ms,
            effective_to_ms=2**63 - 1,
            tick_size=Decimal(price["tickSize"]),
            min_price=Decimal(price["minPrice"]),
            max_price=Decimal(price["maxPrice"]),
            step_size=Decimal(lot["stepSize"]),
            min_quantity=Decimal(lot["minQty"]),
            max_quantity=Decimal(lot["maxQty"]),
            min_notional=Decimal(notional["minNotional"]),
            max_notional=(
                Decimal(notional["maxNotional"])
                if "maxNotional" in notional
                else None
            ),
            bid_multiplier_down=bid_multiplier_down,
            bid_multiplier_up=bid_multiplier_up,
            ask_multiplier_down=ask_multiplier_down,
            ask_multiplier_up=ask_multiplier_up,
            max_open_orders=int(filters.get("MAX_NUM_ORDERS", {}).get("limit", 0)),
            max_algo_orders=int(filters.get("MAX_NUM_ALGO_ORDERS", {}).get("limit", 0)),
            source_sha256=source_sha256,
        )
    except (InvalidOperation, KeyError, TypeError, ValueError) as exc:
        raise DataIntegrityError(f"invalid exchange rules for {symbol}") from exc


def _percent_price_multipliers(
    filters: Mapping[str, Mapping[str, object]],
) -> tuple[Decimal, Decimal, Decimal, Decimal]:
    side_specific = filters.get("PERCENT_PRICE_BY_SIDE")
    if side_specific is not None:
        bid_down = _positive_decimal(side_specific, "bidMultiplierDown")
        bid_up = _positive_decimal(side_specific, "bidMultiplierUp")
        ask_down = _positive_decimal(side_specific, "askMultiplierDown")
        ask_up = _positive_decimal(side_specific, "askMultiplierUp")
        _validate_multiplier_range(bid_down, bid_up)
        _validate_multiplier_range(ask_down, ask_up)
        return bid_down, bid_up, ask_down, ask_up

    generic = filters.get("PERCENT_PRICE")
    if generic is not None:
        multiplier_down = _positive_decimal(generic, "multiplierDown")
        multiplier_up = _positive_decimal(generic, "multiplierUp")
        _validate_multiplier_range(multiplier_down, multiplier_up)
        return (
            multiplier_down,
            multiplier_up,
            multiplier_down,
            multiplier_up,
        )

    return Decimal("0"), Decimal("999999"), Decimal("0"), Decimal("999999")


def _positive_decimal(source: Mapping[str, object], field_name: str) -> Decimal:
    raw_value = source[field_name]
    if type(raw_value) is not str:
        raise TypeError(f"{field_name} must be a decimal string")
    value = Decimal(raw_value)
    if not value.is_finite() or value <= 0:
        raise ValueError(f"{field_name} must be finite and positive")
    return value


def _validate_multiplier_range(lower: Decimal, upper: Decimal) -> None:
    if lower > upper:
        raise ValueError("percent-price multiplier range is inverted")


def constrain_order(
    candidate: OrderCandidate,
    rules: ExchangeRuleSnapshot,
    book: BookTicker,
    *,
    current_open_orders: int = 0,
    current_algo_orders: int = 0,
) -> ConstraintDecision:
    with localcontext(_DECIMAL_CONTEXT):
        if not exchange_rules_are_valid(rules):
            return ConstraintDecision(None, "invalid_rules")
        price = _round_price(
            candidate.price,
            rules.tick_size,
            candidate.side,
            candidate.execution,
        )
        quantity = _round_down(candidate.quantity, rules.step_size)
        reason = _validate(
            candidate,
            price,
            quantity,
            rules,
            book,
            current_open_orders=current_open_orders,
            current_algo_orders=current_algo_orders,
        )
        if reason is not None:
            return ConstraintDecision(None, reason)
        return ConstraintDecision(
            ConstrainedOrder(
                candidate.lane,
                candidate.side,
                candidate.execution,
                price,
                quantity,
            ),
            "accepted",
        )


def _round_price(price: Decimal, tick_size: Decimal, side: str, execution: str) -> Decimal:
    if tick_size <= 0:
        return price
    if side == "buy":
        rounding = ROUND_FLOOR if execution == "maker" else ROUND_CEILING
    elif side == "sell":
        rounding = ROUND_CEILING if execution == "maker" else ROUND_FLOOR
    else:
        return price
    return _round_to_increment(price, tick_size, rounding)


def _round_down(value: Decimal, increment: Decimal) -> Decimal:
    if increment <= 0:
        return value
    return _round_to_increment(value, increment, ROUND_FLOOR)


def _round_to_increment(value: Decimal, increment: Decimal, rounding: str) -> Decimal:
    units = (value / increment).to_integral_value(rounding=rounding)
    return units * increment


def _validate(
    candidate: OrderCandidate,
    price: Decimal,
    quantity: Decimal,
    rules: ExchangeRuleSnapshot,
    book: BookTicker,
    *,
    current_open_orders: int,
    current_algo_orders: int,
) -> str | None:
    if not rules.effective_from_ms <= book.event_time_ms <= rules.effective_to_ms:
        return "rule_not_effective"

    positive_values = (
        candidate.price,
        candidate.quantity,
        candidate.reference_price,
        price,
        quantity,
        rules.step_size,
        book.bid_price,
        book.ask_price,
    )
    if any(value <= 0 for value in positive_values):
        return "non_positive_fields"

    if (rules.min_price > 0 and price < rules.min_price) or (
        rules.max_price > 0 and price > rules.max_price
    ):
        return "price_bounds"

    if candidate.side == "buy":
        percent_min = candidate.reference_price * rules.bid_multiplier_down
        percent_max = candidate.reference_price * rules.bid_multiplier_up
    elif candidate.side == "sell":
        percent_min = candidate.reference_price * rules.ask_multiplier_down
        percent_max = candidate.reference_price * rules.ask_multiplier_up
    else:
        return "non_positive_fields"
    if price < percent_min or price > percent_max:
        return "percent_price_by_side"

    if quantity < rules.min_quantity or quantity > rules.max_quantity:
        return "quantity_bounds"

    if candidate.post_only and (
        (candidate.side == "buy" and price >= book.ask_price)
        or (candidate.side == "sell" and price <= book.bid_price)
    ):
        return "post_only_cross"

    notional = price * quantity
    if notional < rules.min_notional:
        return "min_notional"
    if rules.max_notional is not None and notional > rules.max_notional:
        return "max_notional"

    if candidate.side == "buy":
        adverse_move = max(Decimal("0"), price - candidate.reference_price)
    else:
        adverse_move = max(Decimal("0"), candidate.reference_price - price)
    slippage_bps = adverse_move * Decimal("10000") / candidate.reference_price
    if slippage_bps > candidate.max_slippage_bps:
        return "slippage_cap"

    if current_open_orders < 0 or (
        rules.max_open_orders > 0 and current_open_orders >= rules.max_open_orders
    ):
        return "open_order_limit"
    if candidate.is_algorithmic and (
        current_algo_orders < 0
        or (rules.max_algo_orders > 0 and current_algo_orders >= rules.max_algo_orders)
    ):
        return "algorithmic_order_limit"
    return None


__all__ = [
    "ConstrainedOrder",
    "ConstraintDecision",
    "ExchangeRuleBook",
    "ExchangeRuleSnapshot",
    "OrderCandidate",
    "constrain_order",
    "exchange_rules_are_valid",
    "load_exchange_rule_snapshot",
    "snapshot_from_exchange_info",
]
