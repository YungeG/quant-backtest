from __future__ import annotations

from collections.abc import Iterable
from datetime import date, datetime, timedelta, timezone
from datetime import date as date_type
from hashlib import sha256
from pathlib import Path
import json
import os
import time
from typing import Any, Callable

from .contracts import (
    ArchiveRef,
    DataIntegrityError,
    DateWindow,
    DownloadReceipt,
    FundingPageReceipt,
    RawBundleReceipt,
    canonical_sha256,
)

ARCHIVE_ROOT = "https://data.binance.vision/data/futures/um/daily"
FUNDING_URL = "https://fapi.binance.com/fapi/v1/fundingRate"
KINDS = ("bookTicker", "aggTrades")
MAX_RETRIES = 5
MAX_LOOKBACK_DAYS = 1000
FUNDING_LIMIT = 1000
DAY_CHUNK_BYTES = 1024 * 1024


def resolve_candidate_dates(as_of: date_type, days: int = 30) -> tuple[date_type, ...]:
    if days <= 0:
        raise ValueError("days must be positive")
    return tuple(as_of - timedelta(days=offset) for offset in range(days, 0, -1))


def archive_url(kind: str, day: date_type) -> str:
    if kind not in KINDS:
        raise ValueError(f"unsupported kind: {kind}")
    return f"{ARCHIVE_ROOT}/{kind}/ETHUSDT/ETHUSDT-{kind}-{day.isoformat()}.zip"


def probe_complete_window(
    as_of: date_type,
    days: int,
    session: Any,
    *,
    max_lookback_days: int = MAX_LOOKBACK_DAYS,
    sleep: Callable[[float], None] = time.sleep,
) -> DateWindow:
    if days <= 0:
        raise ValueError("days must be positive")
    if max_lookback_days < days:
        raise ValueError("max_lookback_days must be at least days")

    cursor_end = as_of - timedelta(days=1)
    attempts = max_lookback_days - days + 1
    for _ in range(attempts):
        window_start = cursor_end - timedelta(days=days - 1)
        candidate = DateWindow(start_date=window_start, end_date=cursor_end)
        if _window_complete(candidate, session, sleep=sleep):
            return candidate
        cursor_end -= timedelta(days=1)

    raise DataIntegrityError("could not find a complete archive window within lookback bound")


def download_archive(
    ref: ArchiveRef,
    session: Any,
    *,
    sleep: Callable[[float], None] = time.sleep,
) -> DownloadReceipt:
    checksum_response = _request_with_retries(
        session.get,
        ref.checksum_url,
        sleep=sleep,
    )
    expected_checksum = _parse_checksum_body(checksum_response.content, ref.checksum_url)
    if expected_checksum != ref.sha256:
        raise DataIntegrityError("checksum mismatch for archive declaration")

    archive_path = Path(ref.raw_path)
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    checksum_path = archive_path.with_suffix(archive_path.suffix + ".CHECKSUM")
    temp_path = archive_path.with_name(f".{archive_path.name}.{os.getpid()}.part")
    temp_checksum_path = Path(f"{checksum_path}.{os.getpid()}.tmp")
    try:
        response = _request_with_retries(
            session.get,
            ref.url,
            sleep=sleep,
            stream=True,
        )
        downloaded = 0
        hasher = sha256()
        with temp_path.open("wb") as archive_file:
            for chunk in response.iter_content(chunk_size=DAY_CHUNK_BYTES):
                if not chunk:
                    continue
                archive_file.write(chunk)
                downloaded += len(chunk)
                hasher.update(chunk)

        actual_checksum = hasher.hexdigest()
        if actual_checksum != expected_checksum:
            raise DataIntegrityError("checksum mismatch while downloading archive")

        with temp_checksum_path.open("wb") as checksum_file:
            checksum_file.write(checksum_response.content)

        temp_path.replace(archive_path)
        temp_checksum_path.replace(checksum_path)
        return DownloadReceipt(
            kind=ref.kind,
            date=ref.date,
            url=ref.url,
            raw_path=str(archive_path),
            checksum_path=str(checksum_path),
            expected_sha256=expected_checksum,
            actual_sha256=actual_checksum,
            byte_count=downloaded,
        )
    except Exception:
        for path in (temp_path, temp_checksum_path):
            if path.exists():
                path.unlink()
        raise


def fetch_funding_pages(
    window: DateWindow,
    session: Any,
    *,
    output_dir: str | Path | None = None,
    sleep: Callable[[float], None] = time.sleep,
) -> tuple[FundingPageReceipt, ...]:
    output_directory = Path(output_dir or Path.cwd())
    output_directory.mkdir(parents=True, exist_ok=True)
    request_limit = FUNDING_LIMIT

    start_ms = _to_epoch_ms(window.start_date, "start")
    end_ms = _to_epoch_ms(window.end_date, "end")
    cursor = start_ms
    receipts: list[FundingPageReceipt] = []
    page_index = 0

    while cursor <= end_ms:
        params = {
            "symbol": "ETHUSDT",
            "startTime": cursor,
            "endTime": end_ms,
            "limit": request_limit,
        }
        parameter_items = tuple((key, int(value) if isinstance(value, bool) else value) for key, value in params.items())
        request_params = tuple(sorted(parameter_items))
        request_signature = canonical_sha256(request_params)
        response = _request_with_retries(session.get, FUNDING_URL, sleep=sleep, params=params)

        response_payload = response.content
        if not isinstance(response_payload, (bytes, bytearray)):
            raise DataIntegrityError("malformed funding response: expected bytes")
        response_bytes = bytes(response_payload)
        try:
            page = json.loads(response_bytes)
        except (TypeError, json.JSONDecodeError) as exc:
            raise DataIntegrityError("malformed funding response: invalid json") from exc
        if not isinstance(page, list):
            raise DataIntegrityError("malformed funding response: expected list")
        if not page:
            raise DataIntegrityError("empty funding response")

        page_count = len(page)

        page_times: list[int] = []
        previous_time = cursor - 1
        for item in page:
            try:
                funding_time = _extract_funding_time(item)
            except (KeyError, TypeError, ValueError) as exc:
                raise DataIntegrityError("malformed funding response item") from exc
            if funding_time < cursor:
                raise DataIntegrityError("non-progressing funding page")
            if funding_time <= previous_time:
                raise DataIntegrityError("non-monotonic funding page")
            page_times.append(funding_time)
            previous_time = funding_time

        response_sha = sha256(response_bytes).hexdigest()
        response_path = output_directory / f"funding-{page_index:04d}.json"
        response_path.write_bytes(response_bytes)

        last_time = page_times[-1]
        receipt_path = output_directory / f"funding-{page_index:04d}.receipt.json"
        response_receipt = {
            "request_start_ms": cursor,
            "request_end_ms": end_ms,
            "request_limit": request_limit,
            "request_params": list(request_params),
            "request_params_sha256": request_signature,
            "response_path": str(response_path),
            "receipt_path": str(receipt_path),
            "response_sha256": response_sha,
            "response_count": page_count,
            "last_funding_time_ms": last_time,
        }
        receipt_bytes = json.dumps(response_receipt, sort_keys=True, separators=(",", ":")).encode("utf-8")
        receipt_path.write_bytes(receipt_bytes)

        done = len(page) < request_limit

        receipts.append(
            FundingPageReceipt(
                request_start_ms=cursor,
                request_end_ms=end_ms,
                request_limit=request_limit,
                request_params=request_params,
                request_params_sha256=request_signature,
                response_path=str(response_path),
                receipt_path=str(receipt_path),
                response_sha256=response_sha,
                response_count=page_count,
                last_funding_time_ms=last_time,
            )
        )

        if done:
            break

        next_cursor = last_time + 1
        if next_cursor == cursor:
            raise DataIntegrityError("non-progressing funding page")
        cursor = next_cursor
        page_index += 1

    return tuple(receipts)


def fetch_raw_bundle(
    window: DateWindow,
    output_dir: str | Path,
    session: Any,
    *,
    sleep: Callable[[float], None] = time.sleep,
) -> RawBundleReceipt:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    archives = []
    for archive_day in _iter_days(window.start_date, window.end_date):
        for kind in KINDS:
            archive_path = output / f"{kind}-{archive_day.isoformat()}.zip"
            ref = _build_archive_ref(kind, archive_day, archive_path, session, sleep=sleep)
            archives.append(download_archive(ref, session, sleep=sleep))

    funding = fetch_funding_pages(window, session=session, output_dir=output / "funding", sleep=sleep)
    return RawBundleReceipt(
        window=window,
        archive_downloads=tuple(archives),
        funding_pages=funding,
    )


def _build_archive_ref(
    kind: str,
    archive_day: date_type,
    output_path: Path,
    session: Any,
    *,
    sleep: Callable[[float], None] = time.sleep,
) -> ArchiveRef:
    url = archive_url(kind, archive_day)
    checksum_url = f"{url}.CHECKSUM"
    checksum_response = _request_with_retries(
        session.get,
        checksum_url,
        sleep=sleep,
    )
    checksum = _parse_checksum_body(checksum_response.content, checksum_url)
    return ArchiveRef(
        kind=kind,
        date=archive_day,
        url=url,
        checksum_url=checksum_url,
        raw_path=str(output_path),
        sha256=checksum,
    )

def _window_complete(window: DateWindow, session: Any, *, sleep: Callable[[float], None]) -> bool:
    for day in _iter_days(window.start_date, window.end_date):
        if not _day_complete(day, session=session, sleep=sleep):
            return False
    return True


def _day_complete(day: date_type, *, session: Any, sleep: Callable[[float], None]) -> bool:
    for kind in KINDS:
        for suffix in ("", ".CHECKSUM"):
            url = f"{archive_url(kind, day)}{suffix}"
            status_code = _head_status(session, url, allow_not_found=True, sleep=sleep)
            if status_code != 200:
                return False
    return True


def _head_status(
    session: Any,
    url: str,
    *,
    allow_not_found: bool,
    sleep: Callable[[float], None],
) -> int:
    response = _request_with_retries(
        session.head,
        url,
        sleep=sleep,
        allow_not_found=allow_not_found,
    )
    return response.status_code


def _request_with_retries(
    request_fn: Callable[..., Any],
    url: str,
    *,
    sleep: Callable[[float], None],
    allow_not_found: bool = False,
    **kwargs: Any,
) -> Any:
    for attempt in range(MAX_RETRIES):
        response = request_fn(url, **kwargs)
        status_code = getattr(response, "status_code", None)
        if status_code is None:
            raise DataIntegrityError("session response missing status_code")
        if 200 <= status_code < 300:
            return response
        if allow_not_found and status_code == 404:
            return response
        if status_code in (429,) or 500 <= status_code <= 599:
            if attempt == MAX_RETRIES - 1:
                break
            sleep(2 ** attempt)
            continue
        raise DataIntegrityError(f"{request_fn.__name__} {url} failed with status {status_code}")
    raise DataIntegrityError(f"{request_fn.__name__} {url} exceeded {MAX_RETRIES} retries")


def _parse_checksum_body(body: bytes, url: str) -> str:
    text = body.decode("utf-8", errors="replace").strip()
    if not text:
        raise DataIntegrityError(f"empty checksum body for {url}")
    token = text.split()[0]
    if len(token) != 64 or not all(c in "0123456789abcdef" for c in token):
        raise DataIntegrityError(f"invalid checksum format for {url}")
    return token


def _to_epoch_ms(when: date_type, endpoint: str) -> int:
    day_start = datetime.combine(when, datetime.min.time(), tzinfo=timezone.utc)
    day_end = day_start + timedelta(days=1) - timedelta(milliseconds=1)
    if endpoint == "start":
        return int(day_start.timestamp() * 1000)
    if endpoint == "end":
        return int(day_end.timestamp() * 1000)
    raise ValueError(f"unknown endpoint: {endpoint}")


def _extract_funding_time(item: Any) -> int:
    if not isinstance(item, dict):
        raise TypeError("funding item must be a dict")
    time_value = item.get("fundingTime")
    if time_value is None:
        raise KeyError("fundingTime")
    return int(time_value)


def _iter_days(start: date_type, end: date_type) -> Iterable[date_type]:
    if end < start:
        return iter(())
    return (start + timedelta(days=offset) for offset in range((end - start).days + 1))
