from __future__ import annotations

from bisect import bisect_left
from collections import deque
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from datetime import date
from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext
import heapq

from research.microstructure.events import TradePrint

from .contracts import BookTicker, VerifiedBundle


_BPS = Decimal("10000")
_ZERO = Decimal("0")
_HORIZONS_MS = (1_000, 5_000, 60_000)
_MODEL_FEATURES = (
    "midpoint",
    "spread_bps",
    "imbalance",
    "microprice_offset_bps",
    "trade_flow",
    "realized_vol_bps",
    "displayed_liquidity_quote",
)

# All arithmetic that contributes to a public feature, label, fitted value, or
# prediction runs in this context.  Copying it with localcontext keeps caller
# precision/flags isolated and leaves the process-wide Decimal context untouched.
_DECIMAL_CONTEXT = Context(
    prec=50,
    Emin=-999_999,
    Emax=999_999,
    capitals=1,
    clamp=0,
)
_DECIMAL_CONTEXT.traps[InvalidOperation] = True
_DECIMAL_CONTEXT.traps[DivisionByZero] = True
_DECIMAL_CONTEXT.traps[Overflow] = True


def _require_decimal(value: object, name: str) -> Decimal:
    if isinstance(value, float):
        raise TypeError(f"float values are not allowed for {name}")
    if not isinstance(value, Decimal):
        raise TypeError(f"{name} must be Decimal")
    if not value.is_finite():
        raise ValueError(f"{name} must be finite")
    return value


@dataclass(frozen=True)
class FeatureVector:
    event_time_ms: int
    midpoint: Decimal
    spread_bps: Decimal
    imbalance: Decimal
    microprice_offset_bps: Decimal
    trade_flow: Decimal
    realized_vol_bps: Decimal
    displayed_liquidity_quote: Decimal

    @property
    def microprice(self) -> Decimal:
        with localcontext(_DECIMAL_CONTEXT):
            return self.midpoint * (Decimal("1") + self.microprice_offset_bps / _BPS)


@dataclass(frozen=True)
class CalibrationObservation:
    feature: FeatureVector
    markout_1s_bps: Decimal
    markout_5s_bps: Decimal
    markout_60s_bps: Decimal
    bundle_start_date: date = date.min


@dataclass(frozen=True)
class SignalPrediction:
    direction: str
    confidence: Decimal
    markout_1s_bps: Decimal
    markout_5s_bps: Decimal
    markout_60s_bps: Decimal


def _feature_tuple(feature: FeatureVector) -> tuple[Decimal, ...]:
    return tuple(_require_decimal(getattr(feature, name), name) for name in _MODEL_FEATURES)


class CausalFeatureState:
    def __init__(
        self,
        *,
        trade_half_life_ms: int = 1_000,
        vol_window_ms: int = 5_000,
        max_book_age_ms: int = 5_000,
    ) -> None:
        for name, value in (
            ("trade_half_life_ms", trade_half_life_ms),
            ("vol_window_ms", vol_window_ms),
            ("max_book_age_ms", max_book_age_ms),
        ):
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        self.trade_half_life_ms = trade_half_life_ms
        self.vol_window_ms = vol_window_ms
        self.max_book_age_ms = max_book_age_ms
        self._book: BookTicker | None = None
        self._previous_midpoint: Decimal | None = None
        self._returns: deque[tuple[int, Decimal]] = deque()
        self._trade_flow = _ZERO
        self._trade_flow_time_ms: int | None = None
        self._last_event_key: tuple[int, int, int] | None = None

    def _advance(self, key: tuple[int, int, int]) -> None:
        if self._last_event_key is not None and key < self._last_event_key:
            raise ValueError("event order must be nondecreasing with books before trades")
        self._last_event_key = key

    def _evict_returns(self, event_time_ms: int) -> None:
        cutoff = event_time_ms - self.vol_window_ms
        while self._returns and self._returns[0][0] < cutoff:
            self._returns.popleft()

    def observe_book(self, book: BookTicker) -> None:
        self._advance((book.event_time_ms, 0, book.update_id))
        values = (
            _require_decimal(book.bid_price, "bid_price"),
            _require_decimal(book.bid_quantity, "bid_quantity"),
            _require_decimal(book.ask_price, "ask_price"),
            _require_decimal(book.ask_quantity, "ask_quantity"),
        )
        bid, bid_quantity, ask, ask_quantity = values
        if (
            bid <= _ZERO
            or ask <= _ZERO
            or bid_quantity <= _ZERO
            or ask_quantity <= _ZERO
            or bid >= ask
        ):
            self._book = None
            self._previous_midpoint = None
            self._returns.clear()
            return

        with localcontext(_DECIMAL_CONTEXT):
            midpoint = (bid + ask) / Decimal("2")
            if self._previous_midpoint is not None:
                signed_return_bps = (
                    (midpoint - self._previous_midpoint) / self._previous_midpoint * _BPS
                )
                self._returns.append((book.event_time_ms, signed_return_bps))
        self._previous_midpoint = midpoint
        self._book = book
        self._evict_returns(book.event_time_ms)

    def _decayed_trade_flow(self, event_time_ms: int) -> Decimal:
        if self._trade_flow_time_ms is None:
            return _ZERO
        elapsed = event_time_ms - self._trade_flow_time_ms
        if elapsed < 0:
            raise ValueError("snapshot cannot read future events")
        if elapsed == 0 or self._trade_flow == _ZERO:
            return self._trade_flow
        with localcontext(_DECIMAL_CONTEXT):
            exponent = Decimal(elapsed) / Decimal(self.trade_half_life_ms)
            return self._trade_flow * (Decimal("0.5") ** exponent)

    def observe_trade(self, trade: TradePrint) -> None:
        self._advance((trade.event_time_ms, 1, trade.sequence))
        price = _require_decimal(trade.price, "trade price")
        quantity = _require_decimal(trade.quantity, "trade quantity")
        self._trade_flow = self._decayed_trade_flow(trade.event_time_ms)
        self._trade_flow_time_ms = trade.event_time_ms
        if price <= _ZERO or quantity <= _ZERO:
            return
        with localcontext(_DECIMAL_CONTEXT):
            self._trade_flow += -quantity if trade.buyer_is_maker else quantity

    def snapshot(self, event_time_ms: int) -> FeatureVector | None:
        if self._last_event_key is not None and event_time_ms < self._last_event_key[0]:
            raise ValueError("snapshot cannot read future events")
        book = self._book
        if book is None or event_time_ms - book.event_time_ms > self.max_book_age_ms:
            return None

        bid = book.bid_price
        ask = book.ask_price
        bid_quantity = book.bid_quantity
        ask_quantity = book.ask_quantity
        active_returns = tuple(
            value
            for timestamp, value in self._returns
            if timestamp >= event_time_ms - self.vol_window_ms
        )
        with localcontext(_DECIMAL_CONTEXT):
            total_quantity = bid_quantity + ask_quantity
            midpoint = (bid + ask) / Decimal("2")
            imbalance = (bid_quantity - ask_quantity) / total_quantity
            microprice = (ask * bid_quantity + bid * ask_quantity) / total_quantity
            realized_vol = _ZERO
            if active_returns:
                mean_square = sum(
                    (value * value for value in active_returns),
                    _ZERO,
                ) / Decimal(len(active_returns))
                realized_vol = mean_square.sqrt()
            spread_bps = (ask - bid) / midpoint * _BPS
            microprice_offset_bps = (microprice - midpoint) / midpoint * _BPS
            trade_flow = self._decayed_trade_flow(event_time_ms)
            displayed_liquidity_quote = (
                bid * bid_quantity + ask * ask_quantity
            )
        return FeatureVector(
            event_time_ms=event_time_ms,
            midpoint=midpoint,
            spread_bps=spread_bps,
            imbalance=imbalance,
            microprice_offset_bps=microprice_offset_bps,
            trade_flow=trade_flow,
            realized_vol_bps=realized_vol,
            displayed_liquidity_quote=displayed_liquidity_quote,
        )


def _window_bounds_ms(bundle: VerifiedBundle) -> tuple[int, int]:
    epoch = date(1970, 1, 1)
    window = bundle.manifest.window
    start_ms = (window.start_date - epoch).days * 86_400_000
    end_ms = ((window.end_date - epoch).days + 1) * 86_400_000 - 1
    return start_ms, end_ms


def _bounded_events(
    bundle: VerifiedBundle,
    start_ms: int,
    end_ms: int,
) -> Iterator[tuple[int, int, int, BookTicker | TradePrint]]:
    def books() -> Iterator[tuple[int, int, int, BookTicker]]:
        for book in bundle.iter_book_tickers():
            if book.event_time_ms < start_ms:
                continue
            if book.event_time_ms > end_ms:
                return
            yield book.event_time_ms, 0, book.update_id, book

    def trades() -> Iterator[tuple[int, int, int, TradePrint]]:
        for trade in bundle.iter_agg_trades():
            if trade.event_time_ms < start_ms:
                continue
            if trade.event_time_ms > end_ms:
                return
            yield trade.event_time_ms, 1, trade.sequence, trade

    return heapq.merge(books(), trades(), key=lambda item: item[:3])


def _exact_midpoints(
    bundle: VerifiedBundle,
    start_ms: int,
    end_ms: int,
) -> dict[int, Decimal]:
    midpoints: dict[int, Decimal] = {}
    for book in bundle.iter_book_tickers():
        if book.event_time_ms < start_ms:
            continue
        if book.event_time_ms > end_ms:
            break
        bid = _require_decimal(book.bid_price, "bid_price")
        ask = _require_decimal(book.ask_price, "ask_price")
        bid_quantity = _require_decimal(book.bid_quantity, "bid_quantity")
        ask_quantity = _require_decimal(book.ask_quantity, "ask_quantity")
        if (
            bid > _ZERO
            and ask > _ZERO
            and bid_quantity > _ZERO
            and ask_quantity > _ZERO
            and bid < ask
        ):
            with localcontext(_DECIMAL_CONTEXT):
                midpoints[book.event_time_ms] = (bid + ask) / Decimal("2")
        else:
            midpoints.pop(book.event_time_ms, None)
    return midpoints


def _collect_bundle_observations(bundle: VerifiedBundle) -> tuple[CalibrationObservation, ...]:
    start_ms, end_ms = _window_bounds_ms(bundle)
    state = CausalFeatureState(max_book_age_ms=bundle.manifest.max_book_age_ms)
    features: list[FeatureVector] = []
    for event_time_ms, kind, _sequence, payload in _bounded_events(bundle, start_ms, end_ms):
        if kind == 0:
            state.observe_book(payload)
        else:
            state.observe_trade(payload)
        feature = state.snapshot(event_time_ms)
        if feature is not None and event_time_ms + _HORIZONS_MS[-1] <= end_ms:
            features.append(feature)

    midpoints = _exact_midpoints(bundle, start_ms, end_ms)
    result: list[CalibrationObservation] = []
    for feature in features:
        future = tuple(midpoints.get(feature.event_time_ms + horizon) for horizon in _HORIZONS_MS)
        if any(midpoint is None for midpoint in future):
            continue
        with localcontext(_DECIMAL_CONTEXT):
            markouts = tuple(
                (midpoint - feature.midpoint) / feature.midpoint * _BPS
                for midpoint in future
                if midpoint is not None
            )
        result.append(
            CalibrationObservation(
                bundle_start_date=bundle.manifest.window.start_date,
                feature=feature,
                markout_1s_bps=markouts[0],
                markout_5s_bps=markouts[1],
                markout_60s_bps=markouts[2],
            )
        )
    return tuple(result)


def _observation_sort_key(
    observation: CalibrationObservation,
) -> tuple[date, int, tuple[Decimal, ...]]:
    return (
        observation.bundle_start_date,
        observation.feature.event_time_ms,
        _feature_tuple(observation.feature),
    )


def collect_calibration_observations(
    bundles: Iterable[VerifiedBundle],
) -> tuple[CalibrationObservation, ...]:
    observations = [
        observation
        for bundle in bundles
        for observation in _collect_bundle_observations(bundle)
    ]
    return tuple(sorted(observations, key=_observation_sort_key))


@dataclass(frozen=True)
class _QuantileTable:
    feature_name: str
    edges: tuple[Decimal, ...]
    means: tuple[tuple[Decimal, Decimal, Decimal], ...]

    def lookup(self, feature: FeatureVector) -> tuple[Decimal, Decimal, Decimal]:
        value = _require_decimal(getattr(feature, self.feature_name), self.feature_name)
        return self.means[bisect_left(self.edges, value)]


@dataclass(frozen=True)
class QuantileSignalModel:
    quantiles: int
    tables: tuple[_QuantileTable, ...]

    def predict(self, feature: FeatureVector) -> SignalPrediction:
        _feature_tuple(feature)
        estimates = tuple(table.lookup(feature) for table in self.tables)
        with localcontext(_DECIMAL_CONTEXT):
            horizons = tuple(
                sum(values, _ZERO) / Decimal(len(values)) for values in zip(*estimates)
            )
        direction = (
            "buy"
            if horizons[1] > _ZERO
            else "sell"
            if horizons[1] < _ZERO
            else "neutral"
        )
        if direction == "neutral":
            confidence = _ZERO
        else:
            agreeing = sum(
                1
                for estimate in estimates
                if (estimate[1] > _ZERO and direction == "buy")
                or (estimate[1] < _ZERO and direction == "sell")
            )
            with localcontext(_DECIMAL_CONTEXT):
                confidence = Decimal(agreeing) / Decimal(len(estimates))
        return SignalPrediction(direction, confidence, *horizons)

    def canonical_payload(self) -> dict[str, object]:
        if isinstance(self.quantiles, float):
            raise TypeError("float values are not allowed for quantiles")
        if not isinstance(self.quantiles, int) or isinstance(self.quantiles, bool):
            raise TypeError("quantiles must be an integer")
        return {
            "quantiles": self.quantiles,
            "tables": [
                {
                    "feature": table.feature_name,
                    "edges": [str(_require_decimal(edge, "quantile edge")) for edge in table.edges],
                    "means": [
                        [str(_require_decimal(value, "bin mean")) for value in row]
                        for row in table.means
                    ],
                }
                for table in self.tables
            ],
        }


def _fit_table(
    observations: tuple[CalibrationObservation, ...],
    feature_name: str,
    quantiles: int,
) -> _QuantileTable:
    ranked = sorted(
        observations,
        key=lambda item: (
            _require_decimal(getattr(item.feature, feature_name), feature_name),
            item.feature.event_time_ms,
            _feature_tuple(item.feature),
            _require_decimal(item.markout_1s_bps, "markout_1s_bps"),
            _require_decimal(item.markout_5s_bps, "markout_5s_bps"),
            _require_decimal(item.markout_60s_bps, "markout_60s_bps"),
        ),
    )
    values = tuple(_require_decimal(getattr(item.feature, feature_name), feature_name) for item in ranked)
    edges: list[Decimal] = []
    for index in range(1, quantiles):
        boundary = (len(values) * index + quantiles - 1) // quantiles
        if 0 < boundary < len(values) and values[boundary - 1] < values[boundary]:
            edges.append(values[boundary - 1])
    unique_edges = tuple(dict.fromkeys(edges))
    bins: list[list[CalibrationObservation]] = [[] for _ in range(len(unique_edges) + 1)]
    for item in ranked:
        value = _require_decimal(getattr(item.feature, feature_name), feature_name)
        bins[bisect_left(unique_edges, value)].append(item)
    with localcontext(_DECIMAL_CONTEXT):
        means = tuple(
            tuple(
                sum(
                    (_require_decimal(getattr(item, label), label) for item in items),
                    _ZERO,
                )
                / Decimal(len(items))
                for label in ("markout_1s_bps", "markout_5s_bps", "markout_60s_bps")
            )
            for items in bins
        )
    return _QuantileTable(feature_name, unique_edges, means)


def fit_quantile_signal_model(
    observations: Iterable[CalibrationObservation],
    quantiles: int = 5,
) -> QuantileSignalModel:
    if not isinstance(quantiles, int) or isinstance(quantiles, bool) or quantiles < 1:
        raise ValueError("quantiles must be a positive integer")
    source = tuple(observations)
    if not source or len(source) < quantiles:
        raise ValueError("observations must contain at least quantiles rows")
    ordered = tuple(
        sorted(
            source,
            key=lambda item: (
                item.feature.event_time_ms,
                _feature_tuple(item.feature),
                _require_decimal(item.markout_1s_bps, "markout_1s_bps"),
                _require_decimal(item.markout_5s_bps, "markout_5s_bps"),
                _require_decimal(item.markout_60s_bps, "markout_60s_bps"),
            ),
        )
    )
    tables = tuple(_fit_table(ordered, name, quantiles) for name in _MODEL_FEATURES)
    return QuantileSignalModel(quantiles=quantiles, tables=tables)
