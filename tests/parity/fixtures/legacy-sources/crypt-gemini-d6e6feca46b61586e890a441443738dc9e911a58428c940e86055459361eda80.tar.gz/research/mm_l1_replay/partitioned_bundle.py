from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable
import json

from .contracts import DataIntegrityError


@dataclass(frozen=True)
class PartitionStats:
    row_count: int
    byte_count: int
    sha256: str
    min_event_time_ms: int
    max_event_time_ms: int


def write_jsonl_partition(
    destination: Path,
    rows: Iterable[tuple[int, dict[str, Any]]],
) -> PartitionStats:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    digest = sha256()
    row_count = 0
    byte_count = 0
    min_event_time_ms: int | None = None
    max_event_time_ms: int | None = None

    try:
        with temporary.open("wb") as handle:
            for event_time_ms, row in rows:
                payload = (
                    json.dumps(row, sort_keys=True, separators=(",", ":")).encode("utf-8")
                    + b"\n"
                )
                handle.write(payload)
                digest.update(payload)
                row_count += 1
                byte_count += len(payload)
                if min_event_time_ms is None:
                    min_event_time_ms = event_time_ms
                max_event_time_ms = event_time_ms

        if (
            row_count == 0
            or min_event_time_ms is None
            or max_event_time_ms is None
        ):
            raise DataIntegrityError("normalized partition would be empty")
        temporary.replace(destination)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise

    return PartitionStats(
        row_count=row_count,
        byte_count=byte_count,
        sha256=digest.hexdigest(),
        min_event_time_ms=min_event_time_ms,
        max_event_time_ms=max_event_time_ms,
    )


__all__ = ["PartitionStats", "write_jsonl_partition"]
