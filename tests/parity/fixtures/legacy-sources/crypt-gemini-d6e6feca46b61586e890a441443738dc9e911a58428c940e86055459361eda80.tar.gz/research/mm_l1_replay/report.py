"""Deterministic verdict computation and immutable artifact publishing for MM L1 replays."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from decimal import Decimal
from hashlib import sha256
import heapq
from pathlib import Path
from types import MappingProxyType
from .contracts import MarketManifest, canonical_sha256, decimal_json
from .engine import ProfileReplayResult

JSON_NAME = "result.json"
VALIDATION_NAME = "validation.json"
LEDGER_NAME = "ledger.jsonl"
REPORT_NAME = "report.md"


def build_experiment_report(
    result_payload: Mapping[str, object],
    pareto_payload: Mapping[str, object],
) -> str:
    """Render the deterministic engineering-only Pareto experiment summary."""

    frozen = pareto_payload["frozen_candidate_hashes"]
    assert isinstance(frozen, (list, tuple))
    lines = [
        "# MM L1 Fill/Return Pareto Experiment",
        "",
        "- grade: engineering_replay",
        "- decision_grade_eligible: false",
        "- paper_trading_authorized: false",
        "- live_trading_authorized: false",
        f"- completion_passed: {str(bool(result_payload['completion_passed'])).lower()}",
        f"- signal_model_hash: {result_payload['signal_model_hash']}",
        "",
        "## Frozen development representatives",
        "",
    ]
    if frozen:
        lines.extend(f"- {candidate_hash}" for candidate_hash in frozen)
    else:
        lines.append("- none")
    lines.extend(
        [
            "",
            "## Holdout completion rule",
            "",
            "A candidate completes only with at least three times the same-date baseline eligible fill count and liquidation_adjusted_net_pnl no lower than baseline.",
            "Holdout outcomes never calibrate, select, refit, or retune a configuration.",
            "",
        ]
    )
    return "\n".join(lines)


@dataclass(frozen=True)
class ComparisonVerdict:
    classification: str
    gates: Mapping[str, bool]

    def __post_init__(self) -> None:
        if self.classification not in {"engineering_preferred", "keep_baseline"}:
            raise ValueError(f"unsupported classification: {self.classification}")
        object.__setattr__(self, "gates", MappingProxyType(dict(self.gates)))


@dataclass(frozen=True)
class ComparisonPanel:
    name: str
    baseline: ProfileReplayResult
    lr1: ProfileReplayResult
    verdict: ComparisonVerdict | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "verdict", evaluate_lr1(self.baseline, self.lr1))


@dataclass(frozen=True)
class EngineeringRun:
    manifest: MarketManifest
    primary: ComparisonPanel
    diagnostic: ComparisonPanel | None = None

    def __post_init__(self) -> None:
        if self.manifest.grade != "engineering_replay":
            raise ValueError("engineering artifacts require grade=engineering_replay")
        for field in (
            "decision_grade_eligible",
            "paper_trading_authorized",
            "live_trading_authorized",
        ):
            if self.manifest.authorization.get(field) is not False:
                raise ValueError(f"engineering artifacts require {field}=false")


@dataclass(frozen=True)
class ArtifactSet:
    ledger: Path
    result: Path
    validation: Path
    report: Path
    canonical_hash: str


def evaluate_lr1(baseline: ProfileReplayResult, lr1: ProfileReplayResult) -> ComparisonVerdict:
    terminal_gate = _terminal_inventory_gate(baseline.terminal_inventory_quote, lr1.terminal_inventory_quote)
    gates = {
        "integrity": bool(baseline.integrity_passed and lr1.integrity_passed),
        "net_return": lr1.net_return >= baseline.net_return,
        "max_drawdown": lr1.max_drawdown <= baseline.max_drawdown * Decimal("1.25"),
        "fill_rate": lr1.fill_rate >= baseline.fill_rate * Decimal("1.25"),
        "markout_60s": lr1.average_markout_60s_bps is not None and lr1.average_markout_60s_bps >= Decimal("0"),
        "partial_fill_ratio": lr1.partial_fill_ratio <= Decimal("0.35"),
        "terminal_inventory": terminal_gate,
        "limitations_declared": not (baseline.undeclared_limitations or lr1.undeclared_limitations),
    }
    classification = "engineering_preferred" if all(gates.values()) else "keep_baseline"
    return ComparisonVerdict(classification=classification, gates=MappingProxyType(dict(gates)))


def _terminal_inventory_gate(baseline_terminal: Decimal, lr1_terminal: Decimal) -> bool:
    if baseline_terminal == 0:
        return lr1_terminal == 0
    return abs(lr1_terminal) <= abs(baseline_terminal) * Decimal("1.10")


def build_result(run: EngineeringRun) -> Mapping[str, object]:
    manifest_payload = _manifest_payload(run.manifest)
    manifest_hash = canonical_sha256(manifest_payload)
    primary_panel = _panel_payload(run.primary)
    diagnostic_panel = _panel_payload(run.diagnostic) if run.diagnostic is not None else None

    result: dict[str, object] = {
        "grade": "engineering_replay",
        "decision_grade_eligible": False,
        "paper_trading_authorized": False,
        "live_trading_authorized": False,
        "manifest_hash": manifest_hash,
        "manifest": manifest_payload,
        "source_hashes": {
            "manifest": _manifest_source_hashes(run.manifest),
        },
        "profile_hashes": {
            "primary": {
                "baseline": run.primary.baseline.profile.source_hash,
                "lr1": run.primary.lr1.profile.source_hash,
                "canonical": {
                    "baseline": canonical_sha256(run.primary.baseline.profile.canonical_payload()),
                    "lr1": canonical_sha256(run.primary.lr1.profile.canonical_payload()),
                },
            }
        },
        "primary_panel": primary_panel,
        "primary_panel_name": run.primary.name,
        "classification": run.primary.verdict.classification if run.primary.verdict else "keep_baseline",
        "gates": dict(run.primary.verdict.gates) if run.primary.verdict else {},
        "limitations": {
            "primary": _limitations_payload(run.primary),
            "diagnostic": _limitations_payload(run.diagnostic),
        },
        "diagnostic_panel": diagnostic_panel,
    }

    if run.diagnostic is not None:
        result["profile_hashes"]["diagnostic"] = {
            "baseline": run.diagnostic.baseline.profile.source_hash,
            "lr1": run.diagnostic.lr1.profile.source_hash,
            "canonical": {
                "baseline": canonical_sha256(run.diagnostic.baseline.profile.canonical_payload()),
                "lr1": canonical_sha256(run.diagnostic.lr1.profile.canonical_payload()),
            },
        }

    return result


def _build_validation(run: EngineeringRun, result_payload: Mapping[str, object], canonical_hash: str | None = None) -> dict[str, object]:
    diagnostic_panel = result_payload.get("diagnostic_panel")
    validation: dict[str, object] = {
        "grade": "engineering_replay",
        "decision_grade_eligible": False,
        "paper_trading_authorized": False,
        "live_trading_authorized": False,
        "manifest_hash": result_payload["manifest_hash"],
        "classification": result_payload["classification"],
        "gates": result_payload["gates"],
        "limitations": result_payload["limitations"],
        "fees": {
            "primary": {
                "baseline": run.primary.baseline.maker_fees,
                "lr1": run.primary.lr1.maker_fees,
            }
        },
        "funding": {
            "primary": {
                "baseline": run.primary.baseline.funding_pnl,
                "lr1": run.primary.lr1.funding_pnl,
            }
        },
        "inventory": {
            "primary": {
                "baseline": run.primary.baseline.terminal_inventory_quote,
                "lr1": run.primary.lr1.terminal_inventory_quote,
            }
        },
        "markout": {
            "primary": {
                "baseline_60s": run.primary.baseline.average_markout_60s_bps,
                "lr1_60s": run.primary.lr1.average_markout_60s_bps,
            }
        },
        "stale_gap_metrics": {
            "primary": {
                "baseline": run.primary.baseline.excluded_stale_book_ms,
                "lr1": run.primary.lr1.excluded_stale_book_ms,
            }
        },
        "panel_summary": {
            "primary": {
                "name": run.primary.name,
                "classification": run.primary.verdict.classification if run.primary.verdict else "",
            },
            "diagnostic": {
                "name": diagnostic_panel["name"] if isinstance(diagnostic_panel, dict) else None,
                "classification": diagnostic_panel.get("classification") if isinstance(diagnostic_panel, dict) else None,
            }
            if run.diagnostic is not None
            else None,
        },
        "source_hashes": result_payload["source_hashes"],
        "profile_hashes": result_payload["profile_hashes"],
    }
    if canonical_hash is not None:
        validation["canonical_hash"] = canonical_hash
    return validation


def write_artifacts(run: EngineeringRun, output_dir: str | Path) -> ArtifactSet:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    result_payload = dict(build_result(run))
    validation_payload = _build_validation(run, result_payload)

    # hash uses canonical component bytes without any self-referential hash field
    result_bytes = _json_body({k: v for k, v in result_payload.items() if k != "canonical_hash"})
    validation_bytes = _json_body({k: v for k, v in validation_payload.items() if k != "canonical_hash"})
    manifest_hash = str(result_payload["manifest_hash"])

    ledger_path = output_path / LEDGER_NAME
    temporary_ledger_path = output_path / f".{LEDGER_NAME}.tmp"
    canonical_digest = sha256(manifest_hash.encode("utf-8"))
    ledger_row_count = 0
    with temporary_ledger_path.open("wb") as ledger_handle:
        for row in _iter_ledger_rows(run):
            line = (decimal_json(row) + "\n").encode("utf-8")
            ledger_handle.write(line)
            canonical_digest.update(line)
            ledger_row_count += 1
    temporary_ledger_path.replace(ledger_path)
    canonical_digest.update(result_bytes)
    canonical_digest.update(validation_bytes)
    canonical_hash = canonical_digest.hexdigest()

    result_payload["canonical_hash"] = canonical_hash
    validation_payload["canonical_hash"] = canonical_hash

    result_bytes = _json_text(result_payload)
    validation_bytes = _json_text(validation_payload)
    report_bytes = _markdown_report(run, result_payload, ledger_row_count).encode("utf-8")

    result_path = output_path / JSON_NAME
    validation_path = output_path / VALIDATION_NAME
    report_path = output_path / REPORT_NAME

    result_path.write_bytes(result_bytes)
    validation_path.write_bytes(validation_bytes)
    report_path.write_bytes(report_bytes)

    return ArtifactSet(
        ledger=ledger_path,
        result=result_path,
        validation=validation_path,
        report=report_path,
        canonical_hash=canonical_hash,
    )


def _iter_ledger_rows(run: EngineeringRun) -> Iterable[Mapping[str, object]]:
    def tagged_rows(
        rows: Iterable[object],
        *,
        panel_name: str,
        profile_name: str,
    ) -> Iterable[Mapping[str, object]]:
        for row in rows:
            yield {
                "event_time_ms": row.event_time_ms,
                "event_type": row.event_type,
                "sequence": row.sequence,
                "panel": panel_name,
                "profile": profile_name,
                "side": row.side,
                "level_id": row.level_id,
                "price": row.price,
                "quantity": row.quantity,
                "tag": row.tag,
                "queue_ahead": row.queue_ahead,
                "remaining_quantity": row.remaining_quantity,
                "reason": row.reason,
            }

    streams: list[Iterable[Mapping[str, object]]] = []
    for panel_name, panel in (("primary", run.primary), ("diagnostic", run.diagnostic)):
        if panel is None:
            continue
        for result in (panel.baseline, panel.lr1):
            rows = result.ledger.iter_rows()
            if result.ledger.path is None:
                rows = iter(sorted(rows, key=lambda row: (row.event_time_ms, row.sequence)))
            streams.append(
                tagged_rows(
                    rows,
                    panel_name=panel_name,
                    profile_name=result.profile.name,
                )
            )
    return heapq.merge(
        *streams,
        key=lambda row: (
            row["event_time_ms"],
            row["event_type"],
            row["profile"],
            row["sequence"],
        ),
    )


def _manifest_payload(manifest: MarketManifest) -> dict[str, object]:
    files = [
        {
            "kind": item.kind,
            "date": item.date,
            "sha256": item.sha256,
        }
        for item in sorted(manifest.files, key=lambda item: (item.kind, item.date.isoformat()))
    ]
    return {
        "symbol": manifest.symbol,
        "window": {
            "start_date": manifest.window.start_date,
            "end_date": manifest.window.end_date,
        },
        "files": files,
        "max_book_age_ms": manifest.max_book_age_ms,
        "max_joint_silence_ms": manifest.max_joint_silence_ms,
        "grade": manifest.grade,
        "coverage": manifest.coverage,
        "funding_bounds": manifest.funding_bounds,
        "exact_duplicates": manifest.exact_duplicates,
        "authorization": manifest.authorization,
    }


def _manifest_source_hashes(manifest: MarketManifest) -> list[dict[str, object]]:
    return [
        {
            "kind": item.kind,
            "date": item.date,
            "sha256": item.sha256,
        }
        for item in sorted(
            manifest.files,
            key=lambda item: (item.kind, item.date.isoformat(), item.sha256),
        )
    ]


def _limitations_payload(panel: ComparisonPanel | None) -> dict[str, object] | None:
    if panel is None:
        return None
    return {
        "baseline": list(panel.baseline.limitations),
        "lr1": list(panel.lr1.limitations),
        "baseline_undeclared": panel.baseline.undeclared_limitations,
        "lr1_undeclared": panel.lr1.undeclared_limitations,
    }


def _panel_payload(panel: ComparisonPanel | None) -> dict[str, object] | None:
    if panel is None:
        return None

    return {
        "name": panel.name,
        "classification": panel.verdict.classification if panel.verdict else "keep_baseline",
        "gates": dict(panel.verdict.gates) if panel.verdict else {},
        "baseline": {
            "profile": panel.baseline.profile.name,
            "integrity_passed": panel.baseline.integrity_passed,
            "net_return": panel.baseline.net_return,
            "limitations": list(panel.baseline.limitations),
            "undeclared_limitations": panel.baseline.undeclared_limitations,
            "metrics": _metrics_payload(panel.baseline),
        },
        "lr1": {
            "profile": panel.lr1.profile.name,
            "integrity_passed": panel.lr1.integrity_passed,
            "net_return": panel.lr1.net_return,
            "limitations": list(panel.lr1.limitations),
            "undeclared_limitations": panel.lr1.undeclared_limitations,
            "metrics": _metrics_payload(panel.lr1),
        },
        "fees": {
            "baseline": panel.baseline.maker_fees,
            "lr1": panel.lr1.maker_fees,
        },
        "funding": {
            "baseline": panel.baseline.funding_pnl,
            "lr1": panel.lr1.funding_pnl,
        },
        "inventory": {
            "baseline": panel.baseline.terminal_inventory_quote,
            "lr1": panel.lr1.terminal_inventory_quote,
        },
        "markout": {
            "baseline_60s": panel.baseline.average_markout_60s_bps,
            "lr1_60s": panel.lr1.average_markout_60s_bps,
        },
        "stale_gap_metrics": {
            "baseline_excluded_stale_ms": panel.baseline.excluded_stale_book_ms,
            "lr1_excluded_stale_ms": panel.lr1.excluded_stale_book_ms,
        },
    }


def _metrics_payload(result: ProfileReplayResult) -> dict[str, object]:
    return {
        "fill_count": result.fill_count,
        "quote_create_attempts": result.quote_create_attempts,
        "fill_rate": result.fill_rate,
        "partial_fill_ratio": result.partial_fill_ratio,
        "max_drawdown": result.max_drawdown,
        "terminal_inventory_quote": result.terminal_inventory_quote,
        "markout_1s_bps": result.average_markout_1s_bps,
        "markout_5s_bps": result.average_markout_5s_bps,
        "markout_60s_bps": result.average_markout_60s_bps,
        "markout_1s_eligible_count": result.markout_1s_eligible_count,
        "markout_1s_missing_count": result.markout_1s_missing_count,
        "markout_5s_eligible_count": result.markout_5s_eligible_count,
        "markout_5s_missing_count": result.markout_5s_missing_count,
        "markout_60s_eligible_count": result.markout_60s_eligible_count,
        "markout_60s_missing_count": result.markout_60s_missing_count,
        "excluded_stale_book_ms": result.excluded_stale_book_ms,
        "maker_fees": result.maker_fees,
        "funding_pnl": result.funding_pnl,
        "realized_pnl": result.realized_pnl,
        "unrealized_pnl": result.unrealized_pnl,
        "net_pnl": result.net_pnl,
        "cancel_reasons": result.cancel_reasons,
        "cancel_reasons_count": sum(result.cancel_reasons.values()),
    }


def _json_body(payload: Mapping[str, object]) -> bytes:
    return decimal_json(payload).encode("utf-8")


def _json_text(payload: Mapping[str, object]) -> bytes:
    return (decimal_json(payload) + "\n").encode("utf-8")


def _markdown_report(run: EngineeringRun, result_payload: Mapping[str, object], ledger_row_count: int) -> str:
    gates = result_payload["gates"]
    gate_table = ["| Gate | Pass |", "| --- | --- |"]
    for key in sorted(gates):
        gate_table.append(f"| {key} | {'PASS' if bool(gates[key]) else 'FAIL'} |")
    return "\n".join(
        [
            "# MM L1 Deterministic Engineering Replay",
            "",
            f"classification: {result_payload['classification']}",
            f"canonical_hash: {result_payload['canonical_hash']}",
            "grade: engineering_replay",
            "decision_grade_eligible: false",
            "paper_trading_authorized: false",
            "live_trading_authorized: false",
            "",
            "| Metric | Value |",
            "| --- | --- |",
            f"| manifest_hash | {result_payload['manifest_hash']} |",
            f"| panel | {run.primary.name} |",
            f"| ledger_rows | {ledger_row_count} |",
            "",
            *gate_table,
            "",
            "```json",
            decimal_json(result_payload),
            "```",
        ]
    )


__all__ = [
    "ComparisonVerdict",
    "ComparisonPanel",
    "EngineeringRun",
    "ArtifactSet",
    "evaluate_lr1",
    "build_result",
    "write_artifacts",
    "JSON_NAME",
    "VALIDATION_NAME",
    "LEDGER_NAME",
    "REPORT_NAME",
    "decimal_json",
    "canonical_sha256",
]
