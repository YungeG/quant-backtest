"""Deterministic Pareto selection for MM L1 holdout candidates."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from functools import cmp_to_key
from typing import Iterable


@dataclass(frozen=True)
class CandidateSummary:
    """Canonical objective values and validity findings for one candidate."""

    candidate_hash: str
    eligible_fill_count: int
    liquidation_adjusted_net_pnl: Decimal | None
    validity_reasons: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.candidate_hash, str):
            raise TypeError("candidate_hash must be a string")
        if not self.candidate_hash or self.candidate_hash.strip() != self.candidate_hash:
            raise ValueError("candidate_hash must be a nonempty canonical string")
        if type(self.eligible_fill_count) is not int:
            raise TypeError("eligible_fill_count must be an integer")
        if self.eligible_fill_count < 0:
            raise ValueError("eligible_fill_count must be nonnegative")

        pnl = self.liquidation_adjusted_net_pnl
        if pnl is not None:
            if not isinstance(pnl, Decimal):
                raise TypeError("liquidation_adjusted_net_pnl must be Decimal or None")
            if not pnl.is_finite():
                raise ValueError("liquidation_adjusted_net_pnl must be finite")

        reasons = self.validity_reasons
        if isinstance(reasons, (str, bytes)):
            raise TypeError("validity_reasons must be an iterable of strings")
        try:
            frozen_reasons = tuple(reasons)
        except TypeError as exc:
            raise TypeError("validity_reasons must be an iterable of strings") from exc
        for reason in frozen_reasons:
            if not isinstance(reason, str):
                raise TypeError("validity reasons must be strings")
            if not reason or reason.strip() != reason:
                raise ValueError("validity reasons must be nonempty canonical strings")
        object.__setattr__(self, "validity_reasons", tuple(sorted(set(frozen_reasons))))

    @property
    def is_valid(self) -> bool:
        """Whether this candidate is eligible for selection under the design."""

        return (
            not self.validity_reasons
            and self.liquidation_adjusted_net_pnl is not None
            and self.liquidation_adjusted_net_pnl >= 0
        )


@dataclass(frozen=True)
class ParetoResult:
    """Stable frontier, optional representatives, and holdout completion gate."""

    frontier: tuple[CandidateSummary, ...]
    return_point: CandidateSummary | None
    throughput_point: CandidateSummary | None
    balanced_point: CandidateSummary | None
    completion_passed: bool


def _dominates(left: CandidateSummary, right: CandidateSummary) -> bool:
    left_pnl = left.liquidation_adjusted_net_pnl
    right_pnl = right.liquidation_adjusted_net_pnl
    assert left_pnl is not None and right_pnl is not None
    return (
        left.eligible_fill_count >= right.eligible_fill_count
        and left_pnl >= right_pnl
        and (
            left.eligible_fill_count > right.eligible_fill_count
            or left_pnl > right_pnl
        )
    )


def _is_structurally_valid(item: CandidateSummary) -> bool:
    """Whether required finite objective data exists without validity findings."""

    return not item.validity_reasons and item.liquidation_adjusted_net_pnl is not None


_Polynomial = dict[int, int]


def _decimal_polynomial(value: Decimal) -> _Polynomial:
    sign, digits, exponent = value.as_tuple()
    coefficient = 0
    for digit in digits:
        coefficient = coefficient * 10 + digit
    if sign:
        coefficient = -coefficient
    return {} if not coefficient else {exponent: coefficient}


def _polynomial_add(left: _Polynomial, right: _Polynomial, scale: int = 1) -> _Polynomial:
    result = dict(left)
    for exponent, coefficient in right.items():
        combined = result.get(exponent, 0) + scale * coefficient
        if combined:
            result[exponent] = combined
        else:
            result.pop(exponent, None)
    return result


def _polynomial_scale(value: _Polynomial, scale: int) -> _Polynomial:
    return {} if not scale else {exponent: scale * coefficient for exponent, coefficient in value.items()}


def _polynomial_multiply(left: _Polynomial, right: _Polynomial) -> _Polynomial:
    result: _Polynomial = {}
    for left_exponent, left_coefficient in left.items():
        for right_exponent, right_coefficient in right.items():
            exponent = left_exponent + right_exponent
            coefficient = result.get(exponent, 0) + left_coefficient * right_coefficient
            if coefficient:
                result[exponent] = coefficient
            else:
                result.pop(exponent, None)
    return result


def _integer_digit_count(value: int) -> int:
    """Count base-10 digits without Python's integer/string safety limit."""

    if not value:
        return 1
    return Decimal(abs(value)).adjusted() + 1


def _polynomial_sign(value: _Polynomial) -> int:
    """Return the exact sign without expanding irrelevant exponent gaps."""

    terms = [(exponent, coefficient) for exponent, coefficient in value.items() if coefficient]
    if not terms:
        return 0
    if len(terms) == 1:
        return 1 if terms[0][1] > 0 else -1

    ranked = sorted(
        terms,
        key=lambda term: term[0] + _integer_digit_count(term[1]) - 1,
        reverse=True,
    )
    leading_exponent, leading_coefficient = ranked[0]
    leading_adjusted = leading_exponent + _integer_digit_count(leading_coefficient) - 1
    remainder_adjusted = max(
        exponent + _integer_digit_count(coefficient) - 1
        for exponent, coefficient in ranked[1:]
    )
    if leading_adjusted > remainder_adjusted + _integer_digit_count(len(ranked) - 1):
        return 1 if leading_coefficient > 0 else -1

    minimum_exponent = min(exponent for exponent, _ in terms)
    exact = sum(
        coefficient * 10 ** (exponent - minimum_exponent)
        for exponent, coefficient in terms
    )
    return (exact > 0) - (exact < 0)


def _balanced_point(frontier: tuple[CandidateSummary, ...]) -> CandidateSummary | None:
    if not frontier:
        return None
    if len(frontier) <= 2:
        # One point is ideal. Two distinct non-dominated points are opposing
        # normalized endpoints and therefore have exactly equal distance.
        return min(frontier, key=lambda item: item.candidate_hash)

    min_fills = min(item.eligible_fill_count for item in frontier)
    max_fills = max(item.eligible_fill_count for item in frontier)
    if min_fills == max_fills:
        return min(frontier, key=lambda item: item.candidate_hash)
    pnls = tuple(item.liquidation_adjusted_net_pnl for item in frontier)
    assert all(pnl is not None for pnl in pnls)
    finite_pnls = tuple(pnl for pnl in pnls if pnl is not None)
    min_pnl = min(finite_pnls)
    max_pnl = max(finite_pnls)
    if min_pnl == max_pnl:
        return min(frontier, key=lambda item: item.candidate_hash)

    fill_width = max_fills - min_fills
    maximum_pnl_polynomial = _decimal_polynomial(max_pnl)
    minimum_pnl_polynomial = _decimal_polynomial(min_pnl)
    pnl_width = _polynomial_add(
        maximum_pnl_polynomial,
        minimum_pnl_polynomial,
        scale=-1,
    )
    pnl_width_squared = _polynomial_multiply(pnl_width, pnl_width)
    pnl_distances_squared = tuple(
        _polynomial_multiply(distance, distance)
        for distance in (
            _polynomial_add(
                maximum_pnl_polynomial,
                _decimal_polynomial(pnl),
                scale=-1,
            )
            for pnl in finite_pnls
        )
    )

    def compare(left_index: int, right_index: int) -> int:
        left_fill_distance = max_fills - frontier[left_index].eligible_fill_count
        right_fill_distance = max_fills - frontier[right_index].eligible_fill_count
        fill_difference = left_fill_distance**2 - right_fill_distance**2
        pnl_difference = _polynomial_add(
            pnl_distances_squared[left_index],
            pnl_distances_squared[right_index],
            scale=-1,
        )
        difference = _polynomial_add(
            _polynomial_scale(pnl_width_squared, fill_difference),
            _polynomial_scale(pnl_difference, fill_width**2),
        )
        sign = _polynomial_sign(difference)
        if sign:
            return sign
        left_hash = frontier[left_index].candidate_hash
        right_hash = frontier[right_index].candidate_hash
        return (left_hash > right_hash) - (left_hash < right_hash)

    selected_index = min(
        range(len(frontier)),
        key=cmp_to_key(compare),
    )
    return frontier[selected_index]


def select_pareto(
    candidates: Iterable[CandidateSummary],
    baseline: CandidateSummary,
) -> ParetoResult:
    """Select a deterministic frontier and representatives.

    A structurally valid negative baseline is allowed as a comparison threshold,
    but the baseline is not a candidate and therefore never enters the frontier.
    Candidate negative PnL is excluded from both the frontier and completion gate.
    """

    if not isinstance(baseline, CandidateSummary):
        raise TypeError("baseline must be a CandidateSummary")
    if not _is_structurally_valid(baseline):
        raise ValueError("baseline must be structurally valid with finite PnL")

    evaluated = tuple(candidates)
    for item in evaluated:
        if not isinstance(item, CandidateSummary):
            raise TypeError("candidates must contain CandidateSummary values")

    seen_hashes: set[str] = set()
    for item in sorted(evaluated, key=lambda candidate: candidate.candidate_hash):
        if item.candidate_hash in seen_hashes:
            raise ValueError(f"duplicate candidate hash: {item.candidate_hash}")
        seen_hashes.add(item.candidate_hash)

    eligible = tuple(
        sorted(
            (
                item
                for item in evaluated
                if item.is_valid
            ),
            key=lambda item: item.candidate_hash,
        )
    )
    frontier = tuple(
        item
        for item in eligible
        if not any(_dominates(other, item) for other in eligible if other is not item)
    )

    maximum_pnl = max(
        (item.liquidation_adjusted_net_pnl for item in frontier),
        default=None,
    )
    return_point = min(
        (
            item
            for item in frontier
            if item.liquidation_adjusted_net_pnl == maximum_pnl
        ),
        key=lambda item: item.candidate_hash,
        default=None,
    )
    positive = tuple(
        item
        for item in frontier
        if item.liquidation_adjusted_net_pnl is not None
        and item.liquidation_adjusted_net_pnl > 0
    )
    maximum_fills = max(
        (item.eligible_fill_count for item in positive),
        default=None,
    )
    throughput_point = min(
        (item for item in positive if item.eligible_fill_count == maximum_fills),
        key=lambda item: item.candidate_hash,
        default=None,
    )

    baseline_pnl = baseline.liquidation_adjusted_net_pnl
    assert baseline_pnl is not None
    completion_passed = any(
        item.eligible_fill_count >= 3 * baseline.eligible_fill_count
        and item.liquidation_adjusted_net_pnl is not None
        and item.liquidation_adjusted_net_pnl >= baseline_pnl
        for item in eligible
    )

    return ParetoResult(
        frontier=frontier,
        return_point=return_point,
        throughput_point=throughput_point,
        balanced_point=_balanced_point(frontier),
        completion_passed=completion_passed,
    )
