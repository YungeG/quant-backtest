"""Replay profile resolution helpers for MM v2 risk-matched runs."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

import yaml

from deploy.hummingbot_artifacts.controllers_generic.mm_v2_guarded import MMV2GuardedConfig


BASELINE_CONFIG_PATH = Path("deploy/hummingbot_artifacts/conf_controllers/conf_mm_v2_eth.yml")
LR1_CONFIG_PATH = Path("deploy/hummingbot_artifacts/conf_controllers/conf_mm_v2_eth_lr1.yml")

BASELINE_NAME = "baseline_size_matched"
LR1_NAME = "lr1"
CRITICAL_IDENTITY_FIELDS = (
    "id",
    "controller_name",
    "controller_type",
    "connector_name",
    "trading_pair",
)


def _read_yaml_config(path: Path) -> tuple[Mapping[str, Any], str]:
    raw_bytes = path.read_bytes()
    source_hash = sha256(raw_bytes).hexdigest()
    raw = yaml.safe_load(raw_bytes)

    if not isinstance(raw, Mapping):
        raise ValueError(f"{path}: expected YAML mapping, got {type(raw).__name__}")
    if not raw:
        raise ValueError(f"{path}: YAML document is empty")
    return raw, source_hash


def _model_field_names() -> set[str]:
    if hasattr(MMV2GuardedConfig, "model_fields"):
        return set(MMV2GuardedConfig.model_fields.keys())
    return set(getattr(MMV2GuardedConfig, "__fields__").keys())


def _validate_profile_shape(raw: Mapping[str, Any], path: Path) -> None:
    missing = [field for field in CRITICAL_IDENTITY_FIELDS if field not in raw]
    if missing:
        raise ValueError(f"{path}: missing critical identity fields: {', '.join(sorted(missing))}")

    unknown = set(raw) - _model_field_names()
    if unknown:
        raise ValueError(f"{path}: unknown fields: {', '.join(sorted(unknown))}")


def _model_construct(values: Mapping[str, object]) -> MMV2GuardedConfig:
    try:
        if hasattr(MMV2GuardedConfig, "model_validate"):
            return MMV2GuardedConfig.model_validate(dict(values))
        return MMV2GuardedConfig(**dict(values))
    except (ArithmeticError, TypeError, ValueError) as error:
        raise ValueError(error) from error


def _load_profile(path: Path) -> tuple[MMV2GuardedConfig, str]:
    raw, source_hash = _read_yaml_config(path)
    _validate_profile_shape(raw, path)
    config = _model_construct(raw)
    return config, source_hash


def _model_dump(config: MMV2GuardedConfig) -> dict[str, Any]:
    if hasattr(config, "model_dump"):
        return config.model_dump()  # type: ignore[no-any-return]
    return config.dict()  # type: ignore[no-any-return]


def _apply_overrides(
    config: MMV2GuardedConfig,
    *,
    overrides: Mapping[str, object],
) -> MMV2GuardedConfig:
    payload = dict(_model_dump(config))
    payload.update(dict(overrides))
    return _model_construct(payload)


def _baseline_size_matched_overrides(lr1: MMV2GuardedConfig) -> Mapping[str, object]:
    return {
        "id": BASELINE_NAME,
        "total_amount_quote": lr1.total_amount_quote,
        "buy_amounts_pct": list(lr1.buy_amounts_pct),
        "sell_amounts_pct": list(lr1.sell_amounts_pct),
        "min_trade_notional_usdt": lr1.min_trade_notional_usdt,
        "trading_enabled": True,
    }


def make_size_matched_baseline(
    baseline: MMV2GuardedConfig,
    lr1: MMV2GuardedConfig,
) -> MMV2GuardedConfig:
    return _apply_overrides(
        baseline,
        overrides=_baseline_size_matched_overrides(lr1),
    )


def _deep_freeze(value: object) -> object:
    if isinstance(value, MappingProxyType):
        value = dict(value)

    if isinstance(value, Mapping):
        return MappingProxyType({k: _deep_freeze(value[k]) for k in sorted(value)})
    if isinstance(value, list):
        return tuple(_deep_freeze(item) for item in value)
    if isinstance(value, tuple):
        return tuple(_deep_freeze(item) for item in value)
    return value


def _freeze_mapping(value: Mapping[str, object] | None) -> Mapping[str, object]:
    return MappingProxyType(dict(value or ()))


@dataclass(frozen=True, init=False)
class ResolvedProfile:
    name: str
    source_hash: str
    overrides: Mapping[str, object]
    _controller_config_payload: Mapping[str, object] | None = field(init=False, default=None)
    _canonical_payload: Mapping[str, object] | None = field(default=None, init=False)

    def __init__(
        self,
        name: str,
        controller_config: MMV2GuardedConfig,
        source_hash: str,
        overrides: Mapping[str, object],
    ) -> None:
        object.__setattr__(self, "name", str(name))
        object.__setattr__(
            self,
            "_controller_config_payload",
            _deep_freeze(_model_dump(_model_construct(controller_config))),
        )
        object.__setattr__(self, "source_hash", str(source_hash))
        object.__setattr__(self, "overrides", _deep_freeze(dict(overrides)))
        object.__setattr__(
            self,
            "_canonical_payload",
            _deep_freeze(
                {
                    "name": self.name,
                    "source_hash": self.source_hash,
                    "overrides": self.overrides,
                    "controller_config": self._controller_config_payload,
                }
            ),
        )

    @property
    def controller_config(self) -> MMV2GuardedConfig:
        return _model_construct(self._controller_config_payload)

    def canonical_payload(self) -> Mapping[str, object]:
        return MappingProxyType(self._canonical_payload or {})

    def execution_payload(self) -> Mapping[str, object]:
        return MappingProxyType(
            {
                "controller_config": self._controller_config_payload,
            }
        )


@dataclass(frozen=True)
class ReplayProfiles:
    primary: Mapping[str, ResolvedProfile]
    diagnostic: Mapping[str, ResolvedProfile]
    _snapshot: Mapping[str, Mapping[str, object]] | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "primary", _freeze_mapping(dict(self.primary)))
        object.__setattr__(self, "diagnostic", _freeze_mapping(dict(self.diagnostic)))

    @property
    def canonical_profile_snapshot(self) -> Mapping[str, object]:
        if self._snapshot is None:
            snapshot = MappingProxyType(
                {
                    "primary": _freeze_mapping(
                        {
                            name: _deep_freeze(profile.canonical_payload())
                            for name, profile in self.primary.items()
                        }
                    ),
                    "diagnostic": _freeze_mapping(
                        {
                            name: _deep_freeze(profile.canonical_payload())
                            for name, profile in self.diagnostic.items()
                        }
                    ),
                }
            )
            object.__setattr__(self, "_snapshot", snapshot)
        return self._snapshot

    @property
    def canonical_profile_hash(self) -> str:
        if not isinstance(self._snapshot, Mapping):
            _ = self.canonical_profile_snapshot
        return sha256(
            _canonicalize_json(self.canonical_profile_snapshot).encode("utf-8")
        ).hexdigest()


def _canonicalize_json(value: object) -> str:
    def _to_jsonable(input_value: object) -> Any:
        if isinstance(input_value, Enum):
            return _to_jsonable(input_value.value)
        if isinstance(input_value, Decimal):
            return str(input_value)
        if isinstance(input_value, float):
            raise TypeError("floats are not supported in canonical JSON payload")
        if isinstance(input_value, list):
            return [_to_jsonable(item) for item in input_value]
        if isinstance(input_value, tuple):
            return [_to_jsonable(item) for item in input_value]
        if isinstance(input_value, Mapping):
            return {
                str(key): _to_jsonable(input_value[key])
                for key in sorted(input_value)
            }
        if isinstance(input_value, str) or isinstance(input_value, int) or isinstance(input_value, bool):
            return input_value
        if input_value is None:
            return input_value
        raise TypeError(f"unsupported type: {type(input_value)}")

    import json

    return json.dumps(_to_jsonable(value), sort_keys=True, separators=(",", ":"))


def load_profiles_from_paths(
    baseline_path: Path,
    lr1_path: Path,
) -> "ReplayProfiles":
    baseline, baseline_hash = _load_profile(baseline_path)
    lr1, lr1_hash = _load_profile(lr1_path)

    baseline_overrides = _baseline_size_matched_overrides(lr1)

    return ReplayProfiles(
        primary={
            BASELINE_NAME: ResolvedProfile(
                name=BASELINE_NAME,
                controller_config=make_size_matched_baseline(baseline, lr1),
                source_hash=baseline_hash,
                overrides=baseline_overrides,
            ),
            LR1_NAME: ResolvedProfile(
                name=LR1_NAME,
                controller_config=_apply_overrides(lr1, overrides={"trading_enabled": True}),
                source_hash=lr1_hash,
                overrides={"trading_enabled": True},
            ),
        },
        diagnostic={
            "baseline": ResolvedProfile(
                name="baseline",
                controller_config=baseline,
                source_hash=baseline_hash,
                overrides={},
            ),
            LR1_NAME: ResolvedProfile(
                name=LR1_NAME,
                controller_config=lr1,
                source_hash=lr1_hash,
                overrides={},
            ),
        },
    )


def load_profiles(repo_root: Path) -> "ReplayProfiles":
    baseline_path = repo_root / BASELINE_CONFIG_PATH
    lr1_path = repo_root / LR1_CONFIG_PATH
    return load_profiles_from_paths(baseline_path, lr1_path)
