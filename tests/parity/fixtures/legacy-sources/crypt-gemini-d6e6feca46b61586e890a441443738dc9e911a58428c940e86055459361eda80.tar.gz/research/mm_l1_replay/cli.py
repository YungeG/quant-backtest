from __future__ import annotations

from argparse import ArgumentParser
from datetime import date
from pathlib import Path
from typing import Any
import json
import re
import tempfile

from research.mm_l1_replay import (
    DataIntegrityError,
    DateWindow,
    RawBundleReceipt,
    fetch_raw_bundle,
    load_verified_bundle,
    prepare_bundle,
    probe_complete_window,
)
from research.mm_l1_replay.contracts import DownloadReceipt, FundingPageReceipt, canonical_sha256
from research.mm_l1_replay.experiment import (
    load_experiment_grid,
    run_pareto_experiment,
)
from research.mm_l1_replay.profile_runner import (
    parallel_supported,
    run_requested_profiles,
)
from research.mm_l1_replay.profiles import BASELINE_NAME, LR1_NAME, load_profiles
from research.mm_l1_replay.report import ComparisonPanel, EngineeringRun, write_artifacts

_EXIT_SUCCESS = 0
_EXIT_VALIDATION = 2
_EXIT_RETRIEVAL = 3

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _new_requests_session() -> Any:
    import requests  # imported only for fetch path

    return requests.Session()


def _parse_utc_date(value: str) -> date:
    return date.fromisoformat(value)


def _parse_int(value: str) -> int:
    if not isinstance(value, str) or not value.isdigit():
        raise ValueError("days must be a positive integer")
    parsed = int(value)
    if parsed <= 0:
        raise ValueError("days must be positive")
    return parsed


def _parse_workers(value: str) -> int:
    if not isinstance(value, str) or not value.isdigit():
        raise ValueError("workers must be a positive integer")
    parsed = int(value)
    if parsed <= 0:
        raise ValueError("workers must be positive")
    return parsed


def _require_mapping(value: object, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be an object")
    return value


def _require_sequence(value: object, label: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"{label} must be a list")
    return value


def _require_str(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a string")
    return value


def _require_int(value: object, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError(f"{label} must be an integer")
    if value < 0:
        raise ValueError(f"{label} must be non-negative")
    return value


def _validate_sha256(value: object, label: str) -> str:
    text = _require_str(value, label)
    if not _SHA256_RE.fullmatch(text):
        raise ValueError(f"{label} must be a lowercase sha256")
    return text


def _require_exact_fields(payload: dict[str, Any], expected: set[str], label: str) -> None:
    if set(payload) != expected:
        raise ValueError(f"{label} has unexpected or missing fields")


def _canonicalize_relative_path(root: Path, value: str, label: str) -> str:
    candidate = Path(value)
    if candidate.is_absolute():
        raise ValueError(f"{label} must be relative")
    if "\\" in value:
        raise ValueError(f"{label} must use POSIX separators")
    if ".." in candidate.parts:
        raise ValueError(f"{label} must not contain parent traversal")
    normalized = candidate.as_posix()
    if normalized in {"", "."} or normalized.startswith("./"):
        raise ValueError(f"{label} must be a non-empty relative path")
    resolved = (root / candidate).resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError(f"{label} must stay inside raw directory")
    return normalized


def _path_relative_to_root(root: Path, value: str, label: str) -> str:
    try:
        relative = Path(value).resolve().relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"{label} must stay inside raw directory") from exc
    return _canonicalize_relative_path(root, relative.as_posix(), label)


def _normalize_request_params(payload: list[Any], label: str) -> tuple[tuple[str, object], ...]:
    normalized: list[tuple[str, object]] = []
    seen_keys: set[str] = set()
    for index, item in enumerate(payload):
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            raise ValueError(f"{label}[{index}] must be a two-item pair")
        key = _require_str(item[0], f"{label}[{index}].0")
        if not key or key in seen_keys:
            raise ValueError(f"{label}[{index}].0 must be a unique non-empty key")
        seen_keys.add(key)
        value = item[1]
        if isinstance(value, str):
            value = value.strip()
            if not value:
                raise ValueError(f"{label}[{index}].1 must not be empty")
        elif not isinstance(value, (int, bool)) and value is not None:
            raise ValueError(f"{label}[{index}].1 has an unsupported type")
        if isinstance(value, int) and not isinstance(value, bool) and value < 0:
            raise ValueError(f"{label}[{index}].1 must be non-negative")
        normalized.append((key, value))

    return tuple(sorted(normalized, key=lambda pair: pair[0]))


def _load_raw_bundle_receipt(raw_dir: Path) -> RawBundleReceipt:
    root = raw_dir.resolve()
    receipt_path = root / "raw_bundle_receipt.json"
    if not receipt_path.is_file():
        raise ValueError("raw_bundle_receipt.json is missing")

    try:
        receipt_text = receipt_path.read_text(encoding="utf-8")
        payload = json.loads(receipt_text)
    except json.JSONDecodeError as exc:
        raise ValueError("raw_bundle_receipt.json is not valid JSON") from exc

    payload_map = _require_mapping(payload, "raw_bundle_receipt")
    _require_exact_fields(
        payload_map,
        {"window", "archive_downloads", "funding_pages"},
        "raw_bundle_receipt",
    )
    if json.dumps(payload_map, sort_keys=True, separators=(",", ":")) != receipt_text:
        raise ValueError("raw_bundle_receipt.json is not canonical JSON")
    window_payload = _require_mapping(payload_map.get("window"), "window")
    _require_exact_fields(window_payload, {"start_date", "end_date"}, "window")

    start_date = date.fromisoformat(_require_str(window_payload.get("start_date"), "window.start_date"))
    end_date = date.fromisoformat(_require_str(window_payload.get("end_date"), "window.end_date"))
    if start_date > end_date:
        raise ValueError("window is inverted")

    archive_payloads = _require_sequence(payload_map.get("archive_downloads"), "archive_downloads")
    funding_payloads = _require_sequence(payload_map.get("funding_pages"), "funding_pages")

    archives: list[DownloadReceipt] = []
    for index, download_payload in enumerate(archive_payloads):
        item = _require_mapping(download_payload, f"archive_downloads[{index}]")
        _require_exact_fields(
            item,
            {
                "kind",
                "date",
                "url",
                "raw_path",
                "checksum_path",
                "expected_sha256",
                "actual_sha256",
                "byte_count",
            },
            f"archive_downloads[{index}]",
        )
        raw_path = _canonicalize_relative_path(root, _require_str(item.get("raw_path"), f"archive_downloads[{index}].raw_path"), f"archive_downloads[{index}].raw_path")
        checksum_path = _canonicalize_relative_path(
            root,
            _require_str(item.get("checksum_path"), f"archive_downloads[{index}].checksum_path"),
            f"archive_downloads[{index}].checksum_path",
        )
        archives.append(
            DownloadReceipt(
                kind=_require_str(item.get("kind"), f"archive_downloads[{index}].kind"),
                date=date.fromisoformat(_require_str(item.get("date"), f"archive_downloads[{index}].date")),
                url=_require_str(item.get("url"), f"archive_downloads[{index}].url"),
                raw_path=str(root / raw_path),
                checksum_path=str(root / checksum_path),
                expected_sha256=_validate_sha256(item.get("expected_sha256"), f"archive_downloads[{index}].expected_sha256"),
                actual_sha256=_validate_sha256(item.get("actual_sha256"), f"archive_downloads[{index}].actual_sha256"),
                byte_count=_require_int(item.get("byte_count"), f"archive_downloads[{index}].byte_count"),
            )
        )

    funding_pages: list[FundingPageReceipt] = []
    for index, funding_payload in enumerate(funding_payloads):
        item = _require_mapping(funding_payload, f"funding_pages[{index}]")
        _require_exact_fields(
            item,
            {
                "request_start_ms",
                "request_end_ms",
                "request_limit",
                "request_params",
                "request_params_sha256",
                "response_path",
                "receipt_path",
                "response_sha256",
                "response_count",
                "last_funding_time_ms",
            },
            f"funding_pages[{index}]",
        )
        raw_request_params = _require_sequence(
            item.get("request_params"),
            f"funding_pages[{index}].request_params",
        )
        request_params = _normalize_request_params(
            raw_request_params,
            f"funding_pages[{index}].request_params",
        )
        if [list(pair) for pair in request_params] != raw_request_params:
            raise ValueError(f"funding_pages[{index}].request_params must be canonical")
        request_signature = _validate_sha256(item.get("request_params_sha256"), f"funding_pages[{index}].request_params_sha256")
        if request_signature != canonical_sha256(request_params):
            raise ValueError(f"funding_pages[{index}] has a malformed request_params_sha256")

        response_path = _canonicalize_relative_path(
            root,
            _require_str(item.get("response_path"), f"funding_pages[{index}].response_path"),
            f"funding_pages[{index}].response_path",
        )
        receipt_path = _canonicalize_relative_path(
            root,
            _require_str(item.get("receipt_path"), f"funding_pages[{index}].receipt_path"),
            f"funding_pages[{index}].receipt_path",
        )

        funding_pages.append(
            FundingPageReceipt(
                request_start_ms=_require_int(item.get("request_start_ms"), f"funding_pages[{index}].request_start_ms"),
                request_end_ms=_require_int(item.get("request_end_ms"), f"funding_pages[{index}].request_end_ms"),
                request_limit=_require_int(item.get("request_limit"), f"funding_pages[{index}].request_limit"),
                request_params=request_params,
                request_params_sha256=request_signature,
                response_path=str(root / response_path),
                receipt_path=str(root / receipt_path),
                response_sha256=_validate_sha256(item.get("response_sha256"), f"funding_pages[{index}].response_sha256"),
                response_count=_require_int(item.get("response_count"), f"funding_pages[{index}].response_count"),
                last_funding_time_ms=_require_int(
                    item.get("last_funding_time_ms"),
                    f"funding_pages[{index}].last_funding_time_ms",
                ),
            )
        )

    if not archives:
        raise ValueError("archive_downloads is empty")
    if not funding_pages:
        raise ValueError("funding_pages is empty")

    return RawBundleReceipt(
        window=DateWindow(start_date=start_date, end_date=end_date),
        archive_downloads=tuple(archives),
        funding_pages=tuple(funding_pages),
    )


def _receipt_to_payload(receipt: RawBundleReceipt, raw_dir: Path) -> dict[str, Any]:
    return {
        "window": {
            "start_date": receipt.window.start_date.isoformat(),
            "end_date": receipt.window.end_date.isoformat(),
        },
        "archive_downloads": [
            {
                "kind": download.kind,
                "date": download.date.isoformat(),
                "url": download.url,
                "raw_path": _path_relative_to_root(raw_dir, download.raw_path, f"download[{index}].raw_path"),
                "checksum_path": _path_relative_to_root(
                    raw_dir,
                    download.checksum_path,
                    f"download[{index}].checksum_path",
                ),
                "expected_sha256": download.expected_sha256,
                "actual_sha256": download.actual_sha256,
                "byte_count": download.byte_count,
            }
            for index, download in enumerate(receipt.archive_downloads)
        ],
        "funding_pages": [
            {
                "request_start_ms": funding.request_start_ms,
                "request_end_ms": funding.request_end_ms,
                "request_limit": funding.request_limit,
                "request_params": [list(pair) for pair in funding.request_params],
                "request_params_sha256": funding.request_params_sha256,
                "response_path": _path_relative_to_root(raw_dir, funding.response_path, f"funding[{index}].response_path"),
                "receipt_path": _path_relative_to_root(
                    raw_dir,
                    funding.receipt_path,
                    f"funding[{index}].receipt_path",
                ),
                "response_sha256": funding.response_sha256,
                "response_count": funding.response_count,
                "last_funding_time_ms": funding.last_funding_time_ms,
            }
            for index, funding in enumerate(receipt.funding_pages)
        ],
    }


def _write_raw_receipt(receipt: RawBundleReceipt, raw_dir: Path) -> tuple[RawBundleReceipt, Path]:
    payload = _receipt_to_payload(receipt, raw_dir)
    output_path = raw_dir / "raw_bundle_receipt.json"
    output_path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    return _load_raw_bundle_receipt(raw_dir), output_path


def _build_parser() -> ArgumentParser:
    parser = ArgumentParser(description="MM L1 engineering replay workflow")
    subparsers = parser.add_subparsers(dest="command", required=True)

    fetch_parser = subparsers.add_parser("fetch", help="fetch public raw archives and funding pages")
    fetch_parser.add_argument("--as-of", required=True)
    fetch_parser.add_argument("--days", required=True)
    fetch_parser.add_argument("--output-dir", required=True)

    prepare_parser = subparsers.add_parser("prepare", help="normalize raw fetch artifacts into verified bundle")
    prepare_parser.add_argument("--raw-dir", required=True)
    prepare_parser.add_argument("--output-dir", required=True)
    prepare_parser.add_argument("--exchange-rules-dir")

    replay_parser = subparsers.add_parser("replay", help="run engineering replay from verified manifest")
    replay_parser.add_argument("--manifest", required=True)
    replay_parser.add_argument("--output-dir", required=True)
    replay_parser.add_argument(
        "--workers",
        type=_parse_workers,
        default=3 if parallel_supported() else 1,
    )

    optimize_parser = subparsers.add_parser(
        "optimize", help="run engineering-only fill-return Pareto experiment"
    )
    optimize_parser.add_argument("--development-manifests", nargs="+", required=True)
    optimize_parser.add_argument("--holdout-manifests", nargs="+", required=True)
    optimize_parser.add_argument("--grid", required=True)
    optimize_parser.add_argument("--output-dir", required=True)
    optimize_parser.add_argument(
        "--workers",
        type=_parse_workers,
        default=3 if parallel_supported() else 1,
    )
    return parser


def _run_fetch(args: Any) -> int:
    as_of = _parse_utc_date(args.as_of)
    days = _parse_int(args.days)
    output_dir = Path(args.output_dir).resolve()

    session: Any | None = None
    try:
        import requests  # imported only while executing the networked command

        session = _new_requests_session()
        window = probe_complete_window(as_of, days, session)
        print(f"resolved window: {window.start_date.isoformat()} to {window.end_date.isoformat()}")
        receipt = fetch_raw_bundle(window, output_dir, session)
        _, receipt_path = _write_raw_receipt(receipt, output_dir)
        print(f"raw_bundle_receipt_path={receipt_path}")
    except ImportError as exc:
        print(f"request failure: {exc}")
        return _EXIT_RETRIEVAL
    except Exception as exc:
        if "requests" in locals() and isinstance(exc, requests.RequestException):
            print(f"request failure: {exc}")
            return _EXIT_RETRIEVAL
        if isinstance(exc, (DataIntegrityError, ValueError, TypeError, OSError)):
            print(f"validation failure: {exc}")
            return _EXIT_VALIDATION
        raise
    finally:
        if session is not None:
            close = getattr(session, "close", None)
            if callable(close):
                close()
    return _EXIT_SUCCESS


def _run_prepare(args: Any) -> int:
    raw_dir = Path(args.raw_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    exchange_rules_dir = (
        Path(args.exchange_rules_dir).resolve()
        if args.exchange_rules_dir is not None
        else None
    )

    try:
        receipt = _load_raw_bundle_receipt(raw_dir)
        prepare_bundle(receipt, output_dir, exchange_rules_dir=exchange_rules_dir)
        manifest_path = output_dir / "market_manifest.json"
        manifest_payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        print(f"manifest={manifest_path}")
        print(f"manifest_sha256={manifest_payload['manifest_sha256']}")
        return _EXIT_SUCCESS
    except (DataIntegrityError, KeyError, ValueError, TypeError, OSError) as exc:
        print(f"validation failure: {exc}")
        return _EXIT_VALIDATION


def _run_replay(args: Any) -> int:
    manifest = Path(args.manifest)
    output_dir = Path(args.output_dir).resolve()

    try:
        bundle = load_verified_bundle(manifest)
        repo_root = Path(__file__).resolve().parents[2]
        profiles = load_profiles(repo_root)
        output_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(
            prefix=".profile-ledgers-",
            dir=output_dir,
        ) as ledger_dir_name:
            ledger_dir = Path(ledger_dir_name)
            requested = {
                "primary_baseline": profiles.primary[BASELINE_NAME],
                "primary_lr1": profiles.primary[LR1_NAME],
                "diagnostic_baseline": profiles.diagnostic["baseline"],
                "diagnostic_lr1": profiles.diagnostic[LR1_NAME],
            }
            results = run_requested_profiles(
                bundle,
                requested,
                ledger_dir,
                max_workers=args.workers,
            )

            primary_panel = ComparisonPanel(
                name="primary",
                baseline=results["primary_baseline"],
                lr1=results["primary_lr1"],
            )
            diagnostic_panel = ComparisonPanel(
                name="diagnostic",
                baseline=results["diagnostic_baseline"],
                lr1=results["diagnostic_lr1"],
            )

            run = EngineeringRun(
                manifest=bundle.manifest,
                primary=primary_panel,
                diagnostic=diagnostic_panel,
            )
            artifacts = write_artifacts(run, output_dir)

        payload = json.loads(artifacts.result.read_text(encoding="utf-8"))
        print(f"classification={payload['classification']}")
        print(f"manifest_hash={payload['manifest_hash']}")
        print(f"canonical_hash={payload['canonical_hash']}")
        print(f"result={artifacts.result}")
        print(f"validation={artifacts.validation}")
        print(f"ledger={artifacts.ledger}")
        print(f"report={artifacts.report}")
        return _EXIT_SUCCESS
    except (DataIntegrityError, KeyError, ValueError, TypeError, OSError) as exc:
        print(f"validation failure: {exc}")
        return _EXIT_VALIDATION


def _run_optimize(args: Any) -> int:
    try:
        grid = load_experiment_grid(args.grid)
        artifacts = run_pareto_experiment(
            args.development_manifests,
            args.holdout_manifests,
            grid,
            Path(args.output_dir).resolve(),
            workers=args.workers,
        )
        print(f"canonical_hash={artifacts.canonical_hash}")
        print(f"signal_model_hash={artifacts.signal_model_hash}")
        print(f"output_dir={artifacts.output_dir}")
        return _EXIT_SUCCESS
    except (DataIntegrityError, KeyError, ValueError, TypeError, OSError) as exc:
        print(f"validation failure: {exc}")
        return _EXIT_VALIDATION


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if isinstance(exc.code, int):
            return exc.code
        return _EXIT_VALIDATION

    if args.command == "fetch":
        try:
            return _run_fetch(args)
        except ValueError as exc:
            print(f"invalid input: {exc}")
            return _EXIT_VALIDATION
    if args.command == "prepare":
        return _run_prepare(args)
    if args.command == "replay":
        return _run_replay(args)
    if args.command == "optimize":
        return _run_optimize(args)
    return _EXIT_VALIDATION


if __name__ == "__main__":
    raise SystemExit(main())
