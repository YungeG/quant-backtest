from __future__ import annotations

from collections.abc import Mapping
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, fields, replace
from decimal import Decimal
import multiprocessing
from pathlib import Path
from types import MappingProxyType

from research.mm_l1_replay.contracts import VerifiedBundle, canonical_sha256
from research.mm_l1_replay.engine import (
    AggressiveReplayOptions,
    ProfileReplayResult,
    ReplayLedger,
    run_profile,
)
from research.mm_l1_replay.profiles import ResolvedProfile

_WORKER_BUNDLE: VerifiedBundle | None = None
_WORKER_PROFILES: Mapping[str, ResolvedProfile] = {}
_WORKER_OPTIONS: Mapping[str, AggressiveReplayOptions | None] = {}


@dataclass(frozen=True)
class _ReplayWireResult:
    values: dict[str, object]
    ledger_path: str
    ledger_row_count: int
    ledger_sha256: str


def profile_execution_key(
    profile: ResolvedProfile,
    initial_equity: Decimal,
    aggressive_options: AggressiveReplayOptions | None = None,
) -> str:
    payload = {
        "profile": profile.execution_payload(),
        "initial_equity": initial_equity,
    }
    if aggressive_options is not None and aggressive_options.config.enabled:
        payload["aggressive_options"] = aggressive_options.canonical_payload()
    return canonical_sha256(payload)


def parallel_supported() -> bool:
    return "fork" in multiprocessing.get_all_start_methods()


def _to_wire(result: ProfileReplayResult) -> _ReplayWireResult:
    values = {
        item.name: (
            dict(getattr(result, item.name))
            if item.name in {"cancel_reasons", "lane_metrics", "constraint_rejections"}
            else getattr(result, item.name)
        )
        for item in fields(ProfileReplayResult)
        if item.name not in {"profile", "ledger"}
    }
    if result.ledger.path is None or result.ledger.sha256 is None:
        raise ValueError("parallel replay requires a sealed path-backed ledger")
    return _ReplayWireResult(
        values=values,
        ledger_path=str(result.ledger.path),
        ledger_row_count=result.ledger.row_count,
        ledger_sha256=result.ledger.sha256,
    )


def _from_wire(
    wire: _ReplayWireResult,
    profile: ResolvedProfile,
) -> ProfileReplayResult:
    values = dict(wire.values)
    values["cancel_reasons"] = MappingProxyType(dict(values["cancel_reasons"]))
    values["lane_metrics"] = MappingProxyType(dict(values["lane_metrics"]))
    values["constraint_rejections"] = MappingProxyType(
        dict(values["constraint_rejections"])
    )
    return ProfileReplayResult(
        **values,
        profile=profile,
        ledger=ReplayLedger(
            path=Path(wire.ledger_path),
            row_count=wire.ledger_row_count,
            sha256=wire.ledger_sha256,
        ),
    )


def _worker_run(
    execution_key: str,
    ledger_path: str,
    initial_equity: Decimal,
) -> tuple[str, _ReplayWireResult]:
    if _WORKER_BUNDLE is None:
        raise RuntimeError("parallel replay worker bundle is unavailable")
    profile = _WORKER_PROFILES[execution_key]
    options = _WORKER_OPTIONS[execution_key]
    kwargs = {"ledger_sink": Path(ledger_path)}
    if options is not None:
        kwargs["aggressive_options"] = options
    result = run_profile(_WORKER_BUNDLE, profile, initial_equity, **kwargs)
    return execution_key, _to_wire(result)


def _run_unique_sequential(
    bundle: VerifiedBundle,
    representatives: Mapping[str, ResolvedProfile],
    output_dir: Path,
    initial_equity: Decimal,
    aggressive_options: AggressiveReplayOptions | None,
) -> dict[str, ProfileReplayResult]:
    results = {}
    for execution_key, profile in representatives.items():
        kwargs = {"ledger_sink": output_dir / f"execution-{execution_key}.ndjson"}
        if aggressive_options is not None:
            kwargs["aggressive_options"] = aggressive_options
        results[execution_key] = run_profile(bundle, profile, initial_equity, **kwargs)
    return results


def _run_unique_parallel(
    bundle: VerifiedBundle,
    representatives: Mapping[str, ResolvedProfile],
    output_dir: Path,
    initial_equity: Decimal,
    max_workers: int,
    aggressive_options: AggressiveReplayOptions | None,
) -> dict[str, ProfileReplayResult]:
    global _WORKER_BUNDLE, _WORKER_OPTIONS, _WORKER_PROFILES

    _WORKER_BUNDLE = bundle
    _WORKER_PROFILES = dict(representatives)
    _WORKER_OPTIONS = {
        execution_key: aggressive_options for execution_key in representatives
    }
    wires: dict[str, _ReplayWireResult] = {}
    try:
        context = multiprocessing.get_context("fork")
        worker_count = min(max_workers, len(representatives), 3)
        with ProcessPoolExecutor(
            max_workers=worker_count,
            mp_context=context,
        ) as executor:
            futures = [
                executor.submit(
                    _worker_run,
                    execution_key,
                    str(output_dir / f"execution-{execution_key}.ndjson"),
                    initial_equity,
                )
                for execution_key in representatives
            ]
            for future in futures:
                execution_key, wire = future.result()
                wires[execution_key] = wire
    except BaseException:
        for execution_key in representatives:
            ledger_path = output_dir / f"execution-{execution_key}.ndjson"
            ledger_path.unlink(missing_ok=True)
            for temporary in output_dir.glob(f".{ledger_path.name}.*.tmp"):
                temporary.unlink(missing_ok=True)
        raise
    finally:
        _WORKER_BUNDLE = None
        _WORKER_PROFILES = {}
        _WORKER_OPTIONS = {}

    return {
        execution_key: _from_wire(wires[execution_key], profile)
        for execution_key, profile in representatives.items()
    }


def run_requested_profiles(
    bundle: VerifiedBundle,
    requested: Mapping[str, ResolvedProfile],
    ledger_dir: str | Path,
    *,
    max_workers: int,
    initial_equity: Decimal = Decimal("400"),
    aggressive_options: AggressiveReplayOptions | None = None,
) -> Mapping[str, ProfileReplayResult]:
    if max_workers <= 0:
        raise ValueError("max_workers must be positive")

    output_dir = Path(ledger_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    execution_keys: dict[str, str] = {}
    representatives: dict[str, ResolvedProfile] = {}
    for slot, profile in requested.items():
        execution_key = profile_execution_key(
            profile, initial_equity, aggressive_options
        )
        execution_keys[slot] = execution_key
        representatives.setdefault(execution_key, profile)

    if (
        max_workers > 1
        and len(representatives) > 1
        and parallel_supported()
    ):
        executed = _run_unique_parallel(
            bundle,
            representatives,
            output_dir,
            initial_equity,
            max_workers,
            aggressive_options,
        )
    else:
        executed = _run_unique_sequential(
            bundle,
            representatives,
            output_dir,
            initial_equity,
            aggressive_options,
        )

    return {
        slot: replace(
            executed[execution_keys[slot]],
            profile=profile,
        )
        for slot, profile in requested.items()
    }


__all__ = [
    "parallel_supported",
    "profile_execution_key",
    "run_requested_profiles",
]
