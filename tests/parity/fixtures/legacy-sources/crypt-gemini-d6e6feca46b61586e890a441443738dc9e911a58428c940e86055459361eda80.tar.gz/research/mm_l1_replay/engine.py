from __future__ import annotations

from collections import Counter, deque
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from datetime import date, timedelta
from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext
from hashlib import sha256
import heapq
import json
import os
from pathlib import Path
import tempfile
from types import MappingProxyType
from typing import Any, Iterator, TextIO

from deploy.hummingbot_artifacts.controllers_generic.mm_v2_guarded import MMV2Guarded
from strategy.market_making.mm_core import (
    compute_arbiter_state,
    compute_connectivity_allow,
    compute_carry_skew,
    compute_dynamic_spread,
    compute_expected_edge,
    compute_maker_mode,
    compute_position_inventory_state,
    compute_regime_allow,
)
from research.mm_l1_replay.aggressive_policy import (
    AggressiveBudgetState,
    AggressiveConfig,
    build_aggressive_decision,
)
from research.mm_l1_replay.aggressive_signals import CausalFeatureState, QuantileSignalModel
from research.mm_l1_replay.contracts import DataIntegrityError, VerifiedBundle
from research.mm_l1_replay.exchange_rules import (
    ExchangeRuleBook,
    OrderCandidate,
    constrain_order,
    exchange_rules_are_valid,
)
from research.mm_l1_replay.profiles import ResolvedProfile
from research.microstructure.fills import MakerQuote, QueueFillModel
BAR_INTERVAL_MS = 180_000
MARKOUT_HORIZONS_MS = (1_000, 5_000, 60_000)
_BPS = Decimal("10000")
_DAY_MS = 86_400_000
_ACCOUNTING_LANES = (
    "baseline_maker",
    "aggressive_maker",
    "aggressive_taker",
)
_DECIMAL_CONTEXT = Context(
    prec=50,
    Emin=-999_999,
    Emax=999_999,
    capitals=1,
    clamp=0,
)
_DECIMAL_CONTEXT.traps[InvalidOperation] = True
_DECIMAL_CONTEXT.traps[DivisionByZero] = True
_DECIMAL_CONTEXT.traps[Overflow] = True

_REASON_KEYS = (
    "quote_age",
    "mid_drift",
    "level_not_desired",
    "inventory_state_changed",
    "maker_mode_changed",
    "halt",
    "market_data_not_ready",
    "end_of_data",
)


@dataclass(frozen=True)
class ReplayLedgerRow:
    event_type: str
    event_time_ms: int
    sequence: int
    side: str | None = None
    level_id: str | None = None
    price: Decimal | None = None
    quantity: Decimal | None = None
    tag: str | None = None
    queue_ahead: Decimal | None = None
    remaining_quantity: Decimal | None = None
    reason: str | None = None
    lane: str | None = None


@dataclass(frozen=True)
class ReplayLedger:
    rows: tuple[ReplayLedgerRow, ...] = ()
    path: Path | None = None
    row_count: int = 0
    sha256: str | None = None

    def iter_rows(self) -> Iterator[ReplayLedgerRow]:
        if self.path is None:
            yield from self.rows
            return
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                payload = json.loads(line)
                yield ReplayLedgerRow(
                    event_type=payload["event_type"],
                    event_time_ms=payload["event_time_ms"],
                    sequence=payload["sequence"],
                    side=payload.get("side"),
                    level_id=payload.get("level_id"),
                    price=_optional_decimal(payload.get("price")),
                    quantity=_optional_decimal(payload.get("quantity")),
                    tag=payload.get("tag"),
                    queue_ahead=_optional_decimal(payload.get("queue_ahead")),
                    remaining_quantity=_optional_decimal(payload.get("remaining_quantity")),
                    reason=payload.get("reason"),
                    lane=payload.get("lane"),
                )

    @property
    def fills(self) -> tuple[ReplayLedgerRow, ...]:
        return tuple(row for row in self.iter_rows() if row.event_type == "fill")


def _optional_decimal(value: object) -> Decimal | None:
    return Decimal(str(value)) if value is not None else None


def _ledger_row_line(row: ReplayLedgerRow) -> str:
    payload = {
        field_name: (
            str(value)
            if isinstance(value, Decimal)
            else value
        )
        for field_name, value in row.__dict__.items()
        if field_name != "lane" or value is not None
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n"


class _LedgerRecorder:
    def __init__(self, sink: str | Path | None) -> None:
        self.path = Path(sink) if sink is not None else None
        self.rows: list[ReplayLedgerRow] = []
        self.row_count = 0
        self._digest = sha256()
        self._handle: TextIO | None = None
        self._temporary_path: Path | None = None
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=self.path.parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
                delete=False,
            )
            self._handle = temporary
            self._temporary_path = Path(temporary.name)

    def record(self, row: ReplayLedgerRow) -> None:
        self.row_count += 1
        if self._handle is None:
            self.rows.append(row)
            return
        line = _ledger_row_line(row)
        self._handle.write(line)
        self._digest.update(line.encode("utf-8"))

    def finish(self) -> ReplayLedger:
        if self._handle is None:
            return ReplayLedger(rows=tuple(self.rows), row_count=self.row_count)
        self._handle.flush()
        os.fsync(self._handle.fileno())
        self._handle.close()
        self._handle = None
        assert self.path is not None
        assert self._temporary_path is not None
        self._temporary_path.replace(self.path)
        self._temporary_path = None
        return ReplayLedger(
            path=self.path,
            row_count=self.row_count,
            sha256=self._digest.hexdigest(),
        )

    def __del__(self) -> None:
        if self._handle is not None:
            self._handle.close()
        if self._temporary_path is not None:
            self._temporary_path.unlink(missing_ok=True)


@dataclass(frozen=True)
class ReplayMetrics:
    fill_count: int
    quote_create_attempts: int
    excluded_stale_book_ms: int
    cancel_reasons: Mapping[str, int]
    maker_fees: Decimal
    funding_pnl: Decimal
    realized_pnl: Decimal
    unrealized_pnl: Decimal
    net_pnl: Decimal
    terminal_inventory_quote: Decimal
    max_drawdown: Decimal
    average_markout_1s_bps: Decimal | None
    average_markout_5s_bps: Decimal | None
    average_markout_60s_bps: Decimal | None
    fill_rate: Decimal
    partial_fill_ratio: Decimal
    markout_1s_eligible_count: int
    markout_1s_missing_count: int
    markout_5s_eligible_count: int
    markout_5s_missing_count: int
    markout_60s_eligible_count: int
    markout_60s_missing_count: int


@dataclass(frozen=True)
class LaneMetrics:
    quote_create_attempts: int = 0
    fill_count: int = 0
    maker_fill_count: int = 0
    maker_fill_rate: Decimal = Decimal("0")
    taker_attempt_count: int = 0
    taker_execution_count: int = 0
    taker_execution_rate: Decimal = Decimal("0")
    average_markout_1s_bps: Decimal | None = None
    average_markout_5s_bps: Decimal | None = None
    average_markout_60s_bps: Decimal | None = None
    markout_1s_eligible_count: int = 0
    markout_1s_missing_count: int = 0
    markout_5s_eligible_count: int = 0
    markout_5s_missing_count: int = 0
    markout_60s_eligible_count: int = 0
    markout_60s_missing_count: int = 0
    maker_fees: Decimal = Decimal("0")
    taker_fees: Decimal = Decimal("0")
    realized_pnl: Decimal = Decimal("0")
    signed_terminal_inventory_base: Decimal = Decimal("0")
    terminal_inventory_quote: Decimal = Decimal("0")
    funding_pnl: Decimal = Decimal("0")
    unrealized_pnl: Decimal = Decimal("0")
    net_pnl: Decimal = Decimal("0")
    liquidation_cost: Decimal | None = Decimal("0")
    liquidation_adjusted_net_pnl: Decimal | None = Decimal("0")


@dataclass(frozen=True)
class AggressiveReplayOptions:
    config: AggressiveConfig
    model: QuantileSignalModel
    rule_book: ExchangeRuleBook

    def canonical_payload(self) -> dict[str, object]:
        return {
            "config": self.config,
            "model": self.model.canonical_payload(),
            "rule_book": self.rule_book,
        }


@dataclass(frozen=True)
class TerminalCloseAssumptions:
    taker_fee_rate: Decimal
    slippage_bps: Decimal

    def __post_init__(self) -> None:
        for label, value in (
            ("taker_fee_rate", self.taker_fee_rate),
            ("slippage_bps", self.slippage_bps),
        ):
            if type(value) is not Decimal or not value.is_finite() or value < 0:
                raise ValueError(f"{label} must be a nonnegative finite Decimal")

    def canonical_payload(self) -> dict[str, Decimal]:
        return {
            "taker_fee_rate": self.taker_fee_rate,
            "slippage_bps": self.slippage_bps,
        }


@dataclass(frozen=True)
class ProfileReplayResult(ReplayMetrics):
    profile: ResolvedProfile
    ledger: ReplayLedger
    integrity_passed: bool
    net_return: Decimal
    limitations: tuple[str, ...]
    undeclared_limitations: bool
    initial_equity: Decimal
    lane_metrics: Mapping[str, LaneMetrics] = field(
        default_factory=lambda: MappingProxyType({})
    )
    signed_terminal_inventory_base: Decimal = Decimal("0")
    taker_fees: Decimal = Decimal("0")
    taker_fee_spent: Decimal = Decimal("0")
    liquidation_cost: Decimal | None = Decimal("0")
    liquidation_adjusted_net_pnl: Decimal | None = Decimal("0")
    constraint_rejections: Mapping[str, int] = field(
        default_factory=lambda: MappingProxyType({})
    )
    maker_fill_count: int = 0
    taker_attempt_count: int = 0
    taker_execution_count: int = 0
    taker_execution_rate: Decimal = Decimal("0")
    terminal_close_taker_fee_rate: Decimal = Decimal("0")
    terminal_close_slippage_bps: Decimal = Decimal("0")

    @property
    def metrics(self) -> ReplayMetrics:
        return ReplayMetrics(
            fill_count=self.fill_count,
            quote_create_attempts=self.quote_create_attempts,
            excluded_stale_book_ms=self.excluded_stale_book_ms,
            cancel_reasons=self.cancel_reasons,
            maker_fees=self.maker_fees,
            funding_pnl=self.funding_pnl,
            realized_pnl=self.realized_pnl,
            unrealized_pnl=self.unrealized_pnl,
            net_pnl=self.net_pnl,
            terminal_inventory_quote=self.terminal_inventory_quote,
            max_drawdown=self.max_drawdown,
            average_markout_1s_bps=self.average_markout_1s_bps,
            average_markout_5s_bps=self.average_markout_5s_bps,
            average_markout_60s_bps=self.average_markout_60s_bps,
            fill_rate=self.fill_rate,
            partial_fill_ratio=self.partial_fill_ratio,
            markout_1s_eligible_count=self.markout_1s_eligible_count,
            markout_1s_missing_count=self.markout_1s_missing_count,
            markout_5s_eligible_count=self.markout_5s_eligible_count,
            markout_5s_missing_count=self.markout_5s_missing_count,
            markout_60s_eligible_count=self.markout_60s_eligible_count,
            markout_60s_missing_count=self.markout_60s_missing_count,
        )


@dataclass(frozen=True)
class _MarketState:
    maker_mode: str
    inventory_state: str
    adjusted_delta: Decimal
    dyn_spread: Decimal
    edge: Decimal
    reference_price: Decimal | None
    desired_orders: tuple[Any, ...]
    quote_timestamp: int | None


@dataclass(frozen=True)
class _ActiveQuote:
    lane: str
    level_id: str
    side: str
    price: Decimal
    placed_time_ms: int
    quoted_mid: Decimal
    queue_ahead: Decimal
    maker_mode: str
    inventory_state: str
    maker_quote: MakerQuote
    fill_model: QueueFillModel
    remaining_quantity: Decimal


def _trade_quote_is_eligible(quote: _ActiveQuote, trade: Any) -> bool:
    if trade.event_time_ms <= quote.placed_time_ms:
        return False
    return (
        quote.side == "buy"
        and trade.buyer_is_maker
        and trade.price <= quote.price
    ) or (
        quote.side == "sell"
        and not trade.buyer_is_maker
        and trade.price >= quote.price
    )


def _trade_allocation_key(quote: _ActiveQuote, trade: Any) -> tuple[Any, ...]:
    price_priority = -quote.price if trade.buyer_is_maker else quote.price
    lane_priority = 0 if quote.lane == "baseline_maker" else 1
    return (
        price_priority,
        quote.placed_time_ms,
        lane_priority,
        quote.lane,
        quote.level_id,
    )


def _allocate_trade_fills(
    quotes: tuple[_ActiveQuote, ...],
    trade: Any,
) -> list[tuple[_ActiveQuote, tuple[Any, ...]]]:
    residual = trade.quantity
    allocated: list[tuple[_ActiveQuote, tuple[Any, ...]]] = []
    eligible = sorted(
        (quote for quote in quotes if _trade_quote_is_eligible(quote, trade)),
        key=lambda quote: _trade_allocation_key(quote, trade),
    )
    for quote in eligible:
        if residual <= _decimal_zero():
            break
        queue_before = quote.fill_model.queue_ahead
        offered = replace(trade, quantity=residual)
        fills = quote.fill_model.on_trade(offered)
        queue_consumed = queue_before - quote.fill_model.queue_ahead
        filled_quantity = sum(
            (fill.quantity for fill in fills),
            _decimal_zero(),
        )
        residual = max(
            _decimal_zero(),
            residual - queue_consumed - filled_quantity,
        )
        if fills:
            allocated.append((quote, fills))
    return allocated


@dataclass
class _PendingMarkouts:
    pending: list[tuple[int, int, int, str, Decimal, str | None]] = field(
        default_factory=list
    )
    sums: dict[int, Decimal] = field(
        default_factory=lambda: {
            horizon: Decimal("0")
            for horizon in MARKOUT_HORIZONS_MS
        }
    )
    eligible: Counter[int] = field(default_factory=Counter)
    missing: Counter[int] = field(default_factory=Counter)
    lane_sums: dict[tuple[str, int], Decimal] = field(default_factory=dict)
    lane_eligible: Counter[tuple[str, int]] = field(default_factory=Counter)
    lane_missing: Counter[tuple[str, int]] = field(default_factory=Counter)
    sequence: int = 0

    def add(
        self,
        *,
        event_time_ms: int,
        side: str,
        price: Decimal,
        lane: str | None = None,
    ) -> None:
        for horizon in MARKOUT_HORIZONS_MS:
            heapq.heappush(
                self.pending,
                (
                    event_time_ms + horizon,
                    self.sequence,
                    horizon,
                    side,
                    price,
                    lane,
                ),
            )
            self.sequence += 1

    def settle(self, *, event_time_ms: int, midpoint: Decimal) -> None:
        while self.pending and self.pending[0][0] <= event_time_ms:
            _deadline, _sequence, horizon, side, price, lane = heapq.heappop(
                self.pending
            )
            direction = Decimal("1") if side == "buy" else Decimal("-1")
            value = (
                (midpoint - price)
                * direction
                / price
                * Decimal("10000")
            )
            self.sums[horizon] += value
            self.eligible[horizon] += 1
            if lane is not None:
                key = (lane, horizon)
                self.lane_sums[key] = self.lane_sums.get(key, Decimal("0")) + value
                self.lane_eligible[key] += 1

    def finish(self) -> None:
        while self.pending:
            _deadline, _sequence, horizon, _side, _price, lane = heapq.heappop(
                self.pending
            )
            self.missing[horizon] += 1
            if lane is not None:
                self.lane_missing[(lane, horizon)] += 1

    def result(self, horizon_ms: int) -> tuple[Decimal | None, int, int]:
        eligible = self.eligible[horizon_ms]
        average = (
            self.sums[horizon_ms] / Decimal(str(eligible))
            if eligible
            else None
        )
        return average, eligible, self.missing[horizon_ms]

    def lane_result(
        self, lane: str, horizon_ms: int
    ) -> tuple[Decimal | None, int, int]:
        key = (lane, horizon_ms)
        eligible = self.lane_eligible[key]
        average = (
            self.lane_sums.get(key, Decimal("0")) / Decimal(str(eligible))
            if eligible
            else None
        )
        return average, eligible, self.lane_missing[key]


class _ReplayMarketDataProvider:
    def __init__(self, *, rule: _PinnedRule | None = None) -> None:
        self.rule = rule or _ETHUSDT_REPLAY_RULE

    def time(self) -> float:
        return 0.0

    def initialize_rate_sources(self, *_args: Any, **_kwargs: Any) -> None:
        return None

    def quantize_order_amount(self, _connector: str, _pair: str, amount: Decimal) -> str:
        return str(_quantized_by_rule(_to_decimal(amount), self.rule.min_amount_step))

    def quantize_order_price(self, _connector: str, _pair: str, price: Decimal) -> str:
        return str(_quantized_by_rule(_to_decimal(price), self.rule.min_price_increment))


@dataclass(frozen=True)
class _PinnedRule:
    connector_name: str
    trading_pair: str
    min_price_increment: Decimal
    min_amount_step: Decimal


_ETHUSDT_REPLAY_RULE = _PinnedRule(
    connector_name="binance_perpetual",
    trading_pair="ETH-USDT",
    min_price_increment=Decimal("0.01"),
    min_amount_step=Decimal("0.001"),
)


def _quantized_by_rule(value: Decimal, step: Decimal) -> Decimal:
    if step <= _decimal_zero():
        return value
    if value <= _decimal_zero():
        return _decimal_zero()
    return (value // step) * step


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _decimal_zero() -> Decimal:
    return Decimal("0")


def _to_base_pct(signed_base: Decimal, reference_price: Decimal, total_amount_quote: Decimal) -> Decimal:
    if total_amount_quote <= _decimal_zero() or reference_price <= _decimal_zero():
        return Decimal("0.5")
    signed_inventory_quote = signed_base * reference_price
    current_base_pct = Decimal("0.5") + (signed_inventory_quote / (total_amount_quote * Decimal("2")))
    return min(Decimal("1"), max(Decimal("0"), current_base_pct))


def _realized_vol(closes: tuple[Decimal, ...]) -> Decimal:
    if len(closes) < 20:
        return _decimal_zero()
    sample = closes[-20:]
    mean = sum(sample, _decimal_zero()) / Decimal(str(len(sample)))
    if mean <= _decimal_zero():
        return _decimal_zero()
    variance = sum((x - mean) ** 2 for x in sample) / Decimal(str(len(sample)))
    return variance.sqrt() / mean


def _quantized_map(counter: Counter[str]) -> Mapping[str, int]:
    values = {key: counter.get(key, 0) for key in _REASON_KEYS}
    for key, value in counter.items():
        values.setdefault(key, value)
    return MappingProxyType(values)


def _event_key(item: tuple[int, int, int, str, Any]) -> tuple[int, int, int]:
    ts, kind, seq, _name, _ = item
    return ts, kind, seq


def _window_bounds_ms(bundle: VerifiedBundle) -> tuple[int, int]:
    epoch = date(1970, 1, 1)
    window = bundle.manifest.window
    start_ms = (window.start_date - epoch).days * 86_400_000
    end_ms = ((window.end_date - epoch).days + 1) * 86_400_000 - 1
    return start_ms, end_ms


def _bounded_rows(rows: Iterator[Any], *, timestamp, start_ms: int, end_ms: int) -> Iterator[Any]:
    for row in rows:
        event_time_ms = timestamp(row)
        if event_time_ms < start_ms:
            continue
        if event_time_ms > end_ms:
            return
        yield row


def _prepare_funding_events(
    bundle: VerifiedBundle,
    *,
    start_ms: int,
    end_ms: int,
) -> tuple[Decimal, Iterator[tuple[int, int, int, str, Any]]]:
    source = iter(bundle.iter_funding())
    initial_funding_bps_8h = _decimal_zero()
    first_in_window: tuple[int, Any] | None = None

    for index, item in enumerate(source):
        if item.funding_time_ms < start_ms:
            initial_funding_bps_8h = item.funding_rate * Decimal("10000")
            continue
        first_in_window = (index, item)
        break

    def events() -> Iterator[tuple[int, int, int, str, Any]]:
        if first_in_window is None:
            return
        first_index, first_item = first_in_window
        if first_item.funding_time_ms > end_ms:
            return
        yield (
            first_item.funding_time_ms,
            2,
            first_index,
            "funding",
            first_item,
        )
        for index, item in enumerate(source, start=first_index + 1):
            if item.funding_time_ms > end_ms:
                return
            yield (item.funding_time_ms, 2, index, "funding", item)

    return initial_funding_bps_8h, events()


def _iter_events(
    bundle: VerifiedBundle,
) -> tuple[Decimal, Iterator[tuple[int, int, int, str, Any]]]:
    start_ms, end_ms = _window_bounds_ms(bundle)
    books = (
        (book.event_time_ms, 0, book.update_id, "book", book)
        for book in _bounded_rows(
            bundle.iter_book_tickers(),
            timestamp=lambda row: row.event_time_ms,
            start_ms=start_ms,
            end_ms=end_ms,
        )
    )
    trades = (
        (trade.event_time_ms, 1, trade.sequence, "trade", trade)
        for trade in _bounded_rows(
            bundle.iter_agg_trades(),
            timestamp=lambda row: row.event_time_ms,
            start_ms=start_ms,
            end_ms=end_ms,
        )
    )
    initial_funding_bps_8h, funding = _prepare_funding_events(
        bundle,
        start_ms=start_ms,
        end_ms=end_ms,
    )
    return initial_funding_bps_8h, heapq.merge(
        books,
        trades,
        funding,
        key=_event_key,
    )


def _compute_market_state(
    *,
    bundle: VerifiedBundle,
    profile: ResolvedProfile,
    signed_base: Decimal,
    closes: tuple[Decimal, ...],
    latest_mid: Decimal | None,
    quote_ts: int | None,
    funding_bps_8h: Decimal,
    market_data_provider: _ReplayMarketDataProvider,
) -> _MarketState:
    config = profile.controller_config

    if not config.trading_enabled:
        return _MarketState(
            maker_mode="off",
            inventory_state="neutral",
            adjusted_delta=_decimal_zero(),
            dyn_spread=_decimal_zero(),
            edge=_decimal_zero(),
            reference_price=None,
            desired_orders=tuple(),
            quote_timestamp=quote_ts,
        )

    if latest_mid is None or latest_mid <= _decimal_zero():
        return _MarketState(
            maker_mode="off",
            inventory_state="neutral",
            adjusted_delta=_decimal_zero(),
            dyn_spread=_decimal_zero(),
            edge=_decimal_zero(),
            reference_price=None,
            desired_orders=tuple(),
            quote_timestamp=quote_ts,
        )

    required = max(int(config.sma_window), int(config.breakout_window) + 1)
    if len(closes) < required:
        return _MarketState(
            maker_mode="off",
            inventory_state="neutral",
            adjusted_delta=_decimal_zero(),
            dyn_spread=_decimal_zero(),
            edge=_decimal_zero(),
            reference_price=latest_mid,
            desired_orders=tuple(),
            quote_timestamp=quote_ts,
        )

    last_price = closes[-1]
    sma_window = max(int(config.sma_window), 1)
    sma60 = sum(closes[-sma_window:], _decimal_zero()) / Decimal(str(sma_window))
    realized = _realized_vol(closes)
    prev_window = closes[-(int(config.breakout_window) + 1) : -1]
    breakout_up = bool(prev_window) and last_price > max(prev_window)
    breakout_down = bool(prev_window) and last_price < min(prev_window)

    public_ready = latest_mid > _decimal_zero()
    connectivity_ok = compute_connectivity_allow(
        public_ready=public_ready,
        user_stream_ready=True,
        recent_error_count=0,
        max_recent_errors=config.max_recent_errors,
    )
    regime_ok = compute_regime_allow(
        last_price=last_price,
        sma60=sma60,
        max_divergence=config.max_divergence,
        realized_vol=realized,
        max_realized_vol=config.max_realized_vol,
    )
    trend_state = compute_arbiter_state(
        price=last_price,
        trend_anchor=sma60,
        breakout_up=breakout_up,
        breakout_down=breakout_down,
        realized_vol=realized,
        max_range_vol=config.off_vol_threshold,
    )
    maker_mode = compute_maker_mode(
        trend_ok=regime_ok,
        realized_vol=realized,
        active_vol_threshold=config.active_vol_threshold,
        off_vol_threshold=config.off_vol_threshold,
        connectivity_ok=connectivity_ok,
    )

    current_base_pct = _to_base_pct(
        signed_base=signed_base,
        reference_price=latest_mid,
        total_amount_quote=_to_decimal(config.total_amount_quote),
    )
    inventory_state = compute_position_inventory_state(
        current_base_pct=current_base_pct,
        warning_ratio=config.warning_ratio,
        reduce_only_ratio=config.reduce_only_ratio,
        halt_ratio=config.halt_ratio,
    )
    adjusted_delta = compute_carry_skew(
        inventory_delta=current_base_pct - Decimal("0.5"),
        funding_bps_8h=funding_bps_8h,
        carry_penalty_bps=config.carry_penalty_bps,
    )
    dyn_spread = compute_dynamic_spread(
        base_spread=config.base_spread,
        realized_vol=realized,
        vol_ref=config.vol_ref,
        spread_floor=config.spread_floor,
        spread_cap=config.spread_cap,
    )
    edge = compute_expected_edge(
        dyn_spread,
        config.fee_rate,
        funding_bps_8h,
        config.risk_buffer_bps,
    )

    desired_orders: tuple[Any, ...] = tuple()
    if maker_mode != "off" and edge >= _decimal_zero() and trend_state == "range":
        controller = MMV2Guarded(config, market_data_provider=market_data_provider)
        desired_orders = tuple(
            controller._desired_orders(
                reference_price=latest_mid,
                maker_mode=maker_mode,
                inventory_state=inventory_state,
                adjusted_delta=adjusted_delta,
                dyn_spread=dyn_spread,
            )
        )

    return _MarketState(
        maker_mode=maker_mode,
        inventory_state=inventory_state,
        adjusted_delta=adjusted_delta,
        dyn_spread=dyn_spread,
        edge=edge,
        reference_price=latest_mid,
        desired_orders=desired_orders,
        quote_timestamp=quote_ts,
    )


def _record(recorder: _LedgerRecorder, counter: list[int], *, event_type: str, row_data: dict[str, Any]) -> None:
    seq = counter[0]
    counter[0] += 1
    recorder.record(ReplayLedgerRow(event_type=event_type, sequence=seq, **row_data))


def _quote_cancel_reason(
    *,
    quote: _ActiveQuote,
    event_time_ms: int,
    reference_price: Decimal,
    market_state: _MarketState,
    desired_levels: Mapping[str, Any],
    config,
) -> str | None:
    if quote.level_id not in desired_levels:
        return "level_not_desired"
    if market_state.inventory_state == "halt":
        return "halt"
    if quote.placed_time_ms + int(_to_decimal(config.max_quote_age_seconds) * 1000) <= event_time_ms:
        return "quote_age"
    if market_state.maker_mode != quote.maker_mode:
        return "maker_mode_changed"
    if market_state.inventory_state != quote.inventory_state:
        return "inventory_state_changed"
    drift = abs(reference_price / quote.quoted_mid - Decimal("1")) if quote.quoted_mid != _decimal_zero() else _decimal_zero()
    if drift >= config.max_mid_drift_pct:
        return "mid_drift"
    if market_state.maker_mode == "off":
        return "market_data_not_ready"
    return None


def _close_bar(
    bar_start: int | None,
    bar_midpoint: Decimal | None,
    closed_closes: list[Decimal],
    target: int,
) -> tuple[int | None, Decimal | None]:
    if bar_start is None:
        return target, bar_midpoint

    while target >= bar_start + BAR_INTERVAL_MS:
        if bar_midpoint is not None:
            closed_closes.append(bar_midpoint)
        bar_start += BAR_INTERVAL_MS
        bar_midpoint = None
    return bar_start, bar_midpoint


def _book_is_executable(book: Any, *, event_time_ms: int, max_book_age_ms: int) -> bool:
    decimal_values = (
        book.bid_price,
        book.bid_quantity,
        book.ask_price,
        book.ask_quantity,
    )
    return (
        all(isinstance(value, Decimal) and value.is_finite() for value in decimal_values)
        and book.bid_price > _decimal_zero()
        and book.ask_price > _decimal_zero()
        and book.bid_quantity >= _decimal_zero()
        and book.ask_quantity >= _decimal_zero()
        and book.bid_price < book.ask_price
        and isinstance(book.event_time_ms, int)
        and not isinstance(book.event_time_ms, bool)
        and isinstance(book.transaction_time_ms, int)
        and not isinstance(book.transaction_time_ms, bool)
        and 0 <= book.transaction_time_ms <= book.event_time_ms <= event_time_ms
        and event_time_ms - book.transaction_time_ms <= max_book_age_ms
    )


def _taker_execution(
    order: Any,
    book: Any,
    displayed_quantity: Decimal,
    config: AggressiveConfig,
) -> tuple[Decimal, Decimal, Decimal] | None:
    with localcontext(_DECIMAL_CONTEXT):
        quantity = min(order.quantity, displayed_quantity)
        if quantity <= _decimal_zero():
            return None
        slip = config.max_taker_slippage_bps / _BPS
        if order.side == "buy":
            adverse_price = book.ask_price * (Decimal("1") + slip)
            price = min(order.price, adverse_price)
            if price < book.ask_price:
                return None
        else:
            adverse_price = book.bid_price * (Decimal("1") - slip)
            price = max(order.price, adverse_price)
            if price > book.bid_price:
                return None
        fee = price * quantity * config.taker_fee_rate
        return quantity, price, fee


def _utc_day(event_time_ms: int) -> date:
    return date(1970, 1, 1) + timedelta(days=event_time_ms // _DAY_MS)


def _terminal_liquidation(
    *,
    signed_base: Decimal,
    terminal_mark: Decimal,
    book: Any,
    taker_fee_rate: Decimal,
    slippage_bps: Decimal,
) -> tuple[str, Decimal, Decimal, Decimal]:
    with localcontext(_DECIMAL_CONTEXT):
        quantity = abs(signed_base)
        slip = slippage_bps / _BPS
        if signed_base > _decimal_zero():
            side = "sell"
            price = book.bid_price * (Decimal("1") - slip)
            spread_and_slippage = (terminal_mark - price) * quantity
        else:
            side = "buy"
            price = book.ask_price * (Decimal("1") + slip)
            spread_and_slippage = (price - terminal_mark) * quantity
        if price <= _decimal_zero():
            raise ValueError("terminal liquidation price must be positive")
        fee = price * quantity * taker_fee_rate
        return side, price, quantity, spread_and_slippage + fee


def _allocate_lane_funding_cashflow(
    lane_signed_base: Mapping[str, Decimal],
    *,
    midpoint: Decimal,
    funding_rate: Decimal,
    combined_cashflow: Decimal,
) -> Mapping[str, Decimal]:
    """Allocate funding linearly by signed inventory with an exact residual."""

    with localcontext(_DECIMAL_CONTEXT):
        result = {lane: _decimal_zero() for lane in _ACCOUNTING_LANES}
        active = tuple(
            lane
            for lane in _ACCOUNTING_LANES
            if lane_signed_base.get(lane, _decimal_zero()) != _decimal_zero()
        )
        allocated = _decimal_zero()
        for lane in active[:-1]:
            value = -(
                lane_signed_base[lane] * midpoint * funding_rate
            )
            result[lane] = value
            allocated += value
        if active:
            result[active[-1]] = combined_cashflow - allocated
        return MappingProxyType(result)


def _allocate_lane_liquidation_cost(
    lane_signed_base: Mapping[str, Decimal],
    combined_cost: Decimal,
) -> Mapping[str, Decimal]:
    """Allocate combined close cost by absolute lane inventory.

    Opposing lane positions may internally offset, so this deliberately
    allocates the already-computed combined Task 6 cost rather than fabricating
    independent closes. The final active lane receives the Decimal residual,
    guaranteeing exact additive reconciliation.
    """

    with localcontext(_DECIMAL_CONTEXT):
        weights = {
            lane: abs(lane_signed_base.get(lane, _decimal_zero()))
            for lane in _ACCOUNTING_LANES
        }
        total_weight = sum(weights.values(), _decimal_zero())
        if total_weight == _decimal_zero():
            return MappingProxyType(
                {lane: _decimal_zero() for lane in _ACCOUNTING_LANES}
            )
        active = tuple(lane for lane in _ACCOUNTING_LANES if weights[lane] > 0)
        result = {lane: _decimal_zero() for lane in _ACCOUNTING_LANES}
        allocated = _decimal_zero()
        for lane in active[:-1]:
            value = combined_cost * weights[lane] / total_weight
            result[lane] = value
            allocated += value
        result[active[-1]] = combined_cost - allocated
        return MappingProxyType(result)


def _run_profile(
    bundle: VerifiedBundle,
    profile: ResolvedProfile,
    initial_equity: Decimal = Decimal("400"),
    *,
    ledger_sink: str | Path | None = None,
    aggressive_options: AggressiveReplayOptions | None = None,
    terminal_close_assumptions: TerminalCloseAssumptions | None = None,
) -> ProfileReplayResult:
    if not isinstance(initial_equity, Decimal):
        initial_equity = _to_decimal(initial_equity)
    if initial_equity <= _decimal_zero():
        raise ValueError("initial_equity must be positive")

    config = profile.controller_config
    if terminal_close_assumptions is None:
        terminal_close_taker_fee_rate = (
            aggressive_options.config.taker_fee_rate
            if aggressive_options is not None
            else _decimal_zero()
        )
        terminal_close_slippage_bps = (
            aggressive_options.config.max_taker_slippage_bps
            if aggressive_options is not None
            else _decimal_zero()
        )
    else:
        terminal_close_taker_fee_rate = terminal_close_assumptions.taker_fee_rate
        terminal_close_slippage_bps = terminal_close_assumptions.slippage_bps
    aggressive_enabled = bool(
        aggressive_options is not None and aggressive_options.config.enabled
    )
    max_book_age_ms = int(getattr(bundle.manifest, "max_book_age_ms", 5_000))

    latest_funding_bps_8h, events = _iter_events(bundle)

    close_limit = max(
        int(config.sma_window),
        int(config.breakout_window) + 1,
        20,
    )
    closed_closes: deque[Decimal] = deque(maxlen=close_limit)
    bar_start: int | None = None
    bar_midpoint: Decimal | None = None

    latest_book_ms: int | None = None
    latest_book: Any | None = None
    latest_midpoint: Decimal | None = None
    sequence_counter = [0]
    ledger_recorder = _LedgerRecorder(ledger_sink)
    pending_markouts = _PendingMarkouts()

    active_quotes: dict[tuple[str, str], _ActiveQuote] = {}
    peak_equity: Decimal | None = None
    max_drawdown = _decimal_zero()

    cancel_counts: Counter[str] = Counter()
    excluded_stale_book_ms = 0
    maker_fees = _decimal_zero()
    taker_fees = _decimal_zero()
    funding_pnl = _decimal_zero()
    realized_pnl = _decimal_zero()
    realized_cash = _to_decimal(initial_equity)
    signed_base = _decimal_zero()
    baseline_signed_base = _decimal_zero()

    fill_count = 0
    maker_fill_count = 0
    taker_attempt_count = 0
    taker_execution_count = 0
    partial_fill_count = 0
    quote_create_attempts = 0
    lane_quote_create_attempts: Counter[str] = Counter()
    lane_fill_count: Counter[str] = Counter()
    lane_maker_fill_count: Counter[str] = Counter()
    lane_taker_attempt_count: Counter[str] = Counter()
    lane_taker_execution_count: Counter[str] = Counter()
    lane_maker_fees: dict[str, Decimal] = {}
    lane_taker_fees: dict[str, Decimal] = {}
    lane_realized_pnl: dict[str, Decimal] = {}
    lane_signed_base: dict[str, Decimal] = {
        lane: _decimal_zero() for lane in _ACCOUNTING_LANES
    }
    lane_funding_pnl: dict[str, Decimal] = {
        lane: _decimal_zero() for lane in _ACCOUNTING_LANES
    }
    constraint_rejections: Counter[str] = Counter()
    historical_rules_used = False
    saw_event = False
    final_time = 0

    market_data_provider = _ReplayMarketDataProvider(rule=_ETHUSDT_REPLAY_RULE)
    feature_state = (
        CausalFeatureState(max_book_age_ms=max_book_age_ms)
        if aggressive_enabled
        else None
    )
    aggressive_budget = AggressiveBudgetState()
    taker_bid_quantity = _decimal_zero()
    taker_ask_quantity = _decimal_zero()

    market_state = _MarketState(
        maker_mode="off",
        inventory_state="neutral",
        adjusted_delta=_decimal_zero(),
        dyn_spread=_decimal_zero(),
        edge=_decimal_zero(),
        reference_price=None,
        desired_orders=tuple(),
        quote_timestamp=None,
    )

    def snapshot_equity(event_time_ms: int) -> None:
        nonlocal peak_equity, max_drawdown
        del event_time_ms
        if latest_midpoint is None:
            return
        value = realized_cash + signed_base * latest_midpoint
        if peak_equity is None or value > peak_equity:
            peak_equity = value
        if peak_equity is not None:
            max_drawdown = max(max_drawdown, peak_equity - value)

    def cancel_quote(quote: _ActiveQuote, event_time_ms: int, reason: str) -> None:
        cancel_counts[reason] += 1
        _record(
            ledger_recorder,
            sequence_counter,
            event_type="cancel",
            row_data={
                "event_time_ms": event_time_ms,
                "side": quote.side,
                "level_id": quote.level_id,
                "reason": reason,
                "lane": quote.lane if aggressive_enabled else None,
            },
        )
        active_quotes.pop((quote.lane, quote.level_id), None)

    def expire_aggressive_quotes(event_time_ms: int) -> None:
        if aggressive_options is None:
            return
        for quote in tuple(active_quotes.values()):
            if (
                quote.lane == "aggressive_maker"
                and quote.placed_time_ms
                + aggressive_options.config.order_lifetime_ms
                <= event_time_ms
            ):
                cancel_quote(quote, event_time_ms, "quote_age")

    def refresh_aggressive_quote(event_time_ms: int, book: Any, rules: Any | None) -> None:
        nonlocal aggressive_budget
        nonlocal fill_count
        nonlocal partial_fill_count
        nonlocal quote_create_attempts
        nonlocal realized_cash
        nonlocal realized_pnl
        nonlocal signed_base
        nonlocal taker_ask_quantity
        nonlocal taker_bid_quantity
        nonlocal taker_fees
        nonlocal taker_attempt_count
        nonlocal taker_execution_count
        if not aggressive_enabled or feature_state is None or aggressive_options is None:
            return
        expire_aggressive_quotes(event_time_ms)

        feature = feature_state.snapshot(event_time_ms)
        if feature is None:
            for quote in tuple(active_quotes.values()):
                if quote.lane == "aggressive_maker":
                    cancel_quote(quote, event_time_ms, "market_data_not_ready")
            return
        if rules is None:
            return
        prediction = aggressive_options.model.predict(feature)
        decision = build_aggressive_decision(
            prediction,
            book,
            aggressive_options.config,
            aggressive_budget,
            rules,
        )
        if decision.maker is None:
            constraint_rejections[decision.maker_reason] += 1
            for quote in tuple(active_quotes.values()):
                if quote.lane == "aggressive_maker":
                    cancel_quote(quote, event_time_ms, decision.maker_reason)
        else:
            level_id = f"{decision.maker.side}_0"
            key = (decision.maker.lane, level_id)
            existing = active_quotes.get(key)
            constrained = constrain_order(
                decision.maker,
                rules,
                book,
                current_open_orders=len(active_quotes) - int(existing is not None),
                current_algo_orders=sum(
                    quote.lane == "aggressive_maker" for quote in active_quotes.values()
                ),
            )
            if constrained.order is None:
                constraint_rejections[constrained.reason] += 1
                if existing is not None:
                    cancel_quote(existing, event_time_ms, constrained.reason)
            else:
                order = constrained.order
                for quote in tuple(active_quotes.values()):
                    if quote.lane == order.lane and (quote.lane, quote.level_id) != key:
                        cancel_quote(quote, event_time_ms, "level_not_desired")
                existing = active_quotes.get(key)
                unchanged = bool(
                    existing is not None
                    and existing.side == order.side
                    and existing.price == order.price
                    and existing.remaining_quantity > _decimal_zero()
                )
                if not unchanged:
                    if existing is not None:
                        cancel_quote(existing, event_time_ms, "level_not_desired")
                    queue_ahead = (
                        book.bid_quantity if order.side == "buy" else book.ask_quantity
                    )
                    maker_quote = MakerQuote(
                        quote_id=level_id,
                        side=order.side,
                        price=order.price,
                        quantity=order.quantity,
                        queue_ahead=queue_ahead,
                        placed_time_ms=event_time_ms,
                    )
                    active_quotes[key] = _ActiveQuote(
                        lane=order.lane,
                        level_id=level_id,
                        side=order.side,
                        price=order.price,
                        placed_time_ms=event_time_ms,
                        quoted_mid=feature.midpoint,
                        queue_ahead=queue_ahead,
                        maker_mode=market_state.maker_mode,
                        inventory_state=market_state.inventory_state,
                        maker_quote=maker_quote,
                        fill_model=QueueFillModel(maker_quote),
                        remaining_quantity=order.quantity,
                    )
                    quote_create_attempts += 1
                    lane_quote_create_attempts[order.lane] += 1
                    _record(
                        ledger_recorder,
                        sequence_counter,
                        event_type="create",
                        row_data={
                            "event_time_ms": event_time_ms,
                            "side": order.side,
                            "level_id": level_id,
                            "price": order.price,
                            "quantity": order.quantity,
                            "reason": "create",
                            "lane": order.lane,
                        },
                    )

        if decision.taker is None:
            constraint_rejections[decision.taker_reason] += 1
            return
        taker_attempt_count += 1
        lane_taker_attempt_count["aggressive_taker"] += 1
        taker_constraint = constrain_order(
            decision.taker,
            rules,
            book,
            current_open_orders=len(active_quotes),
            current_algo_orders=sum(
                quote.lane == "aggressive_maker" for quote in active_quotes.values()
            ),
        )
        if taker_constraint.order is None:
            constraint_rejections[taker_constraint.reason] += 1
            return
        taker_order = taker_constraint.order
        displayed = taker_ask_quantity if taker_order.side == "buy" else taker_bid_quantity
        execution = _taker_execution(
            taker_order,
            book,
            displayed,
            aggressive_options.config,
        )
        if execution is None:
            return
        quantity, price, fee = execution
        current_day = _utc_day(event_time_ms)
        fee_spent = (
            aggressive_budget.taker_fee_spent
            if aggressive_budget.fee_day_utc == current_day
            else _decimal_zero()
        )
        if fee_spent + fee > aggressive_options.config.daily_taker_fee_budget:
            constraint_rejections["taker_budget_exhausted"] += 1
            return
        if taker_order.side == "buy":
            taker_ask_quantity -= quantity
            fill_realized = -(price * quantity)
            signed_base += quantity
            lane_signed_base["aggressive_taker"] += quantity
            realized_cash -= price * quantity
        else:
            taker_bid_quantity -= quantity
            fill_realized = price * quantity
            signed_base -= quantity
            lane_signed_base["aggressive_taker"] -= quantity
            realized_cash += price * quantity
        realized_pnl += fill_realized
        realized_cash -= fee
        taker_fees += fee
        fill_count += 1
        taker_execution_count += 1
        if quantity < taker_order.quantity:
            partial_fill_count += 1
        lane_fill_count["aggressive_taker"] += 1
        lane_taker_execution_count["aggressive_taker"] += 1
        lane_taker_fees["aggressive_taker"] = (
            lane_taker_fees.get("aggressive_taker", _decimal_zero()) + fee
        )
        lane_realized_pnl["aggressive_taker"] = (
            lane_realized_pnl.get("aggressive_taker", _decimal_zero()) + fill_realized
        )
        _record(
            ledger_recorder,
            sequence_counter,
            event_type="fill",
            row_data={
                "event_time_ms": event_time_ms,
                "side": taker_order.side,
                "level_id": f"{taker_order.side}_0",
                "price": price,
                "quantity": quantity,
                "tag": "immediate_l1_taker",
                "remaining_quantity": displayed - quantity,
                "lane": "aggressive_taker",
            },
        )
        pending_markouts.add(
            event_time_ms=event_time_ms,
            side=taker_order.side,
            price=price,
            lane="aggressive_taker",
        )
        aggressive_budget = AggressiveBudgetState(
            taker_event_times_ms=aggressive_budget.taker_event_times_ms + (event_time_ms,),
            taker_fee_spent=fee_spent + fee,
            fee_day_utc=current_day,
        )
        _record(
            ledger_recorder,
            sequence_counter,
            event_type="budget",
            row_data={
                "event_time_ms": event_time_ms,
                "price": price,
                "quantity": fee,
                "tag": current_day.isoformat(),
                "lane": "aggressive_taker",
            },
        )

    for event_time, _kind, _seq, kind, payload in events:
        saw_event = True
        final_time = event_time
        aggressive_rules = None
        aggressive_rule_reason = "missing_rules"
        if aggressive_enabled and aggressive_options is not None:
            try:
                aggressive_rules = aggressive_options.rule_book.for_event(event_time)
            except DataIntegrityError as exc:
                reason = (
                    "ambiguous_rules" if "ambiguous" in str(exc) else "missing_rules"
                )
                constraint_rejections[reason] += 1
                for quote in tuple(active_quotes.values()):
                    if quote.lane == "aggressive_maker":
                        cancel_quote(quote, event_time, reason)
                aggressive_rule_reason = reason
            else:
                aggressive_rule_reason = "invalid_rules"
                if exchange_rules_are_valid(aggressive_rules):
                    historical_rules_used = True
        if kind == "book":
            latest_book = payload
            midpoint = (payload.bid_price + payload.ask_price) / Decimal("2")
            pending_markouts.settle(
                event_time_ms=event_time,
                midpoint=midpoint,
            )
            if latest_book_ms is not None:
                stale_gap = event_time - latest_book_ms
                if stale_gap > max_book_age_ms:
                    excluded_stale_book_ms += stale_gap - max_book_age_ms
            if bar_start is None:
                bar_start = (event_time // BAR_INTERVAL_MS) * BAR_INTERVAL_MS
            bar_start, bar_midpoint = _close_bar(
                bar_start=bar_start,
                bar_midpoint=bar_midpoint,
                closed_closes=closed_closes,
                target=event_time,
            )

            bar_midpoint = midpoint
            latest_book_ms = event_time
            latest_midpoint = midpoint
            if (
                aggressive_rules is not None
                and exchange_rules_are_valid(aggressive_rules)
                and aggressive_rules.effective_from_ms
                <= event_time
                <= aggressive_rules.effective_to_ms
                and _book_is_executable(
                    payload,
                    event_time_ms=event_time,
                    max_book_age_ms=max_book_age_ms,
                )
            ):
                taker_bid_quantity = payload.bid_quantity
                taker_ask_quantity = payload.ask_quantity

            market_state = _compute_market_state(
                bundle=bundle,
                profile=profile,
                signed_base=baseline_signed_base,
                closes=tuple(closed_closes),
                latest_mid=midpoint,
                quote_ts=event_time,
                funding_bps_8h=latest_funding_bps_8h,
                market_data_provider=market_data_provider,
            )

            desired_by_level = {order.level_id: order for order in market_state.desired_orders}

            for quote in list(active_quotes.values()):
                if quote.lane != "baseline_maker":
                    continue
                reason = _quote_cancel_reason(
                    quote=quote,
                    event_time_ms=event_time,
                    reference_price=midpoint,
                    market_state=market_state,
                    desired_levels=desired_by_level,
                    config=config,
                )
                if reason is None:
                    continue
                cancel_quote(quote, event_time, reason)

            for order in market_state.desired_orders:
                key = ("baseline_maker", order.level_id)
                existing = active_quotes.get(key)
                baseline_reason = "create"
                baseline_price = order.price
                baseline_quantity = order.amount
                if aggressive_enabled:
                    if aggressive_rules is None:
                        decision = None
                        rejection_reason = aggressive_rule_reason
                    else:
                        constrained = constrain_order(
                            OrderCandidate(
                                lane="baseline_maker",
                                side=order.side,
                                execution="maker",
                                price=order.price,
                                quantity=order.amount,
                                reference_price=midpoint,
                                post_only=True,
                                max_slippage_bps=_decimal_zero(),
                            ),
                            aggressive_rules,
                            payload,
                            current_open_orders=(
                                len(active_quotes) - int(existing is not None)
                            ),
                        )
                        decision = constrained.order
                        rejection_reason = constrained.reason
                    if decision is None:
                        stable_reason = f"baseline_{rejection_reason}"
                        constraint_rejections[stable_reason] += 1
                        if existing is not None:
                            cancel_quote(existing, event_time, rejection_reason)
                        _record(
                            ledger_recorder,
                            sequence_counter,
                            event_type="constraint_reject",
                            row_data={
                                "event_time_ms": event_time,
                                "side": order.side,
                                "level_id": order.level_id,
                                "price": order.price,
                                "quantity": order.amount,
                                "reason": rejection_reason,
                                "lane": "baseline_maker",
                            },
                        )
                        continue
                    baseline_price = decision.price
                    baseline_quantity = decision.quantity
                    adjusted = (
                        baseline_price != order.price
                        or baseline_quantity != order.amount
                    )
                    baseline_reason = "accepted_adjusted" if adjusted else "create"
                    if adjusted:
                        constraint_rejections["baseline_order_adjusted"] += 1
                if existing is not None:
                    if (
                        existing.side == order.side
                        and existing.price == baseline_price
                        and existing.remaining_quantity > _decimal_zero()
                    ):
                        continue
                    # conservative refresh semantics: quote content changed
                    cancel_counts["level_not_desired"] += 1
                    _record(
                        ledger_recorder,
                        sequence_counter,
                        event_type="cancel",
                        row_data={
                            "event_time_ms": event_time,
                            "side": existing.side,
                            "level_id": existing.level_id,
                            "reason": "level_not_desired",
                            "lane": "baseline_maker" if aggressive_enabled else None,
                        },
                    )

                queue_ahead = payload.bid_quantity if order.side == "buy" else payload.ask_quantity
                maker_quote = MakerQuote(
                    quote_id=order.level_id,
                    side=order.side,
                    price=baseline_price,
                    quantity=baseline_quantity,
                    queue_ahead=queue_ahead,
                    placed_time_ms=event_time,
                )
                active_quotes[key] = _ActiveQuote(
                    lane="baseline_maker",
                    level_id=order.level_id,
                    side=order.side,
                    price=baseline_price,
                    placed_time_ms=event_time,
                    quoted_mid=midpoint,
                    queue_ahead=queue_ahead,
                    maker_mode=market_state.maker_mode,
                    inventory_state=market_state.inventory_state,
                    maker_quote=maker_quote,
                    fill_model=QueueFillModel(maker_quote),
                    remaining_quantity=baseline_quantity,
                )
                quote_create_attempts += 1
                if aggressive_enabled:
                    lane_quote_create_attempts["baseline_maker"] += 1
                _record(
                    ledger_recorder,
                    sequence_counter,
                    event_type="create",
                    row_data={
                        "event_time_ms": event_time,
                        "side": order.side,
                        "level_id": order.level_id,
                        "price": baseline_price,
                        "quantity": baseline_quantity,
                        "reason": baseline_reason,
                        "lane": "baseline_maker" if aggressive_enabled else None,
                    },
                )

            if feature_state is not None:
                feature_state.observe_book(payload)
                refresh_aggressive_quote(event_time, payload, aggressive_rules)

            snapshot_equity(event_time)
            continue

        if kind == "trade":
            trade = payload
            expire_aggressive_quotes(event_time)
            is_stale = latest_book_ms is None or (event_time - latest_book_ms) > max_book_age_ms
            if is_stale:
                continue

            if aggressive_enabled:
                allocated_fills = _allocate_trade_fills(
                    tuple(active_quotes.values()), trade
                )
            else:
                allocated_fills = (
                    (quote, quote.fill_model.on_trade(trade))
                    for quote in list(active_quotes.values())
                )
            for quote, fills in allocated_fills:
                for fill in fills:
                    before_remaining = quote.fill_model.remaining_quantity + fill.quantity
                    partial = fill.quantity < before_remaining
                    if partial:
                        partial_fill_count += 1
                    if fill.side == "buy":
                        fill_realized = -(fill.price * fill.quantity)
                        realized_pnl += fill_realized
                        realized_cash -= fill.price * fill.quantity
                        signed_base += fill.quantity
                        if aggressive_enabled:
                            lane_signed_base[quote.lane] += fill.quantity
                        if quote.lane == "baseline_maker":
                            baseline_signed_base += fill.quantity
                    else:
                        fill_realized = fill.price * fill.quantity
                        realized_pnl += fill_realized
                        realized_cash += fill.price * fill.quantity
                        signed_base -= fill.quantity
                        if aggressive_enabled:
                            lane_signed_base[quote.lane] -= fill.quantity
                        if quote.lane == "baseline_maker":
                            baseline_signed_base -= fill.quantity

                    fee_rate = (
                        aggressive_options.config.maker_fee_rate
                        if quote.lane == "aggressive_maker"
                        and aggressive_options is not None
                        else _to_decimal(config.fee_rate)
                    )
                    fee = fill.price * fill.quantity * fee_rate
                    maker_fees += fee
                    realized_cash -= fee
                    if aggressive_enabled:
                        lane_fill_count[quote.lane] += 1
                        lane_maker_fees[quote.lane] = lane_maker_fees.get(
                            quote.lane, _decimal_zero()
                        ) + fee
                        lane_realized_pnl[quote.lane] = lane_realized_pnl.get(
                            quote.lane, _decimal_zero()
                        ) + fill_realized

                    quote = _ActiveQuote(
                        lane=quote.lane,
                        level_id=quote.level_id,
                        side=quote.side,
                        price=quote.price,
                        placed_time_ms=quote.placed_time_ms,
                        quoted_mid=quote.quoted_mid,
                        queue_ahead=quote.fill_model.queue_ahead,
                        maker_mode=quote.maker_mode,
                        inventory_state=quote.inventory_state,
                        maker_quote=quote.maker_quote,
                        fill_model=quote.fill_model,
                        remaining_quantity=quote.fill_model.remaining_quantity,
                    )
                    fill_count += 1
                    maker_fill_count += 1
                    if aggressive_enabled:
                        lane_maker_fill_count[quote.lane] += 1
                    _record(
                        ledger_recorder,
                        sequence_counter,
                        event_type="fill",
                        row_data={
                            "event_time_ms": fill.event_time_ms,
                            "side": fill.side,
                            "level_id": quote.level_id,
                            "price": fill.price,
                            "quantity": fill.quantity,
                            "tag": (
                                "aggressive_l1_queue"
                                if quote.lane == "aggressive_maker"
                                else "l1_queue_lower_bound"
                            ),
                            "queue_ahead": quote.fill_model.queue_ahead,
                            "remaining_quantity": quote.fill_model.remaining_quantity,
                            "lane": quote.lane if aggressive_enabled else None,
                        },
                    )
                    pending_markouts.add(
                        event_time_ms=fill.event_time_ms,
                        side=fill.side,
                        price=fill.price,
                        lane=quote.lane if aggressive_enabled else None,
                    )
                    key = (quote.lane, quote.level_id)
                    active_quotes[key] = quote
                    if quote.fill_model.remaining_quantity <= _decimal_zero():
                        active_quotes.pop(key, None)

            if market_state.reference_price is not None:
                for quote in list(active_quotes.values()):
                    if quote.lane != "baseline_maker":
                        continue
                    reason = _quote_cancel_reason(
                        quote=quote,
                        event_time_ms=event_time,
                        reference_price=market_state.reference_price,
                        market_state=market_state,
                        desired_levels={order.level_id: order for order in market_state.desired_orders},
                        config=config,
                    )
                    if reason is None:
                        continue
                    cancel_quote(quote, event_time, reason)

            if feature_state is not None:
                feature_state.observe_trade(trade)
                if latest_book is not None:
                    refresh_aggressive_quote(
                        event_time,
                        replace(latest_book, event_time_ms=event_time),
                        aggressive_rules,
                    )

            snapshot_equity(event_time)
            continue

        if kind == "funding":
            funding = payload
            has_lane_inventory = aggressive_enabled and any(
                lane_signed_base[lane] != _decimal_zero()
                for lane in _ACCOUNTING_LANES
            )
            if latest_midpoint is not None and (
                signed_base != _decimal_zero() or has_lane_inventory
            ):
                cashflow = -(signed_base * latest_midpoint * funding.funding_rate)
                realized_cash += cashflow
                funding_pnl += cashflow
                if aggressive_enabled:
                    allocation = _allocate_lane_funding_cashflow(
                        lane_signed_base,
                        midpoint=latest_midpoint,
                        funding_rate=funding.funding_rate,
                        combined_cashflow=cashflow,
                    )
                    for lane, lane_cashflow in allocation.items():
                        lane_funding_pnl[lane] += lane_cashflow
                _record(
                        ledger_recorder,
                    sequence_counter,
                    event_type="funding",
                    row_data={
                        "event_time_ms": funding.funding_time_ms,
                        "price": latest_midpoint,
                        "quantity": funding.funding_rate,
                        "side": (
                            "long"
                            if signed_base > _decimal_zero()
                            else "short"
                            if signed_base < _decimal_zero()
                            else "flat"
                        ),
                    },
                )
                snapshot_equity(funding.funding_time_ms)
            latest_funding_bps_8h = funding.funding_rate * Decimal("10000")
            continue

    def frozen_lane_metrics(
        *,
        terminal_mark: Decimal = Decimal("0"),
        combined_terminal_inventory_quote: Decimal = Decimal("0"),
        combined_net_pnl: Decimal = Decimal("0"),
        lane_liquidation_costs: Mapping[str, Decimal] | None = None,
        liquidation_available: bool = True,
    ) -> Mapping[str, LaneMetrics]:
        if not aggressive_enabled:
            return MappingProxyType({})
        lane_inventory_quote = {
            lane: lane_signed_base[lane] * terminal_mark
            for lane in _ACCOUNTING_LANES
        }
        inventory_residual = combined_terminal_inventory_quote - sum(
            lane_inventory_quote.values(), _decimal_zero()
        )
        residual_lane = next(
            (
                lane
                for lane in reversed(_ACCOUNTING_LANES)
                if lane_signed_base[lane] != _decimal_zero()
            ),
            _ACCOUNTING_LANES[-1],
        )
        lane_inventory_quote[residual_lane] += inventory_residual
        lane_nets = {
            lane: (
                lane_realized_pnl.get(lane, _decimal_zero())
                + lane_inventory_quote[lane]
                - lane_maker_fees.get(lane, _decimal_zero())
                - lane_taker_fees.get(lane, _decimal_zero())
                + lane_funding_pnl[lane]
            )
            for lane in _ACCOUNTING_LANES
        }
        lane_nets[residual_lane] += combined_net_pnl - sum(
            lane_nets.values(), _decimal_zero()
        )
        return MappingProxyType(
            {
                lane: LaneMetrics(
                    quote_create_attempts=lane_quote_create_attempts[lane],
                    fill_count=lane_fill_count[lane],
                    maker_fill_count=lane_maker_fill_count[lane],
                    maker_fill_rate=(
                        Decimal(lane_maker_fill_count[lane])
                        / Decimal(lane_quote_create_attempts[lane])
                        if lane_quote_create_attempts[lane]
                        else _decimal_zero()
                    ),
                    taker_attempt_count=lane_taker_attempt_count[lane],
                    taker_execution_count=lane_taker_execution_count[lane],
                    taker_execution_rate=(
                        Decimal(lane_taker_execution_count[lane])
                        / Decimal(lane_taker_attempt_count[lane])
                        if lane_taker_attempt_count[lane]
                        else _decimal_zero()
                    ),
                    average_markout_1s_bps=pending_markouts.lane_result(lane, 1_000)[0],
                    average_markout_5s_bps=pending_markouts.lane_result(lane, 5_000)[0],
                    average_markout_60s_bps=pending_markouts.lane_result(lane, 60_000)[0],
                    markout_1s_eligible_count=pending_markouts.lane_result(lane, 1_000)[1],
                    markout_1s_missing_count=pending_markouts.lane_result(lane, 1_000)[2],
                    markout_5s_eligible_count=pending_markouts.lane_result(lane, 5_000)[1],
                    markout_5s_missing_count=pending_markouts.lane_result(lane, 5_000)[2],
                    markout_60s_eligible_count=pending_markouts.lane_result(lane, 60_000)[1],
                    markout_60s_missing_count=pending_markouts.lane_result(lane, 60_000)[2],
                    maker_fees=lane_maker_fees.get(lane, _decimal_zero()),
                    taker_fees=lane_taker_fees.get(lane, _decimal_zero()),
                    realized_pnl=lane_realized_pnl.get(lane, _decimal_zero()),
                    signed_terminal_inventory_base=lane_signed_base[lane],
                    terminal_inventory_quote=lane_inventory_quote[lane],
                    funding_pnl=lane_funding_pnl[lane],
                    unrealized_pnl=lane_inventory_quote[lane],
                    net_pnl=lane_nets[lane],
                    liquidation_cost=(
                        None
                        if not liquidation_available
                        else (
                            lane_liquidation_costs.get(lane, _decimal_zero())
                            if lane_liquidation_costs is not None
                            else _decimal_zero()
                        )
                    ),
                    liquidation_adjusted_net_pnl=(
                        None
                        if not liquidation_available
                        else lane_nets[lane]
                        - (
                            lane_liquidation_costs.get(lane, _decimal_zero())
                            if lane_liquidation_costs is not None
                            else _decimal_zero()
                        )
                    ),
                )
                for lane in _ACCOUNTING_LANES
            }
        )

    def frozen_constraint_rejections() -> Mapping[str, int]:
        return MappingProxyType(dict(sorted(constraint_rejections.items())))

    if not saw_event:
        return ProfileReplayResult(
            fill_count=0,
            quote_create_attempts=0,
            excluded_stale_book_ms=0,
            cancel_reasons=MappingProxyType({key: 0 for key in _REASON_KEYS}),
            maker_fees=_decimal_zero(),
            funding_pnl=_decimal_zero(),
            realized_pnl=_decimal_zero(),
            unrealized_pnl=_decimal_zero(),
            net_pnl=_decimal_zero(),
            terminal_inventory_quote=_decimal_zero(),
            max_drawdown=_decimal_zero(),
            average_markout_1s_bps=None,
            average_markout_5s_bps=None,
            average_markout_60s_bps=None,
            fill_rate=_decimal_zero(),
            partial_fill_ratio=_decimal_zero(),
            markout_1s_eligible_count=0,
            markout_1s_missing_count=0,
            markout_5s_eligible_count=0,
            markout_5s_missing_count=0,
            markout_60s_eligible_count=0,
            markout_60s_missing_count=0,
            profile=profile,
            ledger=ledger_recorder.finish(),
            integrity_passed=False,
            net_return=_decimal_zero(),
            limitations=(
                "EMPTY_REPLAY_INPUT",
                "L1_QUEUE_LOWER_BOUND",
                "NON_HISTORICAL_RULES",
            ),
            undeclared_limitations=False,
            initial_equity=initial_equity,
            lane_metrics=frozen_lane_metrics(),
            constraint_rejections=frozen_constraint_rejections(),
            terminal_close_taker_fee_rate=terminal_close_taker_fee_rate,
            terminal_close_slippage_bps=terminal_close_slippage_bps,
        )

    final_time = max(final_time, latest_book_ms or 0)
    if latest_book_ms is not None:
        trailing_gap = final_time - latest_book_ms
        if trailing_gap > max_book_age_ms:
            excluded_stale_book_ms += trailing_gap - max_book_age_ms

    for quote in list(active_quotes.values()):
        cancel_counts["end_of_data"] += 1
        _record(
            ledger_recorder,
            sequence_counter,
            event_type="cancel",
            row_data={
                "event_time_ms": final_time,
                "side": quote.side,
                "level_id": quote.level_id,
                "reason": "end_of_data",
                "lane": quote.lane if aggressive_enabled else None,
            },
        )
    active_quotes.clear()

    terminal_mark = latest_midpoint or _decimal_zero()
    terminal_inventory_quote = signed_base * terminal_mark

    snapshot_equity(final_time)
    pending_markouts.finish()
    (
        average_markout_1s_bps,
        markout_1s_eligible_count,
        markout_1s_missing_count,
    ) = pending_markouts.result(1_000)
    (
        average_markout_5s_bps,
        markout_5s_eligible_count,
        markout_5s_missing_count,
    ) = pending_markouts.result(5_000)
    (
        average_markout_60s_bps,
        markout_60s_eligible_count,
        markout_60s_missing_count,
    ) = pending_markouts.result(60_000)

    realized_total = realized_pnl
    unrealized_pnl = terminal_inventory_quote
    net = realized_total + unrealized_pnl - maker_fees - taker_fees + funding_pnl
    combined_fill_count = Decimal(fill_count)
    maker_fill_count_decimal = Decimal(maker_fill_count)
    fill_attempts = Decimal(str(quote_create_attempts if quote_create_attempts else 1))
    limitations = {
        "L1_QUEUE_LOWER_BOUND",
    }
    if not historical_rules_used:
        limitations.add("NON_HISTORICAL_RULES")
    if markout_1s_missing_count:
        limitations.add("INCOMPLETE_MARKOUT_1S")
    if markout_5s_missing_count:
        limitations.add("INCOMPLETE_MARKOUT_5S")
    if markout_60s_missing_count:
        limitations.add("INCOMPLETE_MARKOUT_60S")

    liquidation_cost: Decimal | None = _decimal_zero()
    liquidation_adjusted_net_pnl: Decimal | None = net
    lane_liquidation_costs: Mapping[str, Decimal] | None = MappingProxyType(
        {lane: _decimal_zero() for lane in _ACCOUNTING_LANES}
    )
    integrity_passed = True
    if signed_base != _decimal_zero():
        terminal_book_valid = latest_book is not None and _book_is_executable(
            latest_book,
            event_time_ms=final_time,
            max_book_age_ms=max_book_age_ms,
        )
        if not terminal_book_valid:
            liquidation_cost = None
            liquidation_adjusted_net_pnl = None
            lane_liquidation_costs = None
            integrity_passed = False
            limitations.add("TERMINAL_LIQUIDATION_UNAVAILABLE")
        else:
            try:
                side, price, quantity, liquidation_cost = _terminal_liquidation(
                    signed_base=signed_base,
                    terminal_mark=terminal_mark,
                    book=latest_book,
                    taker_fee_rate=terminal_close_taker_fee_rate,
                    slippage_bps=terminal_close_slippage_bps,
                )
            except (InvalidOperation, ValueError):
                liquidation_cost = None
                liquidation_adjusted_net_pnl = None
                lane_liquidation_costs = None
                integrity_passed = False
                limitations.add("TERMINAL_LIQUIDATION_UNAVAILABLE")
            else:
                liquidation_adjusted_net_pnl = net - liquidation_cost
                lane_liquidation_costs = _allocate_lane_liquidation_cost(
                    lane_signed_base,
                    liquidation_cost,
                )
                if aggressive_enabled:
                    _record(
                        ledger_recorder,
                        sequence_counter,
                        event_type="liquidation",
                        row_data={
                            "event_time_ms": final_time,
                            "side": side,
                            "price": price,
                            "quantity": quantity,
                            "tag": "terminal_executable_close",
                            "lane": "terminal_liquidation",
                        },
                    )

    return ProfileReplayResult(
        fill_count=fill_count,
        quote_create_attempts=quote_create_attempts,
        excluded_stale_book_ms=excluded_stale_book_ms,
        cancel_reasons=_quantized_map(cancel_counts),
        maker_fees=maker_fees,
        funding_pnl=funding_pnl,
        realized_pnl=realized_total,
        unrealized_pnl=unrealized_pnl,
        net_pnl=net,
        terminal_inventory_quote=terminal_inventory_quote,
        max_drawdown=max_drawdown,
        average_markout_1s_bps=average_markout_1s_bps,
        average_markout_5s_bps=average_markout_5s_bps,
        average_markout_60s_bps=average_markout_60s_bps,
        fill_rate=maker_fill_count_decimal / fill_attempts,
        partial_fill_ratio=(Decimal(partial_fill_count) / combined_fill_count) if fill_count else _decimal_zero(),
        markout_1s_eligible_count=markout_1s_eligible_count,
        markout_1s_missing_count=markout_1s_missing_count,
        markout_5s_eligible_count=markout_5s_eligible_count,
        markout_5s_missing_count=markout_5s_missing_count,
        markout_60s_eligible_count=markout_60s_eligible_count,
        markout_60s_missing_count=markout_60s_missing_count,
        profile=profile,
        ledger=ledger_recorder.finish(),
        integrity_passed=integrity_passed,
        net_return=net / initial_equity,
        limitations=tuple(sorted(limitations)),
        undeclared_limitations=False,
        initial_equity=initial_equity,
        lane_metrics=frozen_lane_metrics(
            terminal_mark=terminal_mark,
            combined_terminal_inventory_quote=terminal_inventory_quote,
            combined_net_pnl=net,
            lane_liquidation_costs=lane_liquidation_costs,
            liquidation_available=liquidation_adjusted_net_pnl is not None,
        ),
        signed_terminal_inventory_base=signed_base,
        taker_fees=taker_fees,
        taker_fee_spent=aggressive_budget.taker_fee_spent,
        liquidation_cost=liquidation_cost,
        liquidation_adjusted_net_pnl=liquidation_adjusted_net_pnl,
        constraint_rejections=frozen_constraint_rejections(),
        maker_fill_count=maker_fill_count,
        taker_attempt_count=taker_attempt_count,
        taker_execution_count=taker_execution_count,
        taker_execution_rate=(
            Decimal(taker_execution_count) / Decimal(taker_attempt_count)
            if taker_attempt_count
            else _decimal_zero()
        ),
        terminal_close_taker_fee_rate=terminal_close_taker_fee_rate,
        terminal_close_slippage_bps=terminal_close_slippage_bps,
    )


def run_profile(
    bundle: VerifiedBundle,
    profile: ResolvedProfile,
    initial_equity: Decimal = Decimal("400"),
    *,
    ledger_sink: str | Path | None = None,
    aggressive_options: AggressiveReplayOptions | None = None,
    terminal_close_assumptions: TerminalCloseAssumptions | None = None,
) -> ProfileReplayResult:
    with localcontext(_DECIMAL_CONTEXT):
        return _run_profile(
            bundle,
            profile,
            initial_equity,
            ledger_sink=ledger_sink,
            aggressive_options=aggressive_options,
            terminal_close_assumptions=terminal_close_assumptions,
        )


__all__ = [
    "AggressiveReplayOptions",
    "LaneMetrics",
    "ProfileReplayResult",
    "ReplayLedger",
    "ReplayLedgerRow",
    "ReplayMetrics",
    "TerminalCloseAssumptions",
    "run_profile",
]
