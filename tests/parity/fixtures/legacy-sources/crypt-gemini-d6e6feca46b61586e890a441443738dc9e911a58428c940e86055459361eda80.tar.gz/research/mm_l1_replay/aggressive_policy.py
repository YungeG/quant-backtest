from __future__ import annotations

from dataclasses import dataclass, fields
from datetime import date, timedelta
from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext

from .aggressive_signals import SignalPrediction
from .contracts import BookTicker
from .exchange_rules import (
    ExchangeRuleSnapshot,
    OrderCandidate,
    constrain_order,
    exchange_rules_are_valid,
)


_BPS = Decimal("10000")
_ZERO = Decimal("0")
_DAY_MS = 86_400_000
_MINUTE_MS = 60_000

# Copying this module-owned context isolates every public calculation from the
# caller's Decimal precision and never mutates the process-wide context.
_DECIMAL_CONTEXT = Context(
    prec=50,
    Emin=-999_999,
    Emax=999_999,
    capitals=1,
    clamp=0,
)
_DECIMAL_CONTEXT.traps[InvalidOperation] = True
_DECIMAL_CONTEXT.traps[DivisionByZero] = True
_DECIMAL_CONTEXT.traps[Overflow] = True


def _require_decimal(value: object, name: str) -> Decimal:
    if isinstance(value, float):
        raise TypeError(f"float values are not allowed for {name}")
    if not isinstance(value, Decimal):
        raise TypeError(f"{name} must be Decimal")
    if not value.is_finite():
        raise ValueError(f"{name} must be finite")
    return value


@dataclass(frozen=True)
class AggressiveConfig:
    enabled: bool
    maker_distance_ticks: int
    order_notional: Decimal
    order_lifetime_ms: int
    min_confidence: Decimal
    maker_min_edge_bps: Decimal
    taker_min_edge_bps: Decimal
    maker_fee_rate: Decimal
    taker_fee_rate: Decimal
    risk_buffer_bps: Decimal
    max_taker_slippage_bps: Decimal
    max_takers_per_minute: int
    daily_taker_fee_budget: Decimal
    max_book_age_ms: int = 5_000

    def __post_init__(self) -> None:
        if not isinstance(self.enabled, bool):
            raise TypeError("enabled must be bool")
        for name in (
            "maker_distance_ticks",
            "order_lifetime_ms",
            "max_takers_per_minute",
            "max_book_age_ms",
        ):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError(f"{name} must be int")
            if value < 0:
                raise ValueError(f"{name} must be non-negative")
        if self.maker_distance_ticks == 0:
            raise ValueError("maker_distance_ticks must be positive")
        if self.order_lifetime_ms == 0:
            raise ValueError("order_lifetime_ms must be positive")

        for field in fields(self):
            if field.name in {
                "enabled",
                "maker_distance_ticks",
                "order_lifetime_ms",
                "max_takers_per_minute",
                "max_book_age_ms",
            }:
                continue
            value = _require_decimal(getattr(self, field.name), field.name)
            if value < _ZERO:
                raise ValueError(f"{field.name} must be non-negative")
        if self.order_notional == _ZERO:
            raise ValueError("order_notional must be positive")
        if self.min_confidence > Decimal("1"):
            raise ValueError("min_confidence must not exceed one")
        for name in ("maker_fee_rate", "taker_fee_rate"):
            if getattr(self, name) > Decimal("1"):
                raise ValueError(f"{name} must not exceed one")
        for name in (
            "maker_min_edge_bps",
            "taker_min_edge_bps",
            "risk_buffer_bps",
            "max_taker_slippage_bps",
        ):
            if getattr(self, name) > _BPS:
                raise ValueError(f"{name} must not exceed 10000")


@dataclass(frozen=True)
class AggressiveBudgetState:
    taker_event_times_ms: tuple[int, ...] = ()
    taker_fee_spent: Decimal = Decimal("0")
    fee_day_utc: date | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.taker_event_times_ms, tuple):
            raise TypeError("taker_event_times_ms must be a tuple")
        for timestamp in self.taker_event_times_ms:
            if not isinstance(timestamp, int) or isinstance(timestamp, bool):
                raise TypeError("taker event timestamps must be integers")
            if timestamp < 0:
                raise ValueError("taker event timestamps must be non-negative")
        object.__setattr__(
            self,
            "taker_event_times_ms",
            tuple(sorted(self.taker_event_times_ms)),
        )
        fee_spent = _require_decimal(self.taker_fee_spent, "taker_fee_spent")
        if fee_spent < _ZERO:
            raise ValueError("taker_fee_spent must be non-negative")
        if self.fee_day_utc is not None and type(self.fee_day_utc) is not date:
            raise TypeError("fee_day_utc must be a date or None")
        if fee_spent > _ZERO and self.fee_day_utc is None:
            raise ValueError("nonzero taker_fee_spent requires fee_day_utc")


@dataclass(frozen=True)
class AggressiveDecision:
    maker: OrderCandidate | None
    taker: OrderCandidate | None
    maker_reason: str
    taker_reason: str


def _rejected(reason: str) -> AggressiveDecision:
    return AggressiveDecision(None, None, reason, reason)


def _utc_day(event_time_ms: int) -> date:
    return date(1970, 1, 1) + timedelta(days=event_time_ms // _DAY_MS)


def _validate_market(
    book: BookTicker,
    config: AggressiveConfig,
    rules: ExchangeRuleSnapshot | None,
) -> str | None:
    if rules is None:
        return "missing_rules"
    if not exchange_rules_are_valid(rules):
        return "invalid_rules"
    try:
        bid = _require_decimal(book.bid_price, "bid_price")
        ask = _require_decimal(book.ask_price, "ask_price")
        bid_quantity = _require_decimal(book.bid_quantity, "bid_quantity")
        ask_quantity = _require_decimal(book.ask_quantity, "ask_quantity")
    except (TypeError, ValueError):
        return "non_positive_book"
    if min(bid, ask, bid_quantity, ask_quantity) <= _ZERO:
        return "non_positive_book"
    if bid >= ask:
        return "crossed_book"
    if (
        not isinstance(book.event_time_ms, int)
        or isinstance(book.event_time_ms, bool)
        or not isinstance(book.transaction_time_ms, int)
        or isinstance(book.transaction_time_ms, bool)
        or book.event_time_ms < 0
        or book.transaction_time_ms < 0
        or book.transaction_time_ms > book.event_time_ms
        or book.event_time_ms - book.transaction_time_ms > config.max_book_age_ms
    ):
        return "stale_book"
    if not rules.effective_from_ms <= book.event_time_ms <= rules.effective_to_ms:
        return "rule_not_effective"
    return None


def _validated_prediction(
    prediction: SignalPrediction | None,
) -> tuple[Decimal, Decimal] | None:
    if not isinstance(prediction, SignalPrediction):
        return None
    try:
        confidence = _require_decimal(prediction.confidence, "confidence")
        _require_decimal(prediction.markout_1s_bps, "markout_1s_bps")
        markout_5s = _require_decimal(prediction.markout_5s_bps, "markout_5s_bps")
        _require_decimal(prediction.markout_60s_bps, "markout_60s_bps")
        direction = prediction.direction
    except (AttributeError, TypeError, ValueError):
        return None
    if (
        confidence < _ZERO
        or confidence > Decimal("1")
        or direction not in {"buy", "sell", "neutral"}
    ):
        return None
    if direction == "buy":
        edge = markout_5s
    elif direction == "sell":
        edge = -markout_5s
    else:
        edge = _ZERO
    return confidence, edge


def _candidate(
    *,
    lane: str,
    side: str,
    execution: str,
    price: Decimal,
    config: AggressiveConfig,
    reference_price: Decimal,
) -> OrderCandidate:
    with localcontext(_DECIMAL_CONTEXT):
        quantity = config.order_notional / price
    return OrderCandidate(
        lane=lane,
        side=side,
        execution=execution,
        price=price,
        quantity=quantity,
        reference_price=reference_price,
        post_only=execution == "maker",
        max_slippage_bps=(
            _ZERO if execution == "maker" else config.max_taker_slippage_bps
        ),
    )


def build_aggressive_decision(
    prediction: SignalPrediction | None,
    book: BookTicker,
    config: AggressiveConfig,
    budget: AggressiveBudgetState,
    rules: ExchangeRuleSnapshot | None,
) -> AggressiveDecision:
    if not config.enabled:
        return _rejected("disabled")

    validated_prediction = _validated_prediction(prediction)
    if validated_prediction is None:
        return _rejected("invalid_prediction")
    confidence, edge = validated_prediction
    if confidence < config.min_confidence:
        return _rejected("confidence_below_threshold")
    assert prediction is not None
    if prediction.direction == "neutral":
        return _rejected("neutral_signal")

    market_reason = _validate_market(book, config, rules)
    if market_reason is not None:
        return _rejected(market_reason)
    assert rules is not None

    side = prediction.direction
    with localcontext(_DECIMAL_CONTEXT):
        maker_cost = config.maker_fee_rate * _BPS + config.risk_buffer_bps
        taker_cost = (
            config.taker_fee_rate * _BPS
            + config.max_taker_slippage_bps
            + config.risk_buffer_bps
        )
        maker_required = config.maker_min_edge_bps + maker_cost
        taker_required = config.taker_min_edge_bps + taker_cost

        if side == "buy":
            maker_reference = book.ask_price
            maker_price = maker_reference - config.maker_distance_ticks * rules.tick_size
            taker_price = book.ask_price
        else:
            maker_reference = book.bid_price
            maker_price = maker_reference + config.maker_distance_ticks * rules.tick_size
            taker_price = book.bid_price

    maker: OrderCandidate | None = None
    maker_reason = "edge_below_cost"
    if edge >= maker_required and maker_price > _ZERO:
        raw_maker = _candidate(
            lane="aggressive_maker",
            side=side,
            execution="maker",
            price=maker_price,
            config=config,
            reference_price=maker_reference,
        )
        maker_constraint = constrain_order(raw_maker, rules, book)
        if maker_constraint.order is None:
            maker_reason = maker_constraint.reason
        else:
            maker = raw_maker
            maker_reason = "candidate"

    current_day = _utc_day(book.event_time_ms)
    budget_is_future = any(
        timestamp > book.event_time_ms
        for timestamp in budget.taker_event_times_ms
    ) or (
        budget.fee_day_utc is not None
        and budget.fee_day_utc > current_day
    )
    taker: OrderCandidate | None = None
    taker_reason = "invalid_budget_state" if budget_is_future else "edge_below_cost"
    if not budget_is_future and edge >= taker_required:
        raw_taker = _candidate(
            lane="aggressive_taker",
            side=side,
            execution="taker",
            price=taker_price,
            config=config,
            reference_price=taker_price,
        )
        taker_constraint = constrain_order(raw_taker, rules, book)
        if taker_constraint.order is None:
            taker_reason = taker_constraint.reason
        else:
            cutoff = book.event_time_ms - _MINUTE_MS
            recent_takers = sum(
                cutoff < timestamp <= book.event_time_ms
                for timestamp in budget.taker_event_times_ms
            )
            if recent_takers >= config.max_takers_per_minute:
                taker_reason = "taker_rate_limit"
            else:
                fee_spent = (
                    budget.taker_fee_spent
                    if budget.fee_day_utc == current_day
                    else _ZERO
                )
                constrained_taker = taker_constraint.order
                with localcontext(_DECIMAL_CONTEXT):
                    projected_fee = (
                        constrained_taker.price
                        * constrained_taker.quantity
                        * config.taker_fee_rate
                    )
                    projected_spend = fee_spent + projected_fee
                if projected_spend > config.daily_taker_fee_budget:
                    taker_reason = "taker_budget_exhausted"
                else:
                    taker = raw_taker
                    taker_reason = "candidate"

    return AggressiveDecision(maker, taker, maker_reason, taker_reason)


__all__ = [
    "AggressiveBudgetState",
    "AggressiveConfig",
    "AggressiveDecision",
    "build_aggressive_decision",
]
