"""Deterministic development/holdout orchestration for fill-return research."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from datetime import date
from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext
from hashlib import sha256
from itertools import product
import os
from pathlib import Path
import shutil
import tempfile
from types import MappingProxyType

import yaml

from .aggressive_policy import AggressiveConfig
from .aggressive_signals import (
    collect_calibration_observations,
    fit_quantile_signal_model,
)
from .bundle import load_verified_bundle
from .contracts import DataIntegrityError, VerifiedBundle, canonical_sha256, decimal_json
from .engine import (
    AggressiveReplayOptions,
    ProfileReplayResult,
    TerminalCloseAssumptions,
    run_profile,
)
from .exchange_rules import (
    ExchangeRuleBook,
    load_exchange_rule_snapshot,
)
from .pareto import CandidateSummary, ParetoResult, select_pareto
from .profiles import BASELINE_NAME, load_profiles
from .report import build_experiment_report


MAX_GRID_CANDIDATES = 4_096
EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS = TerminalCloseAssumptions(
    taker_fee_rate=Decimal("0.0004"),
    slippage_bps=Decimal("2"),
)
_AUTHORIZATION = {
    "grade": "engineering_replay",
    "decision_grade_eligible": False,
    "paper_trading_authorized": False,
    "live_trading_authorized": False,
}
_DECIMAL_CONTEXT = Context(
    prec=50,
    Emin=-999_999,
    Emax=999_999,
    capitals=1,
    clamp=0,
)
_DECIMAL_CONTEXT.traps[InvalidOperation] = True
_DECIMAL_CONTEXT.traps[DivisionByZero] = True
_DECIMAL_CONTEXT.traps[Overflow] = True
_ARTIFACT_NAMES = (
    "pareto.json",
    "signal_model.json",
    "result.json",
    "validation.json",
    "ledger.jsonl",
    "report.md",
)

_DIMENSION_FIELDS = (
    "maker_distance_ticks",
    "order_notional",
    "order_lifetime_ms",
    "min_confidence",
    "maker_min_edge_bps",
    "taker_min_edge_bps",
    "max_taker_slippage_bps",
    "max_takers_per_minute",
    "daily_taker_fee_budget",
)
_FIXED_FIELDS = (
    "maker_fee_rate",
    "taker_fee_rate",
    "risk_buffer_bps",
    "max_book_age_ms",
)
_INTEGER_FIELDS = frozenset(
    {
        "maker_distance_ticks",
        "order_lifetime_ms",
        "max_takers_per_minute",
        "max_book_age_ms",
    }
)


@dataclass(frozen=True)
class ExperimentCandidate:
    candidate_hash: str
    config: AggressiveConfig


@dataclass(frozen=True)
class ExperimentDay:
    date: date
    manifest_path: Path
    manifest_hash: str
    bundle: VerifiedBundle
    rule_book: ExchangeRuleBook


@dataclass(frozen=True)
class ExperimentSplit:
    development: tuple[ExperimentDay, ...]
    holdout: tuple[ExperimentDay, ...]


@dataclass(frozen=True)
class ExperimentArtifactSet:
    output_dir: Path
    canonical_hash: str
    signal_model_hash: str
    frozen_candidate_hashes: tuple[str, ...]
    artifact_hashes: Mapping[str, str]
    replay_execution_count: int
    published_ledger_row_count: int

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "artifact_hashes",
            MappingProxyType(dict(sorted(self.artifact_hashes.items()))),
        )


@dataclass(frozen=True)
class _ReplayRun:
    stage: str
    day: ExperimentDay
    candidate_hash: str
    config: AggressiveConfig | None
    result: ProfileReplayResult
    validation_reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class _Aggregate:
    candidate_hash: str
    config: AggressiveConfig | None
    summary: CandidateSummary
    runs: tuple[_ReplayRun, ...]


def _require_exact_keys(
    value: object,
    expected: set[str],
    label: str,
) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{label} must be a mapping")
    if any(not isinstance(key, str) for key in value):
        raise TypeError(f"{label} keys must be strings")
    actual = set(value)
    if actual != expected:
        missing = sorted(expected - actual)
        unknown = sorted(actual - expected)
        detail = []
        if missing:
            detail.append(f"missing: {', '.join(missing)}")
        if unknown:
            detail.append(f"unknown: {', '.join(unknown)}")
        raise ValueError(f"{label} fields do not match schema ({'; '.join(detail)})")
    return value


def _canonical_decimal_text(value: object, label: str) -> str:
    if isinstance(value, (float, bool)):
        raise TypeError(f"{label} must not be a float or bool")
    if not isinstance(value, (str, int, Decimal)):
        raise TypeError(f"{label} must be a decimal string or integer")
    if isinstance(value, str) and (not value or value.strip() != value):
        raise ValueError(f"{label} must be a canonical nonempty decimal string")
    try:
        parsed = Decimal(value) if not isinstance(value, int) else Decimal(value)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{label} must be a valid decimal") from exc
    if not parsed.is_finite():
        raise ValueError(f"{label} must be finite")
    if parsed == 0:
        return "0"
    sign, digits, exponent = parsed.as_tuple()
    if len(digits) > 50 or abs(parsed.adjusted()) > 18:
        raise ValueError(f"{label} exceeds the supported decimal magnitude")
    coefficient = "".join(str(digit) for digit in digits)
    if exponent >= 0:
        body = coefficient + "0" * exponent
    else:
        point = len(coefficient) + exponent
        body = (
            coefficient[:point] + "." + coefficient[point:]
            if point > 0
            else "0." + "0" * (-point) + coefficient
        )
        body = body.rstrip("0").rstrip(".")
    return ("-" if sign else "") + body


def _normalize_field(name: str, value: object, label: str) -> int | Decimal:
    if name in _INTEGER_FIELDS:
        if type(value) is not int:
            raise TypeError(f"{label} must be an integer")
        return value
    return Decimal(_canonical_decimal_text(value, label))


def _config_payload(config: AggressiveConfig) -> dict[str, object]:
    return {
        name: (
            getattr(config, name)
            if name in _INTEGER_FIELDS or name == "enabled"
            else _canonical_decimal_text(getattr(config, name), name)
        )
        for name in ("enabled", *_DIMENSION_FIELDS, *_FIXED_FIELDS)
    }


def expand_experiment_grid(grid: Mapping[str, object]) -> tuple[ExperimentCandidate, ...]:
    """Validate and canonically expand the deliberately narrow Task 8 grid."""

    top = _require_exact_keys(
        grid,
        {"schema_version", "dimensions", "fixed"},
        "grid",
    )
    if top["schema_version"] != 1 or type(top["schema_version"]) is not int:
        raise ValueError("grid.schema_version must be integer 1")
    dimensions = _require_exact_keys(
        top["dimensions"], set(_DIMENSION_FIELDS), "grid.dimensions"
    )
    fixed = _require_exact_keys(top["fixed"], set(_FIXED_FIELDS), "grid.fixed")

    normalized_dimensions: dict[str, tuple[int | Decimal, ...]] = {}
    candidate_count = 1
    for name in _DIMENSION_FIELDS:
        raw_values = dimensions[name]
        if isinstance(raw_values, (str, bytes)) or not isinstance(raw_values, Sequence):
            raise TypeError(f"grid.dimensions.{name} must be a list")
        if not raw_values:
            raise ValueError(f"grid.dimensions.{name} must not be empty")
        values = tuple(
            _normalize_field(name, value, f"grid.dimensions.{name}")
            for value in raw_values
        )
        if len(set(values)) != len(values):
            raise ValueError(f"grid.dimensions.{name} contains duplicate values")
        normalized_dimensions[name] = tuple(sorted(values))
        candidate_count *= len(values)
        if candidate_count > MAX_GRID_CANDIDATES:
            raise ValueError(
                f"grid exceeds {MAX_GRID_CANDIDATES} candidates"
            )

    normalized_fixed = {
        name: _normalize_field(name, fixed[name], f"grid.fixed.{name}")
        for name in _FIXED_FIELDS
    }
    candidates: list[ExperimentCandidate] = []
    for values in product(*(normalized_dimensions[name] for name in _DIMENSION_FIELDS)):
        config = AggressiveConfig(
            enabled=True,
            **dict(zip(_DIMENSION_FIELDS, values)),
            **normalized_fixed,
        )
        candidate_hash = canonical_sha256(_config_payload(config))
        candidates.append(ExperimentCandidate(candidate_hash, config))
    return tuple(sorted(candidates, key=lambda item: item.candidate_hash))


def load_experiment_grid(path: str | Path) -> Mapping[str, object]:
    """Safely load a YAML grid and validate it before returning."""

    try:
        payload = yaml.safe_load(Path(path).read_bytes())
    except (OSError, yaml.YAMLError) as exc:
        raise ValueError(f"invalid experiment grid: {path}") from exc
    if not isinstance(payload, Mapping):
        raise ValueError("experiment grid must be a mapping")
    # Expansion performs the complete schema/type/cardinality validation.
    expand_experiment_grid(payload)
    return dict(payload)


def orchestration_operation_counts(
    development_candidate_count: int,
    frozen_candidate_count: int,
    *,
    development_reproduced_candidate_count: int | None = None,
) -> Mapping[str, int]:
    """Return the deterministic 5/15 replay-operation budget."""

    if development_reproduced_candidate_count is None:
        development_reproduced_candidate_count = frozen_candidate_count
    for label, value in (
        ("development_candidate_count", development_candidate_count),
        ("frozen_candidate_count", frozen_candidate_count),
        (
            "development_reproduced_candidate_count",
            development_reproduced_candidate_count,
        ),
    ):
        if type(value) is not int or value < 0:
            raise ValueError(f"{label} must be a nonnegative integer")
    if development_reproduced_candidate_count > development_candidate_count:
        raise ValueError(
            "development_reproduced_candidate_count cannot exceed "
            "development_candidate_count"
        )
    counts = {
        "development_search": 5 * (1 + development_candidate_count),
        "development_selected_reproduction": (
            5 * development_reproduced_candidate_count
        ),
        "holdout_evaluation": 15 * (1 + frozen_candidate_count),
        "holdout_frozen_reproduction": 15 * frozen_candidate_count,
    }
    counts["total"] = sum(counts.values())
    return MappingProxyType(counts)


def _manifest_hash(bundle: VerifiedBundle) -> str:
    manifest = bundle.manifest
    return canonical_sha256(
        {
            "symbol": manifest.symbol,
            "window": {
                "start_date": manifest.window.start_date,
                "end_date": manifest.window.end_date,
            },
            "files": [
                {"kind": item.kind, "date": item.date, "sha256": item.sha256}
                for item in sorted(
                    manifest.files,
                    key=lambda item: (item.kind, item.date, item.sha256),
                )
            ],
        }
    )


def _canonical_manifest_paths(
    paths: Sequence[str | Path],
    label: str,
) -> tuple[Path, ...]:
    if isinstance(paths, (str, bytes)) or not isinstance(paths, Sequence):
        raise TypeError(f"{label} manifests must be an explicit list")
    normalized = tuple(Path(path).resolve() for path in paths)
    if len(set(normalized)) != len(normalized):
        raise ValueError(f"duplicate {label} manifest path")
    return normalized


def _load_experiment_day(path: Path) -> ExperimentDay:
    bundle = load_verified_bundle(path)
    window = bundle.manifest.window
    if window.start_date != window.end_date:
        raise ValueError(f"{path}: experiment manifests must have a single-day window")
    if not bundle.exchange_rule_paths:
        raise ValueError(f"{path}: missing exchange rule snapshots")
    if len(set(bundle.exchange_rule_paths)) != len(bundle.exchange_rule_paths):
        raise ValueError(f"{path}: duplicate exchange rule snapshot path")
    snapshots = tuple(
        load_exchange_rule_snapshot(rule_path)
        for rule_path in bundle.exchange_rule_paths
    )
    if any(snapshot.symbol != bundle.manifest.symbol for snapshot in snapshots):
        raise ValueError(f"{path}: exchange rule symbol does not match manifest")
    start_ms = (window.start_date - date(1970, 1, 1)).days * 86_400_000
    end_ms = start_ms + 86_400_000 - 1
    relevant = tuple(
        sorted(
            (
                snapshot
                for snapshot in snapshots
                if snapshot.effective_from_ms <= end_ms
                and snapshot.effective_to_ms >= start_ms
            ),
            key=lambda snapshot: (
                snapshot.effective_from_ms,
                snapshot.effective_to_ms,
                snapshot.source_sha256,
            ),
        )
    )
    cursor = start_ms
    for snapshot in relevant:
        segment_start = max(start_ms, snapshot.effective_from_ms)
        segment_end = min(end_ms, snapshot.effective_to_ms)
        if segment_start != cursor:
            raise ValueError(
                f"{path}: exchange rule snapshots do not cover manifest day exactly once"
            )
        cursor = segment_end + 1
    if cursor != end_ms + 1:
        raise ValueError(
            f"{path}: exchange rule snapshots do not cover manifest day exactly once"
        )
    rule_book = ExchangeRuleBook(snapshots)
    return ExperimentDay(
        date=window.start_date,
        manifest_path=path,
        manifest_hash=_manifest_hash(bundle),
        bundle=bundle,
        rule_book=rule_book,
    )


def _require_unique_dates(days: tuple[ExperimentDay, ...], label: str) -> None:
    seen: set[date] = set()
    for item in days:
        if item.date in seen:
            raise ValueError(f"duplicate {label} date: {item.date.isoformat()}")
        seen.add(item.date)


def validate_experiment_split(
    development_manifests: Sequence[str | Path],
    holdout_manifests: Sequence[str | Path],
) -> ExperimentSplit:
    """Load an exact, canonical, disjoint 5/15 daily experiment split."""

    if len(development_manifests) != 5 or len(holdout_manifests) != 15:
        raise ValueError(
            "experiment requires exactly five development and fifteen holdout manifests"
        )
    development_paths = _canonical_manifest_paths(
        development_manifests, "development"
    )
    holdout_paths = _canonical_manifest_paths(holdout_manifests, "holdout")
    if set(development_paths) & set(holdout_paths):
        raise ValueError("development and holdout manifest paths overlap")

    development = tuple(_load_experiment_day(path) for path in development_paths)
    holdout = tuple(_load_experiment_day(path) for path in holdout_paths)
    _require_unique_dates(development, "development")
    _require_unique_dates(holdout, "holdout")
    if {item.date for item in development} & {item.date for item in holdout}:
        raise ValueError("development and holdout dates overlap")
    return ExperimentSplit(
        development=tuple(sorted(development, key=lambda item: item.date)),
        holdout=tuple(sorted(holdout, key=lambda item: item.date)),
    )


def _require_decimal(value: object, label: str) -> Decimal:
    if type(value) is not Decimal or not value.is_finite():
        raise ValueError(f"{label} must be a finite Decimal")
    return value


def _result_reasons(
    result: ProfileReplayResult,
    config: AggressiveConfig | None,
) -> tuple[str, ...]:
    reasons: set[str] = set()
    if (
        result.terminal_close_taker_fee_rate
        != EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS.taker_fee_rate
        or result.terminal_close_slippage_bps
        != EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS.slippage_bps
    ):
        reasons.add("terminal_close_assumption_mismatch")
    if result.integrity_passed is not True:
        reasons.add("integrity_failure")
    liquidation_pnl = result.liquidation_adjusted_net_pnl
    if liquidation_pnl is None:
        reasons.add("liquidation_unavailable")
    elif type(liquidation_pnl) is not Decimal or not liquidation_pnl.is_finite():
        reasons.add("invalid_liquidation_adjusted_net_pnl")
    else:
        if config is not None and liquidation_pnl < 0:
            reasons.add("negative_liquidation_adjusted_net_pnl")
    if type(result.fill_count) is not int or result.fill_count < 0:
        reasons.add("invalid_fill_count")
    try:
        maker_fill_count = result.maker_fill_count
        taker_attempt_count = result.taker_attempt_count
        taker_execution_count = result.taker_execution_count
        if any(
            type(value) is not int or value < 0
            for value in (
                maker_fill_count,
                taker_attempt_count,
                taker_execution_count,
            )
        ):
            raise ValueError("invalid execution counts")
        if maker_fill_count + taker_execution_count != result.fill_count:
            reasons.add("execution_count_reconciliation_failure")
        expected_fill_rate = Decimal(maker_fill_count) / Decimal(
            result.quote_create_attempts or 1
        )
        if _require_decimal(result.fill_rate, "fill_rate") != expected_fill_rate:
            reasons.add("fill_rate_reconciliation_failure")
        expected_taker_rate = (
            Decimal(taker_execution_count) / Decimal(taker_attempt_count)
            if taker_attempt_count
            else Decimal("0")
        )
        if (
            _require_decimal(result.taker_execution_rate, "taker_execution_rate")
            != expected_taker_rate
        ):
            reasons.add("taker_execution_rate_reconciliation_failure")
    except (ArithmeticError, AttributeError, ValueError):
        reasons.add("execution_count_reconciliation_failure")

    try:
        with localcontext(_DECIMAL_CONTEXT):
            reconciled_net = (
                _require_decimal(result.realized_pnl, "realized_pnl")
                + _require_decimal(result.unrealized_pnl, "unrealized_pnl")
                - _require_decimal(result.maker_fees, "maker_fees")
                - _require_decimal(result.taker_fees, "taker_fees")
                + _require_decimal(result.funding_pnl, "funding_pnl")
            )
            if reconciled_net != _require_decimal(result.net_pnl, "net_pnl"):
                reasons.add("pnl_reconciliation_failure")
            liquidation_cost = result.liquidation_cost
            if liquidation_pnl is not None:
                if liquidation_cost is None or (
                    result.net_pnl - _require_decimal(liquidation_cost, "liquidation_cost")
                    != liquidation_pnl
                ):
                    reasons.add("liquidation_reconciliation_failure")
    except (ArithmeticError, ValueError):
        reasons.add("pnl_reconciliation_failure")

    if config is not None:
        if any(
            key.startswith("baseline_") and value > 0
            for key, value in result.constraint_rejections.items()
        ):
            reasons.add("baseline_rule_constraint")
        required_lanes = {
            "baseline_maker",
            "aggressive_maker",
            "aggressive_taker",
        }
        try:
            lane_metrics = result.lane_metrics
            if set(lane_metrics) != required_lanes:
                reasons.add("lane_reconciliation_missing_lanes")
            else:
                with localcontext(_DECIMAL_CONTEXT):
                    if (
                        sum(
                            item.quote_create_attempts
                            for item in lane_metrics.values()
                        )
                        != result.quote_create_attempts
                    ):
                        reasons.add("lane_reconciliation_quote_create_attempts")
                    if sum(item.fill_count for item in lane_metrics.values()) != result.fill_count:
                        reasons.add("lane_reconciliation_fill_count")
                    if (
                        sum(item.maker_fill_count for item in lane_metrics.values())
                        != result.maker_fill_count
                    ):
                        reasons.add("lane_reconciliation_maker_fill_count")
                    if (
                        sum(item.taker_attempt_count for item in lane_metrics.values())
                        != result.taker_attempt_count
                    ):
                        reasons.add("lane_reconciliation_taker_attempt_count")
                    if (
                        sum(item.taker_execution_count for item in lane_metrics.values())
                        != result.taker_execution_count
                    ):
                        reasons.add("lane_reconciliation_taker_execution_count")
                    for lane, item in lane_metrics.items():
                        if (
                            item.maker_fill_count + item.taker_execution_count
                            != item.fill_count
                        ):
                            reasons.add("lane_reconciliation_execution_count")
                        expected_maker_rate = Decimal(item.maker_fill_count) / Decimal(
                            item.quote_create_attempts or 1
                        )
                        if item.maker_fill_rate != expected_maker_rate:
                            reasons.add("lane_reconciliation_maker_fill_rate")
                        expected_taker_rate = (
                            Decimal(item.taker_execution_count)
                            / Decimal(item.taker_attempt_count)
                            if item.taker_attempt_count
                            else Decimal("0")
                        )
                        if item.taker_execution_rate != expected_taker_rate:
                            reasons.add("lane_reconciliation_taker_execution_rate")
                    decimal_fields = (
                        "maker_fees",
                        "taker_fees",
                        "realized_pnl",
                        "signed_terminal_inventory_base",
                        "terminal_inventory_quote",
                        "funding_pnl",
                        "unrealized_pnl",
                        "net_pnl",
                    )
                    for field_name in decimal_fields:
                        lane_total = sum(
                            (
                                _require_decimal(
                                    getattr(item, field_name),
                                    f"lane {field_name}",
                                )
                                for item in lane_metrics.values()
                            ),
                            Decimal("0"),
                        )
                        if lane_total != _require_decimal(
                            getattr(result, field_name), field_name
                        ):
                            reasons.add(f"lane_reconciliation_{field_name}")
                    optional_fields = (
                        "liquidation_cost",
                        "liquidation_adjusted_net_pnl",
                    )
                    for field_name in optional_fields:
                        combined = getattr(result, field_name)
                        lane_values = tuple(
                            getattr(item, field_name) for item in lane_metrics.values()
                        )
                        if combined is None:
                            if any(value is not None for value in lane_values):
                                reasons.add(f"lane_reconciliation_{field_name}")
                        elif any(value is None for value in lane_values) or sum(
                            (
                                _require_decimal(value, f"lane {field_name}")
                                for value in lane_values
                            ),
                            Decimal("0"),
                        ) != _require_decimal(combined, field_name):
                            reasons.add(f"lane_reconciliation_{field_name}")
                    for item in lane_metrics.values():
                        if item.terminal_inventory_quote != item.unrealized_pnl:
                            reasons.add("lane_reconciliation_lane_formula")
                        expected_net = (
                            item.realized_pnl
                            + item.unrealized_pnl
                            - item.maker_fees
                            - item.taker_fees
                            + item.funding_pnl
                        )
                        if expected_net != item.net_pnl:
                            reasons.add("lane_reconciliation_lane_formula")
                        if (
                            item.liquidation_cost is not None
                            and item.liquidation_adjusted_net_pnl
                            != item.net_pnl - item.liquidation_cost
                        ):
                            reasons.add("lane_reconciliation_lane_formula")
        except (ArithmeticError, AttributeError, TypeError, ValueError):
            reasons.add("lane_reconciliation_malformed")
        try:
            if _require_decimal(result.taker_fee_spent, "taker_fee_spent") > config.daily_taker_fee_budget:
                reasons.add("taker_budget_exceeded")
        except ValueError:
            reasons.add("invalid_taker_fee_spent")

    ledger = result.ledger
    if ledger.path is not None:
        try:
            digest = sha256()
            row_count = 0
            with ledger.path.open("rb") as handle:
                for line in handle:
                    digest.update(line)
                    row_count += 1
            if ledger.sha256 != digest.hexdigest() or ledger.row_count != row_count:
                reasons.add("determinism_failure")
        except OSError:
            reasons.add("determinism_failure")
    elif ledger.row_count != len(ledger.rows):
        reasons.add("determinism_failure")
    return tuple(sorted(reasons))


def _aggregate_runs(
    candidate_hash: str,
    config: AggressiveConfig | None,
    runs: Sequence[_ReplayRun],
) -> _Aggregate:
    ordered = tuple(sorted(runs, key=lambda item: item.day.date))
    reasons = {
        reason
        for run in ordered
        for reason in _result_reasons(run.result, config)
    }
    reasons.update(
        reason for run in ordered for reason in run.validation_reasons
    )
    pnl_values = tuple(run.result.liquidation_adjusted_net_pnl for run in ordered)
    if any(type(value) is not Decimal or not value.is_finite() for value in pnl_values):
        aggregate_pnl = None
    else:
        with localcontext(_DECIMAL_CONTEXT):
            aggregate_pnl = sum(
                (_require_decimal(value, "liquidation_adjusted_net_pnl") for value in pnl_values),
                Decimal("0"),
            )
    summary = CandidateSummary(
        candidate_hash=candidate_hash,
        eligible_fill_count=sum(
            run.result.fill_count
            for run in ordered
            if type(run.result.fill_count) is int and run.result.fill_count >= 0
        ),
        liquidation_adjusted_net_pnl=aggregate_pnl,
        validity_reasons=tuple(sorted(reasons)),
    )
    return _Aggregate(candidate_hash, config, summary, ordered)


def _run_replays(
    *,
    stage: str,
    days: Sequence[ExperimentDay],
    candidates: Sequence[ExperimentCandidate],
    model: object,
    baseline_profile: object,
    ledger_dir: Path,
    workers: int,
    include_baseline: bool = True,
) -> tuple[_ReplayRun, ...]:
    requests: list[tuple[ExperimentDay, ExperimentCandidate | None]] = []
    for day in days:
        if include_baseline:
            requests.append((day, None))
        requests.extend((day, candidate) for candidate in candidates)

    def execute(request: tuple[ExperimentDay, ExperimentCandidate | None]) -> _ReplayRun:
        day, candidate = request
        candidate_hash = "baseline" if candidate is None else candidate.candidate_hash
        options = (
            None
            if candidate is None
            else AggressiveReplayOptions(candidate.config, model, day.rule_book)
        )
        ledger_path = ledger_dir / f"{stage}-{day.date.isoformat()}-{candidate_hash}.jsonl"
        result = run_profile(
            day.bundle,
            baseline_profile,
            Decimal("400"),
            ledger_sink=ledger_path,
            aggressive_options=options,
            terminal_close_assumptions=EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS,
        )
        return _ReplayRun(
            stage=stage,
            day=day,
            candidate_hash=candidate_hash,
            config=None if candidate is None else candidate.config,
            result=result,
        )

    if workers == 1 or len(requests) <= 1:
        return tuple(execute(request) for request in requests)
    with ThreadPoolExecutor(max_workers=min(workers, len(requests))) as executor:
        # executor.map preserves request order regardless of completion order.
        return tuple(executor.map(execute, requests))


def _canonical_replay_result(result: ProfileReplayResult) -> str:
    values = {
        name: value
        for name, value in vars(result).items()
        if name not in {"profile", "ledger"}
    }
    return canonical_sha256(values)


def _canonical_ledger_bytes(result: ProfileReplayResult) -> bytes:
    ledger = result.ledger
    if ledger.path is not None:
        return ledger.path.read_bytes()
    return b"".join(
        (decimal_json(row) + "\n").encode("utf-8")
        for row in ledger.rows
    )


def _compare_reproductions(
    primary: Sequence[_ReplayRun],
    reproduced: Sequence[_ReplayRun],
) -> tuple[_ReplayRun, ...]:
    reproduced_by_key = {
        (run.day.date, run.candidate_hash): run for run in reproduced
    }
    reproduced_hashes = {run.candidate_hash for run in reproduced}
    compared: list[_ReplayRun] = []
    for run in primary:
        if (
            run.candidate_hash == "baseline"
            or run.candidate_hash not in reproduced_hashes
        ):
            compared.append(run)
            continue
        duplicate = reproduced_by_key.get((run.day.date, run.candidate_hash))
        mismatch = bool(
            duplicate is None
            or _canonical_replay_result(run.result)
            != _canonical_replay_result(duplicate.result)
            or _canonical_ledger_bytes(run.result)
            != _canonical_ledger_bytes(duplicate.result)
        )
        compared.append(
            replace(
                run,
                validation_reasons=("determinism_failure",) if mismatch else (),
            )
        )
    return tuple(compared)


def _merge_aggregate_reasons(
    aggregate: _Aggregate,
    extra_reasons: Sequence[str],
) -> _Aggregate:
    reasons = tuple(sorted(set(aggregate.summary.validity_reasons) | set(extra_reasons)))
    return replace(
        aggregate,
        summary=replace(aggregate.summary, validity_reasons=reasons),
    )


def _aggregate_stage(
    runs: Sequence[_ReplayRun],
    candidates: Sequence[ExperimentCandidate],
) -> tuple[_Aggregate, tuple[_Aggregate, ...]]:
    baseline = _aggregate_runs(
        "baseline",
        None,
        tuple(run for run in runs if run.candidate_hash == "baseline"),
    )
    if baseline.summary.validity_reasons or baseline.summary.liquidation_adjusted_net_pnl is None:
        raise DataIntegrityError(
            "baseline experiment results are invalid: "
            + ", ".join(baseline.summary.validity_reasons)
        )
    aggregates = tuple(
        _aggregate_runs(
            candidate.candidate_hash,
            candidate.config,
            tuple(run for run in runs if run.candidate_hash == candidate.candidate_hash),
        )
        for candidate in candidates
    )
    return baseline, aggregates


def _summary_payload(summary: CandidateSummary) -> dict[str, object]:
    return {
        "candidate_hash": summary.candidate_hash,
        "eligible_fill_count": summary.eligible_fill_count,
        "liquidation_adjusted_net_pnl": summary.liquidation_adjusted_net_pnl,
        "validity_reasons": summary.validity_reasons,
        "is_valid": summary.is_valid,
    }


def _run_diagnostic_payload(run: _ReplayRun) -> dict[str, object]:
    result = run.result
    return {
        "date": run.day.date,
        "manifest_hash": run.day.manifest_hash,
        "fill_count": result.fill_count,
        "integrity_passed": result.integrity_passed,
        "liquidation_adjusted_net_pnl": result.liquidation_adjusted_net_pnl,
        "signed_terminal_inventory_base": result.signed_terminal_inventory_base,
        "terminal_inventory_quote": result.terminal_inventory_quote,
        "max_drawdown": result.max_drawdown,
        "lane_metrics": {
            lane: vars(metrics)
            for lane, metrics in sorted(result.lane_metrics.items())
        },
        "validation_reasons": run.validation_reasons,
    }


def _aggregate_payload(aggregate: _Aggregate) -> dict[str, object]:
    return {
        **_summary_payload(aggregate.summary),
        "config": (
            _config_payload(aggregate.config)
            if aggregate.config is not None
            else None
        ),
        "days": [_run_diagnostic_payload(run) for run in aggregate.runs],
    }


def _representative_payload(result: ParetoResult) -> dict[str, str | None]:
    return {
        "return_point": (
            result.return_point.candidate_hash if result.return_point is not None else None
        ),
        "balanced_point": (
            result.balanced_point.candidate_hash if result.balanced_point is not None else None
        ),
        "throughput_point": (
            result.throughput_point.candidate_hash
            if result.throughput_point is not None
            else None
        ),
    }


def _stage_payload(
    baseline: _Aggregate,
    aggregates: Sequence[_Aggregate],
    pareto: ParetoResult,
) -> dict[str, object]:
    return {
        "baseline": _aggregate_payload(baseline),
        "candidates": [_aggregate_payload(item) for item in aggregates],
        "frontier": [_summary_payload(item) for item in pareto.frontier],
        "representatives": _representative_payload(pareto),
        "completion_passed": pareto.completion_passed,
    }


def _candidate_completes_holdout(
    candidate: CandidateSummary,
    baseline: CandidateSummary,
) -> bool:
    baseline_pnl = baseline.liquidation_adjusted_net_pnl
    candidate_pnl = candidate.liquidation_adjusted_net_pnl
    assert baseline_pnl is not None
    return bool(
        candidate.is_valid
        and candidate.eligible_fill_count >= 3 * baseline.eligible_fill_count
        and candidate_pnl is not None
        and candidate_pnl >= baseline_pnl
    )


def _holdout_payload(
    baseline: _Aggregate,
    aggregates: Sequence[_Aggregate],
    development_roles: Mapping[str, str | None],
) -> dict[str, object]:
    by_hash = {item.candidate_hash: item for item in aggregates}
    roles_by_hash: dict[str, list[str]] = {}
    for role, candidate_hash in development_roles.items():
        if candidate_hash is not None:
            roles_by_hash.setdefault(candidate_hash, []).append(role)
    completion_by_hash = {
        candidate_hash: _candidate_completes_holdout(
            aggregate.summary, baseline.summary
        )
        for candidate_hash, aggregate in sorted(by_hash.items())
    }
    measurements_by_hash = {
        candidate_hash: {
            **_aggregate_payload(aggregate),
            "frozen_roles": tuple(sorted(roles_by_hash.get(candidate_hash, ()))),
            "completion_passed": completion_by_hash[candidate_hash],
        }
        for candidate_hash, aggregate in sorted(by_hash.items())
    }
    measurements_by_role = {
        role: {
            **_aggregate_payload(by_hash[candidate_hash]),
            "frozen_role": role,
            "completion_passed": completion_by_hash[candidate_hash],
        }
        for role, candidate_hash in development_roles.items()
        if candidate_hash is not None
    }
    return {
        "baseline": _aggregate_payload(baseline),
        "measurements_by_hash": measurements_by_hash,
        "measurements_by_role": measurements_by_role,
        "completion_by_hash": completion_by_hash,
        "completion_passed": any(completion_by_hash.values()),
    }


def _atomic_write(path: Path, body: bytes) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    with temporary.open("wb") as handle:
        handle.write(body)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def _artifact_json(payload: Mapping[str, object]) -> bytes:
    return (decimal_json(payload) + "\n").encode("utf-8")


def _ledger_row_payload(row: object) -> dict[str, object]:
    fields = (
        "event_type",
        "event_time_ms",
        "sequence",
        "side",
        "level_id",
        "price",
        "quantity",
        "tag",
        "queue_ahead",
        "remaining_quantity",
        "reason",
        "lane",
    )
    return {name: getattr(row, name) for name in fields}


def _write_ledger(
    path: Path,
    runs: Sequence[_ReplayRun],
    frozen_hashes: tuple[str, ...],
) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        for run in sorted(
            runs,
            key=lambda item: (item.stage, item.day.date, item.candidate_hash),
        ):
            metadata = {
                **_AUTHORIZATION,
                "stage": run.stage,
                "date": run.day.date,
                "manifest_hash": run.day.manifest_hash,
                "candidate_hash": run.candidate_hash,
                "selected_frozen_representative": run.candidate_hash in frozen_hashes,
            }
            handle.write(decimal_json({**metadata, "record_type": "day_start"}) + "\n")
            for row in run.result.ledger.iter_rows():
                handle.write(
                    decimal_json(
                        {
                            **metadata,
                            "record_type": "replay_event",
                            "event": _ledger_row_payload(row),
                        }
                    )
                    + "\n"
                )
            handle.write(decimal_json({**metadata, "record_type": "day_end"}) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def _publish_artifacts(
    *,
    split: ExperimentSplit,
    candidates: tuple[ExperimentCandidate, ...],
    model: object,
    development_baseline: _Aggregate,
    development_aggregates: tuple[_Aggregate, ...],
    development_pareto: ParetoResult,
    holdout_baseline: _Aggregate,
    holdout_aggregates: tuple[_Aggregate, ...],
    development_roles: Mapping[str, str | None],
    frozen: tuple[ExperimentCandidate, ...],
    all_runs: tuple[_ReplayRun, ...],
    development_reproduction_count: int,
    holdout_reproduction_count: int,
    staging: Path,
) -> tuple[str, str, int, int]:
    model_payload = model.canonical_payload()
    signal_model_hash = canonical_sha256(model_payload)
    frozen_hashes = tuple(item.candidate_hash for item in frozen)
    operation_counts = orchestration_operation_counts(
        len(candidates),
        len(frozen),
        development_reproduced_candidate_count=(
            development_reproduction_count // len(split.development)
        ),
    )
    published_ledger_row_count = (
        sum(run.result.ledger.row_count for run in all_runs)
        + 2 * len(all_runs)
    )
    holdout_payload = _holdout_payload(
        holdout_baseline,
        holdout_aggregates,
        development_roles,
    )
    split_payload = {
        "development": [
            {"date": item.date, "manifest_hash": item.manifest_hash}
            for item in split.development
        ],
        "holdout": [
            {"date": item.date, "manifest_hash": item.manifest_hash}
            for item in split.holdout
        ],
    }
    pareto_payload: dict[str, object] = {
        **_AUTHORIZATION,
        "terminal_close_assumptions": (
            EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS.canonical_payload()
        ),
        "development": _stage_payload(
            development_baseline, development_aggregates, development_pareto
        ),
        "holdout": holdout_payload,
        "frozen_candidate_hashes": frozen_hashes,
        "frozen_configs": [
            {
                "candidate_hash": item.candidate_hash,
                "config": _config_payload(item.config),
            }
            for item in frozen
        ],
    }
    signal_payload = {
        **_AUTHORIZATION,
        "signal_model_hash": signal_model_hash,
        "model": model_payload,
    }
    core_result: dict[str, object] = {
        **_AUTHORIZATION,
        "terminal_close_assumptions": (
            EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS.canonical_payload()
        ),
        "split": split_payload,
        "grid_hash": canonical_sha256(
            [
                {"candidate_hash": item.candidate_hash, "config": _config_payload(item.config)}
                for item in candidates
            ]
        ),
        "signal_model_hash": signal_model_hash,
        "frozen_candidate_hashes": frozen_hashes,
        "development": _stage_payload(
            development_baseline, development_aggregates, development_pareto
        ),
        "holdout": holdout_payload,
        "completion_passed": holdout_payload["completion_passed"],
    }
    canonical_hash = canonical_sha256(core_result)
    result_payload = {**core_result, "canonical_hash": canonical_hash}
    invalid_results = [
        _summary_payload(item.summary)
        for item in (*development_aggregates, *holdout_aggregates)
        if item.summary.validity_reasons
    ]
    validation_payload = {
        **_AUTHORIZATION,
        "terminal_close_assumptions": (
            EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS.canonical_payload()
        ),
        "canonical_hash": canonical_hash,
        "signal_model_hash": signal_model_hash,
        "split_valid": True,
        "development_model_fit_count": 1,
        "holdout_label_collection_count": 0,
        "holdout_refit_count": 0,
        "holdout_retune_count": 0,
        "development_selected_reproduction_count": development_reproduction_count,
        "holdout_frozen_reproduction_count": holdout_reproduction_count,
        "orchestration": {
            "operation_counts": operation_counts,
            "published_ledger_row_count": published_ledger_row_count,
        },
        "frozen_candidate_hashes": frozen_hashes,
        "invalid_results": invalid_results,
        "completion_passed": holdout_payload["completion_passed"],
    }

    _atomic_write(staging / "pareto.json", _artifact_json(pareto_payload))
    _atomic_write(staging / "signal_model.json", _artifact_json(signal_payload))
    _atomic_write(staging / "result.json", _artifact_json(result_payload))
    _atomic_write(staging / "validation.json", _artifact_json(validation_payload))
    _write_ledger(staging / "ledger.jsonl", all_runs, frozen_hashes)
    report = build_experiment_report(result_payload, pareto_payload)
    _atomic_write(staging / "report.md", report.encode("utf-8"))
    return canonical_hash, signal_model_hash, operation_counts["total"], published_ledger_row_count


def run_pareto_experiment(
    development_manifests: Sequence[str | Path],
    holdout_manifests: Sequence[str | Path],
    grid: Mapping[str, object],
    output_dir: str | Path,
    *,
    workers: int = 1,
) -> ExperimentArtifactSet:
    """Fit once on development, freeze representatives, and evaluate holdout once."""

    if type(workers) is not int or workers <= 0:
        raise ValueError("workers must be a positive integer")
    destination = Path(output_dir).resolve()
    if destination.exists() and (
        not destination.is_dir() or any(destination.iterdir())
    ):
        raise ValueError("output directory must be empty")

    split = validate_experiment_split(development_manifests, holdout_manifests)
    candidates = expand_experiment_grid(grid)
    observations = collect_calibration_observations(
        tuple(item.bundle for item in split.development)
    )
    model = fit_quantile_signal_model(observations, quantiles=5)
    repo_root = Path(__file__).resolve().parents[2]
    baseline_profile = load_profiles(repo_root).primary[BASELINE_NAME]

    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.staging-", dir=destination.parent)
    )
    try:
        ledger_dir = staging / ".replay-ledgers"
        ledger_dir.mkdir()
        development_runs = _run_replays(
            stage="development",
            days=split.development,
            candidates=candidates,
            model=model,
            baseline_profile=baseline_profile,
            ledger_dir=ledger_dir,
            workers=workers,
        )
        candidate_by_hash = {item.candidate_hash: item for item in candidates}
        verified_hashes: set[str] = set()
        development_reproductions: list[_ReplayRun] = []
        for _ in range(len(candidates) + 1):
            development_baseline, development_aggregates = _aggregate_stage(
                development_runs, candidates
            )
            development_pareto = select_pareto(
                (item.summary for item in development_aggregates),
                development_baseline.summary,
            )
            development_roles = _representative_payload(development_pareto)
            representative_hashes = tuple(
                sorted(
                    {
                        item.candidate_hash
                        for item in (
                            development_pareto.return_point,
                            development_pareto.balanced_point,
                            development_pareto.throughput_point,
                        )
                        if item is not None
                    }
                )
            )
            pending_hashes = tuple(
                value
                for value in representative_hashes
                if value not in verified_hashes
            )
            if not pending_hashes:
                break
            pending = tuple(candidate_by_hash[value] for value in pending_hashes)
            reproduced = _run_replays(
                stage="development_reproduction",
                days=split.development,
                candidates=pending,
                model=model,
                baseline_profile=baseline_profile,
                ledger_dir=ledger_dir,
                workers=workers,
                include_baseline=False,
            )
            development_reproductions.extend(reproduced)
            development_runs = _compare_reproductions(
                development_runs,
                reproduced,
            )
            verified_hashes.update(pending_hashes)
        else:  # pragma: no cover - the candidate-count bound is an invariant.
            raise DataIntegrityError(
                "development reproduction selection did not converge"
            )
        frozen = tuple(candidate_by_hash[value] for value in representative_hashes)
        holdout_runs = _run_replays(
            stage="holdout",
            days=split.holdout,
            candidates=frozen,
            model=model,
            baseline_profile=baseline_profile,
            ledger_dir=ledger_dir,
            workers=workers,
        )
        holdout_reproductions = _run_replays(
            stage="holdout_reproduction",
            days=split.holdout,
            candidates=frozen,
            model=model,
            baseline_profile=baseline_profile,
            ledger_dir=ledger_dir,
            workers=workers,
            include_baseline=False,
        )
        holdout_runs = _compare_reproductions(holdout_runs, holdout_reproductions)
        holdout_baseline, holdout_aggregates = _aggregate_stage(holdout_runs, frozen)
        development_reasons = {
            item.candidate_hash: tuple(
                reason
                for reason in item.summary.validity_reasons
                if reason == "determinism_failure"
            )
            for item in development_aggregates
        }
        holdout_aggregates = tuple(
            _merge_aggregate_reasons(
                item,
                development_reasons.get(item.candidate_hash, ()),
            )
            for item in holdout_aggregates
        )
        (
            canonical_hash,
            signal_model_hash,
            replay_execution_count,
            published_ledger_row_count,
        ) = _publish_artifacts(
            split=split,
            candidates=candidates,
            model=model,
            development_baseline=development_baseline,
            development_aggregates=development_aggregates,
            development_pareto=development_pareto,
            holdout_baseline=holdout_baseline,
            holdout_aggregates=holdout_aggregates,
            development_roles=development_roles,
            frozen=frozen,
            all_runs=(*development_runs, *holdout_runs),
            development_reproduction_count=len(development_reproductions),
            holdout_reproduction_count=len(holdout_reproductions),
            staging=staging,
        )
        shutil.rmtree(ledger_dir)
        artifact_hashes = {
            name: sha256((staging / name).read_bytes()).hexdigest()
            for name in _ARTIFACT_NAMES
        }
        if destination.exists():
            destination.rmdir()
        staging.replace(destination)
        return ExperimentArtifactSet(
            output_dir=destination,
            canonical_hash=canonical_hash,
            signal_model_hash=signal_model_hash,
            frozen_candidate_hashes=representative_hashes,
            artifact_hashes=artifact_hashes,
            replay_execution_count=replay_execution_count,
            published_ledger_row_count=published_ledger_row_count,
        )
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise


__all__ = [
    "ExperimentCandidate",
    "ExperimentArtifactSet",
    "ExperimentDay",
    "ExperimentSplit",
    "EXPERIMENT_TERMINAL_CLOSE_ASSUMPTIONS",
    "MAX_GRID_CANDIDATES",
    "expand_experiment_grid",
    "load_experiment_grid",
    "orchestration_operation_counts",
    "run_pareto_experiment",
    "validate_experiment_split",
]
