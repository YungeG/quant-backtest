from __future__ import annotations

from dataclasses import dataclass, field
from dataclasses import fields, is_dataclass
from collections.abc import Callable, Iterator, Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING
from datetime import date
from decimal import Decimal
from pathlib import Path
import re
import hashlib
import json
from typing import Any

from ..microstructure.events import TradePrint


@dataclass(frozen=True)
class DateWindow:
    start_date: date
    end_date: date


class DataIntegrityError(ValueError):
    pass


@dataclass(frozen=True)
class ArchiveRef:
    kind: str
    date: date
    url: str
    checksum_url: str
    raw_path: str
    sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "sha256", _validate_sha256(self.sha256))


@dataclass(frozen=True)
class BookTicker:
    update_id: int
    event_time_ms: int
    transaction_time_ms: int
    bid_price: Decimal
    bid_quantity: Decimal
    ask_price: Decimal
    ask_quantity: Decimal


@dataclass(frozen=True)
class FundingRate:
    funding_time_ms: int
    funding_rate: Decimal


@dataclass(frozen=True)
class ManifestFile:
    kind: str
    date: date
    path: str
    sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "sha256", _validate_sha256(self.sha256))


@dataclass(frozen=True)
class MarketManifest:
    symbol: str
    window: DateWindow
    files: tuple[ManifestFile, ...] = ()
    exact_duplicates: Mapping[str, int] | None = None
    max_book_age_ms: int = 5_000
    max_joint_silence_ms: int = 60_000
    grade: str = "engineering_replay"
    authorization: Mapping[str, bool] | None = None
    coverage: Mapping[str, int] | None = None
    funding_bounds: Mapping[str, int] | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "exact_duplicates", _freeze_mapping(self.exact_duplicates))
        object.__setattr__(self, "authorization", _freeze_mapping(self.authorization))
        object.__setattr__(self, "coverage", _freeze_mapping(self.coverage))
        object.__setattr__(self, "funding_bounds", _freeze_mapping(self.funding_bounds))


def _freeze_mapping(source: Mapping[str, object] | None) -> Mapping[str, object]:
    return MappingProxyType(dict(source or {}))


@dataclass(frozen=True)
class VerifiedBundle:
    manifest: MarketManifest
    book_tickers: tuple[BookTicker, ...]
    agg_trades: tuple[TradePrint, ...]
    funding: tuple[FundingRate, ...]
    book_path: Path
    trade_path: Path
    funding_path: Path
    schema_version: int = 1
    book_ticker_factory: Callable[[], Iterator[BookTicker]] | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    agg_trade_factory: Callable[[], Iterator[TradePrint]] | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    funding_factory: Callable[[], Iterator[FundingRate]] | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    exchange_rule_paths: tuple[Path, ...] = ()

    @property
    def normalized_funding(self) -> tuple[FundingRate, ...]:
        return self.funding

    def iter_book_tickers(self) -> Iterator[BookTicker]:
        if self.book_ticker_factory is not None:
            return self.book_ticker_factory()
        return iter(self.book_tickers)

    def iter_agg_trades(self) -> Iterator[TradePrint]:
        if self.agg_trade_factory is not None:
            return self.agg_trade_factory()
        return iter(self.agg_trades)

    def iter_funding(self) -> Iterator[FundingRate]:
        if self.funding_factory is not None:
            return self.funding_factory()
        return iter(self.funding)


@dataclass(frozen=True)
class DownloadReceipt:
    kind: str
    date: date
    url: str
    raw_path: str
    checksum_path: str
    expected_sha256: str
    actual_sha256: str
    byte_count: int


@dataclass(frozen=True)
class FundingPageReceipt:
    request_start_ms: int
    request_end_ms: int
    request_limit: int
    request_params: tuple[tuple[str, object], ...]
    request_params_sha256: str
    response_path: str
    receipt_path: str
    response_sha256: str
    response_count: int
    last_funding_time_ms: int

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "request_params_sha256",
            _validate_sha256(self.request_params_sha256),
        )
        object.__setattr__(
            self,
            "response_sha256",
            _validate_sha256(self.response_sha256),
        )


@dataclass(frozen=True)
class RawBundleReceipt:
    window: DateWindow
    archive_downloads: tuple[DownloadReceipt, ...]
    funding_pages: tuple[FundingPageReceipt, ...]


def decimal_json(value: object) -> str:
    return json.dumps(_to_jsonable(value), sort_keys=True, separators=(",", ":"))


def canonical_sha256(value: object) -> str:
    return hashlib.sha256(decimal_json(value).encode("utf-8")).hexdigest()


def _to_jsonable(value: object) -> Any:
    if isinstance(value, float):
        raise TypeError("float values are not allowed")
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, date):
        return value.isoformat()
    if is_dataclass(value):
        return {field.name: _to_jsonable(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise TypeError("dict keys must be strings")
        return {
            key: _to_jsonable(item)
            for key, item in sorted(value.items(), key=lambda item: str(item[0]))
        }
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    raise TypeError(f"unsupported type: {type(value).__name__}")


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _validate_sha256(value: str) -> str:
    if not isinstance(value, str) or not _SHA256_RE.fullmatch(value):
        raise ValueError("sha256 must be 64 lowercase hexadecimal characters")
    return value
