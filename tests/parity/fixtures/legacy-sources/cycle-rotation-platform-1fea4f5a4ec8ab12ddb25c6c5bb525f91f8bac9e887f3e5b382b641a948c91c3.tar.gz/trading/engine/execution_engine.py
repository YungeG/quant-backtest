from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

from trading.adapters.paper_broker import PaperBroker
from trading.engine.daily_report import render_daily_report_markdown
from trading.engine.order_manager import OrderManager
from trading.engine.reconciliation import build_reconciliation_summary
from trading.engine.risk_gate import RiskGate, RiskGateConfig
from trading.orders import PlannedOrder
from trading.signal_order_planner import plan_orders_from_signal_with_diagnostics
from trading.state.repository import SqliteStateRepository


@dataclass
class ExecutionRuntimeConfig:
    initial_cash: float = 1_000_000.0
    max_position_pct: float = 0.1
    lot_size: int = 100
    position_management_mode: str = "current_budgeted_next_open"
    position_management: dict = field(default_factory=dict)
    exit_policy: dict = field(default_factory=dict)
    max_total_position_ratio: float = 0.95
    max_single_position_ratio: float = 0.2
    max_daily_loss_ratio: float = 0.05
    min_fill_rate_warn: Optional[float] = None
    blacklist_symbols: List[str] = field(default_factory=list)
    require_manual_approval: bool = False
    approval_flag_file: Optional[str] = None
    kill_switch_file: Optional[str] = None
    max_retry_attempts: int = 0
    retryable_reject_reasons: List[str] = field(
        default_factory=lambda: ["temporary_broker_unavailable", "temporary_market_data_unavailable"]
    )
    auto_switch_to_cautious_on_retry_exhausted: bool = False
    auto_switch_retry_exhausted_streak_threshold: int = 1
    cautious_approval_flag_file: Optional[str] = "/tmp/quant_approval.flag"


class ExecutionEngine:
    def __init__(
        self,
        config: ExecutionRuntimeConfig,
        broker_factory: Callable[[SqliteStateRepository], PaperBroker] | None = None,
    ):
        self.config = config
        self.order_manager = OrderManager()
        self.risk_gate = RiskGate(
            RiskGateConfig(
                max_total_position_ratio=self.config.max_total_position_ratio,
                max_single_position_ratio=self.config.max_single_position_ratio,
                max_daily_loss_ratio=self.config.max_daily_loss_ratio,
                blacklist_symbols={str(s).zfill(6) for s in self.config.blacklist_symbols},
            )
        )
        self.broker_factory = broker_factory or PaperBroker
        self.retryable_reject_reasons = {
            str(r).strip().lower()
            for r in self.config.retryable_reject_reasons
            if str(r).strip()
        }

    def execute_from_signal(
        self,
        signal_path: str,
        state_db_path: str,
        report_path: str,
        daily_report_path: str | None = None,
        runtime_config_path: str | None = None,
    ) -> dict:
        signal_payload = json.loads(Path(signal_path).read_text(encoding="utf-8"))
        signal_date = str(signal_payload.get("signal_date") or datetime.now().date())

        abort_reason = self._check_runtime_guards()
        if abort_reason:
            summary = self._build_abort_summary(
                signal_date=signal_date,
                signal_path=signal_path,
                state_db_path=state_db_path,
                abort_reason=abort_reason,
            )
            self._write_outputs(summary, report_path, daily_report_path)
            return summary

        top_n = signal_payload.get("top_n")

        repo = SqliteStateRepository(state_db_path)
        repo.initialize()
        if repo.get_cash() <= 0 and self.config.initial_cash > 0:
            repo.set_cash(self.config.initial_cash)

        current_positions = repo.get_positions()
        position_metadata = repo.get_position_metadata()
        cash = repo.get_cash()

        price_by_symbol = self._build_price_map(signal_payload, top_n)
        planned_orders, planning = plan_orders_from_signal_with_diagnostics(
            signal_payload=signal_payload,
            current_positions=current_positions,
            cash_available=cash,
            max_position_pct=self.config.max_position_pct,
            lot_size=self.config.lot_size,
            top_n=top_n,
            price_by_symbol=price_by_symbol,
            planning_config={
                "position_management_mode": self.config.position_management_mode,
                "position_management": dict(self.config.position_management or {}),
                "exit_policy": dict(self.config.exit_policy or {}),
            },
            position_metadata=position_metadata,
        )
        nav = cash + sum(
            int(shares) * float(price_by_symbol.get(str(symbol).zfill(6), 0.0) or 0.0)
            for symbol, shares in current_positions.items()
        )

        approved_orders, blocked_orders = self.risk_gate.precheck_orders(
            orders=planned_orders,
            price_by_symbol=price_by_symbol,
            cash=cash,
            positions=current_positions,
            nav=nav,
            daily_pnl=0.0,
        )

        intents = self.order_manager.build_order_intents(signal_date, approved_orders)

        broker = self.broker_factory(state_repo=repo)
        retried_order_ids: set[str] = set()
        retry_success_ids: set[str] = set()
        latest_fill_by_order_id: Dict[str, dict] = {}

        pending_intents = list(intents)
        attempt = 0
        attempt_history: List[dict] = []

        while True:
            for intent in pending_intents:
                self.order_manager.mark_sent(intent)
                self.order_manager.mark_ack(intent)

            attempt_fills = broker.execute_orders(
                orders=[
                    PlannedOrder(
                        symbol=i.symbol,
                        side=i.side,
                        shares=i.shares,
                        reason=i.reason,
                    )
                    for i in pending_intents
                ],
                price_by_symbol=price_by_symbol,
                trade_date=signal_date,
            )

            next_pending: List = []
            for intent, fill in zip(pending_intents, attempt_fills):
                fill_with_attempt = {
                    **fill,
                    "attempt": attempt,
                    "order_id": intent.order_id,
                }
                attempt_history.append(fill_with_attempt)
                latest_fill_by_order_id[intent.order_id] = fill_with_attempt
                self.order_manager.apply_execution_result(intent, fill_with_attempt)

                reject_reason = str(fill_with_attempt.get("reject_reason") or "").strip().lower()
                is_retryable = (
                    fill_with_attempt.get("status") == "REJECTED"
                    and reject_reason in self.retryable_reject_reasons
                )
                if is_retryable and attempt < int(self.config.max_retry_attempts):
                    retried_order_ids.add(intent.order_id)
                    next_pending.append(intent)
                elif intent.order_id in retried_order_ids and fill_with_attempt.get("status") == "FILLED":
                    retry_success_ids.add(intent.order_id)

            if not next_pending:
                break

            pending_intents = next_pending
            attempt += 1

        final_fills = [
            latest_fill_by_order_id[i.order_id]
            for i in intents
            if i.order_id in latest_fill_by_order_id
        ]

        blocked_as_results = [
            {
                "trade_date": signal_date,
                "symbol": b["symbol"],
                "side": b["side"],
                "shares": int(b["shares"]),
                "price": float(price_by_symbol.get(b["symbol"], 0.0) or 0.0),
                "notional": float(price_by_symbol.get(b["symbol"], 0.0) or 0.0)
                * int(b["shares"]),
                "reason": "risk_gate_blocked",
                "status": "REJECTED",
                "reject_reason": b["reason"],
                "attempt": 0,
                "order_id": None,
            }
            for b in blocked_orders
        ]

        combined_results = [*final_fills, *blocked_as_results]

        ending_positions = repo.get_positions()
        execution_target_symbols = planning.get("execution_target_symbols")
        if execution_target_symbols is None:
            execution_target_symbols = [
                str(row["symbol"]).zfill(6)
                for row in list(signal_payload.get("candidates", []))[: int(top_n) if top_n is not None else None]
            ]
        target_symbols = {
            str(symbol).zfill(6)
            for symbol in execution_target_symbols
        }
        reconciliation = build_reconciliation_summary(
            target_symbols=target_symbols,
            ending_positions=ending_positions,
            fills=combined_results,
        )

        fill_rate = (
            sum(1 for f in combined_results if f["status"] == "FILLED")
            / len(combined_results)
        ) if combined_results else 0.0

        lifecycle_counts = self.order_manager.summarize_lifecycle(intents)
        lifecycle_counts["REJECTED"] = lifecycle_counts.get("REJECTED", 0) + len(
            blocked_orders
        )

        warnings: List[str] = []
        if (
            self.config.min_fill_rate_warn is not None
            and fill_rate < float(self.config.min_fill_rate_warn)
        ):
            warnings.append("low_fill_rate")

        retry_failed_count = len(retried_order_ids - retry_success_ids)
        retry_exhausted = retry_failed_count > 0
        auto_actions = self._handle_retry_exhausted_protection(
            runtime_config_path=runtime_config_path,
            retry_exhausted=retry_exhausted,
        )
        if retry_exhausted:
            warnings.append("retry_exhausted")

        summary = {
            "status": "WARN" if warnings else "OK",
            "warnings": warnings,
            "abort_reason": None,
            "signal_date": signal_date,
            "signal_path": signal_path,
            "state_db_path": state_db_path,
            "orders_total": len(combined_results),
            "orders_filled": sum(1 for f in combined_results if f["status"] == "FILLED"),
            "orders_rejected": sum(
                1 for f in combined_results if f["status"] == "REJECTED"
            ),
            "orders_blocked_by_risk": len(blocked_orders),
            "lifecycle_counts": lifecycle_counts,
            "fill_rate": fill_rate,
            "ending_cash": repo.get_cash(),
            "ending_positions": ending_positions,
            "reconciliation": reconciliation,
            "recovery": {
                "retry_max_attempts": int(self.config.max_retry_attempts),
                "retry_attempts_used": max((r.get("attempt", 0) for r in attempt_history), default=0),
                "retried_orders": len(retried_order_ids),
                "retry_success_count": len(retry_success_ids),
                "retry_failed_count": retry_failed_count,
            },
            "auto_actions": auto_actions,
            "planning": planning,
            "orders": combined_results,
            "execution_attempts": attempt_history,
        }

        self._write_outputs(summary, report_path, daily_report_path)
        return summary

    def _check_runtime_guards(self) -> str | None:
        if self.config.kill_switch_file and Path(self.config.kill_switch_file).exists():
            return "kill_switch_triggered"

        if self.config.require_manual_approval:
            if not self.config.approval_flag_file:
                return "manual_approval_missing"
            if not Path(self.config.approval_flag_file).exists():
                return "manual_approval_missing"

        return None

    def _handle_retry_exhausted_protection(
        self,
        runtime_config_path: str | None,
        retry_exhausted: bool,
    ) -> dict:
        action = {
            "switched_to_cautious": False,
            "switch_reason": None,
            "runtime_config_path": runtime_config_path,
            "retry_exhausted_streak": 0,
            "streak_threshold": int(max(1, self.config.auto_switch_retry_exhausted_streak_threshold)),
        }
        if not runtime_config_path:
            action["switch_reason"] = "runtime_config_path_missing"
            return action

        cfg_path = Path(runtime_config_path)
        if not cfg_path.exists():
            action["switch_reason"] = "runtime_config_not_found"
            return action

        payload = json.loads(cfg_path.read_text(encoding="utf-8"))
        current_streak = int(payload.get("retry_exhausted_streak", 0) or 0)
        new_streak = current_streak + 1 if retry_exhausted else 0
        payload["retry_exhausted_streak"] = new_streak
        action["retry_exhausted_streak"] = new_streak

        threshold = int(max(1, self.config.auto_switch_retry_exhausted_streak_threshold))
        if retry_exhausted and self.config.auto_switch_to_cautious_on_retry_exhausted and new_streak >= threshold:
            payload["require_manual_approval"] = True
            payload["approval_flag_file"] = (
                self.config.cautious_approval_flag_file
                or payload.get("approval_flag_file")
                or "/tmp/quant_approval.flag"
            )
            action["switched_to_cautious"] = True
            action["switch_reason"] = "retry_exhausted"
        elif retry_exhausted and not self.config.auto_switch_to_cautious_on_retry_exhausted:
            action["switch_reason"] = "auto_switch_disabled"
        elif retry_exhausted:
            action["switch_reason"] = "streak_below_threshold"
        else:
            action["switch_reason"] = "no_retry_exhausted"

        cfg_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return action

    @staticmethod
    def _build_abort_summary(
        signal_date: str, signal_path: str, state_db_path: str, abort_reason: str
    ) -> dict:
        return {
            "status": "ABORTED",
            "abort_reason": abort_reason,
            "warnings": [],
            "signal_date": signal_date,
            "signal_path": signal_path,
            "state_db_path": state_db_path,
            "orders_total": 0,
            "orders_filled": 0,
            "orders_rejected": 0,
            "orders_blocked_by_risk": 0,
            "lifecycle_counts": {
                "NEW": 0,
                "SENT": 0,
                "ACK": 0,
                "PARTIAL": 0,
                "FILLED": 0,
                "REJECTED": 0,
                "CANCELED": 0,
            },
            "fill_rate": 0.0,
            "ending_cash": 0.0,
            "ending_positions": {},
            "reconciliation": {
                "target_symbols": [],
                "position_symbols": [],
                "missing_target_symbols": [],
                "extra_position_symbols": [],
                "filled_count": 0,
                "rejected_count": 0,
                "buy_notional_filled": 0.0,
                "sell_notional_filled": 0.0,
                "missing_target_reason_breakdown": {},
            },
            "recovery": {
                "retry_max_attempts": 0,
                "retry_attempts_used": 0,
                "retried_orders": 0,
                "retry_success_count": 0,
                "retry_failed_count": 0,
            },
            "auto_actions": {
                "switched_to_cautious": False,
                "switch_reason": None,
                "runtime_config_path": None,
                "retry_exhausted_streak": 0,
                "streak_threshold": 1,
            },
            "orders": [],
            "execution_attempts": [],
        }

    @staticmethod
    def _write_outputs(summary: dict, report_path: str, daily_report_path: str | None) -> None:
        Path(report_path).parent.mkdir(parents=True, exist_ok=True)
        Path(report_path).write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )

        if daily_report_path:
            md = render_daily_report_markdown(summary)
            Path(daily_report_path).parent.mkdir(parents=True, exist_ok=True)
            Path(daily_report_path).write_text(md, encoding="utf-8")

    @staticmethod
    def _build_price_map(signal_payload: dict, top_n: int | None) -> Dict[str, float]:
        candidates = list(signal_payload.get("candidates", []))
        if top_n is not None:
            candidates = candidates[: int(top_n)]
        price_map = {
            str(row["symbol"]).zfill(6): float(row.get("close", 0.0) or 0.0)
            for row in candidates
        }
        for row in list(signal_payload.get("holding_quotes", []) or []):
            symbol = str(row.get("symbol", "")).zfill(6)
            price = float(row.get("close", 0.0) or 0.0)
            if symbol and price > 0 and symbol not in price_map:
                price_map[symbol] = price
        return price_map
