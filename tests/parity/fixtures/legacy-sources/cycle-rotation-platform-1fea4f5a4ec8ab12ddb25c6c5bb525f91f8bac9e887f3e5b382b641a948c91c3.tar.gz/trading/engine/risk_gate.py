from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Set, Tuple

from trading.orders import PlannedOrder


@dataclass
class RiskGateConfig:
    max_total_position_ratio: float
    max_single_position_ratio: float
    blacklist_symbols: Set[str]
    max_daily_loss_ratio: float


class RiskGate:
    def __init__(self, config: RiskGateConfig):
        self.config = config

    def precheck_orders(
        self,
        orders: Iterable[PlannedOrder],
        price_by_symbol: Dict[str, float],
        cash: float,
        positions: Dict[str, int],
        nav: float,
        daily_pnl: float,
    ) -> Tuple[List[PlannedOrder], List[dict]]:
        approved: List[PlannedOrder] = []
        blocked: List[dict] = []

        nav_base = float(nav) if float(nav) > 0 else float(cash)
        if nav_base <= 0:
            nav_base = 1.0

        if float(daily_pnl) < 0 and abs(float(daily_pnl)) / nav_base >= float(
            self.config.max_daily_loss_ratio
        ):
            for order in orders:
                blocked.append(
                    {
                        "symbol": str(order.symbol).zfill(6),
                        "side": str(order.side).upper(),
                        "shares": int(order.shares),
                        "reason": "daily_loss_limit_reached",
                    }
                )
            return approved, blocked

        current_position_value = 0.0
        for symbol, shares in positions.items():
            symbol = str(symbol).zfill(6)
            px = float(price_by_symbol.get(symbol, 0.0) or 0.0)
            current_position_value += max(px, 0.0) * int(shares)

        total_position_value = current_position_value

        for order in orders:
            symbol = str(order.symbol).zfill(6)
            side = str(order.side).upper()
            shares = int(order.shares)
            price = float(price_by_symbol.get(symbol, 0.0) or 0.0)
            notional = price * shares

            if symbol in {s.zfill(6) for s in self.config.blacklist_symbols}:
                blocked.append(
                    {
                        "symbol": symbol,
                        "side": side,
                        "shares": shares,
                        "reason": "blacklist_symbol",
                    }
                )
                continue

            if side == "BUY" and nav_base > 0:
                single_ratio = notional / nav_base
                projected_total_ratio = (total_position_value + notional) / nav_base
                if single_ratio > float(self.config.max_single_position_ratio):
                    blocked.append(
                        {
                            "symbol": symbol,
                            "side": side,
                            "shares": shares,
                            "reason": "single_position_ratio_exceeded",
                        }
                    )
                    continue
                if projected_total_ratio > float(self.config.max_total_position_ratio):
                    blocked.append(
                        {
                            "symbol": symbol,
                            "side": side,
                            "shares": shares,
                            "reason": "total_position_ratio_exceeded",
                        }
                    )
                    continue
                total_position_value += notional
            elif side == "SELL":
                total_position_value = max(0.0, total_position_value - notional)

            approved.append(order)

        return approved, blocked
