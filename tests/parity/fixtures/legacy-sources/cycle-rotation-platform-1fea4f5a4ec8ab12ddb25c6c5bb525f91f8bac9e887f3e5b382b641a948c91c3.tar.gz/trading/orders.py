from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PlannedOrder:
    symbol: str
    side: str  # BUY or SELL
    shares: int
    reason: str
