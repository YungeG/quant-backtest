from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence


@dataclass(frozen=True)
class RankedCandidate:
    symbol: str
    price: float
    rank: int
    is_current_holding: bool = False


@dataclass(frozen=True)
class BlockedCandidate:
    symbol: str
    rank: int
    price: float
    reason: str


@dataclass(frozen=True)
class PositionTarget:
    symbol: str
    rank: int
    price: float
    target_weight: float
    target_value: float
    is_current_holding: bool = False


@dataclass(frozen=True)
class PositionSizingConfig:
    total_exposure_ratio: float = 0.95
    lot_size: int = 100
    min_open_lots: int = 2
    min_rebalance_lots: int = 1
    min_open_value: float = 0.0
    min_rebalance_value: float = 0.0
    band_width: float = 0.25


@dataclass(frozen=True)
class AllocationDecision:
    target_count: int
    target_value_per_name: float
    targets: list[PositionTarget]
    blocked: list[BlockedCandidate]


@dataclass(frozen=True)
class RebalanceOrder:
    symbol: str
    side: str
    shares: int
    reason: str


def _round_down_lot(shares: float, lot_size: int) -> int:
    if lot_size <= 0:
        raise ValueError("lot_size must be positive")
    return int(shares // lot_size) * lot_size


def build_equal_weight_targets(
    candidates: Sequence[RankedCandidate],
    nav: float,
    cfg: PositionSizingConfig,
    target_count: int | None = None,
) -> list[PositionTarget]:
    limit = min(int(target_count or len(candidates)), len(candidates))
    if limit <= 0 or nav <= 0:
        return []
    target_value = float(nav) * float(cfg.total_exposure_ratio) / float(limit)
    target_weight = float(cfg.total_exposure_ratio) / float(limit)
    targets: list[PositionTarget] = []
    for candidate in list(candidates)[:limit]:
        if float(candidate.price) <= 0:
            continue
        targets.append(
            PositionTarget(
                symbol=str(candidate.symbol).zfill(6),
                rank=int(candidate.rank),
                price=float(candidate.price),
                target_weight=target_weight,
                target_value=target_value,
                is_current_holding=bool(candidate.is_current_holding),
            )
        )
    return targets


def build_capital_aware_targets(
    candidates: Sequence[RankedCandidate],
    nav: float,
    cfg: PositionSizingConfig,
    max_target_count: int | None = None,
) -> AllocationDecision:
    cleaned = [
        RankedCandidate(
            symbol=str(candidate.symbol).zfill(6),
            price=float(candidate.price),
            rank=int(candidate.rank),
            is_current_holding=bool(candidate.is_current_holding),
        )
        for candidate in candidates
        if float(candidate.price) > 0
    ]
    limit = min(len(cleaned), int(max_target_count or len(cleaned)))
    if limit <= 0 or nav <= 0:
        return AllocationDecision(target_count=0, target_value_per_name=0.0, targets=[], blocked=[])

    total_budget = float(nav) * float(cfg.total_exposure_ratio)
    last_blocked: list[BlockedCandidate] = []
    for target_count in range(limit, 0, -1):
        target_value = total_budget / float(target_count)
        target_weight = float(cfg.total_exposure_ratio) / float(target_count)
        targets: list[PositionTarget] = []
        blocked: list[BlockedCandidate] = []
        upper_keep_value = target_value * (1.0 + max(float(cfg.band_width), 0.0))

        for candidate in cleaned:
            symbol = str(candidate.symbol).zfill(6)
            price = float(candidate.price)
            if candidate.is_current_holding:
                if price * int(cfg.lot_size) <= upper_keep_value + 1e-9:
                    targets.append(
                        PositionTarget(
                            symbol=symbol,
                            rank=int(candidate.rank),
                            price=price,
                            target_weight=target_weight,
                            target_value=target_value,
                            is_current_holding=True,
                        )
                    )
                else:
                    blocked.append(
                        BlockedCandidate(
                            symbol=symbol,
                            rank=int(candidate.rank),
                            price=price,
                            reason="retained_one_lot_exceeds_upper_band",
                        )
                    )
            else:
                min_open_lot_value = price * int(cfg.lot_size) * max(int(cfg.min_open_lots), 1)
                min_open_value = max(min_open_lot_value, float(cfg.min_open_value))
                if min_open_value <= target_value + 1e-9:
                    targets.append(
                        PositionTarget(
                            symbol=symbol,
                            rank=int(candidate.rank),
                            price=price,
                            target_weight=target_weight,
                            target_value=target_value,
                            is_current_holding=False,
                        )
                    )
                else:
                    reason = (
                        "new_entry_min_value_exceeded"
                        if float(cfg.min_open_value) > min_open_lot_value + 1e-9
                        else "new_entry_min_lots_exceeded"
                    )
                    blocked.append(
                        BlockedCandidate(
                            symbol=symbol,
                            rank=int(candidate.rank),
                            price=price,
                            reason=reason,
                        )
                    )
            if len(targets) >= target_count:
                return AllocationDecision(
                    target_count=target_count,
                    target_value_per_name=target_value,
                    targets=targets,
                    blocked=blocked,
                )

        last_blocked = blocked

    return AllocationDecision(target_count=0, target_value_per_name=0.0, targets=[], blocked=last_blocked)


def plan_target_rebalance_orders(
    targets: Sequence[PositionTarget],
    current_positions: Mapping[str, int],
    cfg: PositionSizingConfig,
) -> tuple[list[RebalanceOrder], list[BlockedCandidate]]:
    target_map = {str(target.symbol).zfill(6): target for target in targets}
    orders: list[RebalanceOrder] = []
    blocked: list[BlockedCandidate] = []
    min_rebalance_shares = int(cfg.min_rebalance_lots) * int(cfg.lot_size)
    min_open_shares = int(cfg.min_open_lots) * int(cfg.lot_size)
    min_open_value = max(float(cfg.min_open_value), 0.0)
    min_rebalance_value = max(float(cfg.min_rebalance_value), 0.0)

    for symbol, shares in current_positions.items():
        normalized_symbol = str(symbol).zfill(6)
        if normalized_symbol not in target_map and int(shares) > 0:
            orders.append(
                RebalanceOrder(
                    symbol=normalized_symbol,
                    side="SELL",
                    shares=int(shares),
                    reason="symbol_not_in_execution_targets",
                )
            )

    for symbol, target in target_map.items():
        current_shares = int(current_positions.get(symbol, 0) or 0)
        current_value = current_shares * float(target.price)
        target_value = float(target.target_value)
        lower_value = target_value * (1.0 - max(float(cfg.band_width), 0.0))
        upper_value = target_value * (1.0 + max(float(cfg.band_width), 0.0))

        if current_shares <= 0:
            raw_shares = target_value / float(target.price)
            shares = _round_down_lot(raw_shares, int(cfg.lot_size))
            order_value = shares * float(target.price)
            if shares >= min_open_shares and order_value + 1e-9 >= min_open_value:
                orders.append(
                    RebalanceOrder(
                        symbol=symbol,
                        side="BUY",
                        shares=shares,
                        reason="open_to_target_weight",
                    )
                )
            elif target_value > 0:
                blocked.append(
                    BlockedCandidate(
                        symbol=symbol,
                        rank=int(target.rank),
                        price=float(target.price),
                        reason=(
                            "target_below_min_open_value"
                            if shares >= min_open_shares
                            else "target_below_min_open_lots"
                        ),
                    )
                )
            continue

        if current_value < lower_value:
            diff_value = target_value - current_value
            shares = _round_down_lot(diff_value / float(target.price), int(cfg.lot_size))
            order_value = shares * float(target.price)
            if shares >= min_rebalance_shares and order_value + 1e-9 >= min_rebalance_value:
                orders.append(
                    RebalanceOrder(
                        symbol=symbol,
                        side="BUY",
                        shares=shares,
                        reason="top_up_to_target_band",
                    )
                )
            elif shares > 0:
                blocked.append(
                    BlockedCandidate(
                        symbol=symbol,
                        rank=int(target.rank),
                        price=float(target.price),
                        reason=(
                            "rebalance_below_min_value"
                            if shares >= min_rebalance_shares
                            else "rebalance_below_min_lots"
                        ),
                    )
                )
        elif current_value > upper_value:
            diff_value = current_value - target_value
            shares = min(_round_down_lot(diff_value / float(target.price), int(cfg.lot_size)), current_shares)
            order_value = shares * float(target.price)
            if shares >= min_rebalance_shares and order_value + 1e-9 >= min_rebalance_value:
                orders.append(
                    RebalanceOrder(
                        symbol=symbol,
                        side="SELL",
                        shares=shares,
                        reason="trim_to_target_band",
                    )
                )
            elif shares > 0:
                blocked.append(
                    BlockedCandidate(
                        symbol=symbol,
                        rank=int(target.rank),
                        price=float(target.price),
                        reason=(
                            "rebalance_below_min_value"
                            if shares >= min_rebalance_shares
                            else "rebalance_below_min_lots"
                        ),
                    )
                )

    orders.sort(key=lambda order: 0 if str(order.side).upper() == "SELL" else 1)
    return orders, blocked
