from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from typing import Any, Callable, Protocol


NotifyAlert = Callable[[str, str], Any]
NotifySignalSummary = Callable[..., Any]


@dataclass(frozen=True)
class SignalGenerationRequest:
    project_root: Path
    config_path: Path
    base_name: str
    plan_key: str | None = None
    live_dir: Path | None = None
    limit: int | None = None
    notify: bool = True
    verbose: bool = False
    use_strategy_reference_state: bool = False
    signal_storage_db_path: Path | None = None
    send_alert: NotifyAlert | None = None
    send_signal_summary: NotifySignalSummary | None = None


@dataclass(frozen=True)
class SignalGenerationResult:
    latest_path: Path
    dated_path: Path
    payload: dict[str, Any]


class StrategyAdapter(Protocol):
    key: str

    def generate_signals(self, request: SignalGenerationRequest) -> SignalGenerationResult:
        ...


ADAPTER_MODULES = {
    "cycle_rotation": "strategies.cycle_rotation.adapter",
    "lowturn_liqfloor": "strategies.lowturn_liqfloor.adapter",
    "wyckoff_chan": "strategies.wyckoff_chan.adapter",
    "wyckoff_markup": "strategies.wyckoff_markup.adapter",
    "market_gated_pullback": "strategies.market_gated_pullback.adapter",
    "rapid_riser_turnover_shadow": "strategies.rapid_riser.adapter",
}


def load_strategy_adapter(key: str) -> StrategyAdapter:
    module_name = ADAPTER_MODULES.get(key, key if "." in key else "")
    if not module_name:
        known = ", ".join(sorted(ADAPTER_MODULES))
        raise ValueError(f"unknown strategy adapter {key!r}; known adapters: {known}")

    module = import_module(module_name)
    adapter = getattr(module, "ADAPTER", None)
    if adapter is None:
        raise ValueError(f"strategy adapter module {module_name!r} does not expose ADAPTER")
    if not hasattr(adapter, "generate_signals"):
        raise TypeError(f"strategy adapter {key!r} does not implement generate_signals")
    return adapter


def known_strategy_adapters() -> list[str]:
    return sorted(ADAPTER_MODULES)
