from __future__ import annotations

from strategies.contracts import validate_signal_payload
from strategies.registry import SignalGenerationRequest, SignalGenerationResult


class TemplateStrategyAdapter:
    """Copy this scaffold into strategies/<strategy_key>/adapter.py."""

    key = "replace_me"

    def generate_signals(self, request: SignalGenerationRequest) -> SignalGenerationResult:
        # Load request.config_path, score the universe, and build the common
        # signal payload. Keep strategy-specific logic here; operations code
        # should only see SignalGenerationResult and the validated payload.
        payload = {
            "strategy_adapter": self.key,
            "strategy_name": "replace_me",
            "signal_date": "YYYY-MM-DD",
            "execution_rule": "next_open",
            "top_n": 0,
            "warnings": [],
            "universe_size": 0,
            "filtered_universe_size": 0,
            "holding_quotes": [],
            "candidates": [],
        }
        validate_signal_payload(payload)
        raise NotImplementedError("Template adapter must be copied and implemented before registration")


# Do not register this template directly.
ADAPTER = TemplateStrategyAdapter()
