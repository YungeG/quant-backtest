from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


class SignalContractError(ValueError):
    pass


REQUIRED_SIGNAL_FIELDS = {
    "strategy_name",
    "signal_date",
    "execution_rule",
    "top_n",
    "warnings",
    "universe_size",
    "filtered_universe_size",
    "holding_quotes",
    "candidates",
}

REQUIRED_CANDIDATE_FIELDS = {"symbol", "close", "total_score"}
REQUIRED_HOLDING_QUOTE_FIELDS = {"symbol", "close"}
ALLOWED_QUALITY_STATUSES = {"ok", "watch", "weak"}


def _fail(message: str) -> None:
    raise SignalContractError(message)


def _require_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(f"{label} must be an object")
    return value


def _require_sequence(value: Any, label: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        _fail(f"{label} must be a list")
    return value


def _require_non_empty_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        _fail(f"{label} must be a non-empty string")
    return value


def _require_non_negative_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        _fail(f"{label} must be a non-negative integer")
    return value


def _require_number(value: Any, label: str) -> float:
    if isinstance(value, bool):
        _fail(f"{label} must be numeric")
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        _fail(f"{label} must be numeric")
    return parsed


def _require_optional_number(value: Any, label: str) -> float | None:
    if value is None:
        return None
    return _require_number(value, label)


def _validate_symbol(value: Any, label: str) -> str:
    symbol = _require_non_empty_string(value, label).split(".")[0].zfill(6)
    if not symbol.isdigit() or len(symbol) != 6:
        _fail(f"{label} must normalize to a 6-digit stock symbol")
    return symbol


def validate_signal_payload(payload: Mapping[str, Any]) -> None:
    """Validate the strategy-neutral signal JSON consumed by operations apps."""
    missing = sorted(field for field in REQUIRED_SIGNAL_FIELDS if field not in payload)
    if missing:
        _fail(f"signal payload missing required fields: {', '.join(missing)}")

    _require_non_empty_string(payload.get("strategy_name"), "strategy_name")
    _require_non_empty_string(payload.get("signal_date"), "signal_date")
    _require_non_empty_string(payload.get("execution_rule"), "execution_rule")
    _require_non_negative_int(payload.get("top_n"), "top_n")
    _require_non_negative_int(payload.get("universe_size"), "universe_size")
    _require_non_negative_int(payload.get("filtered_universe_size"), "filtered_universe_size")

    if "strategy_adapter" in payload:
        _require_non_empty_string(payload.get("strategy_adapter"), "strategy_adapter")

    _require_sequence(payload.get("warnings"), "warnings")

    for index, row in enumerate(_require_sequence(payload.get("candidates"), "candidates")):
        candidate = _require_mapping(row, f"candidates[{index}]")
        missing_candidate = sorted(field for field in REQUIRED_CANDIDATE_FIELDS if field not in candidate)
        if missing_candidate:
            _fail(
                f"candidates[{index}] missing required fields: "
                f"{', '.join(missing_candidate)}"
            )
        _validate_symbol(candidate.get("symbol"), f"candidates[{index}].symbol")
        close = _require_number(candidate.get("close"), f"candidates[{index}].close")
        if close <= 0:
            _fail(f"candidates[{index}].close must be positive")
        _require_number(candidate.get("total_score"), f"candidates[{index}].total_score")
        for field in (
            "base_total_score",
            "factor_base_total_score",
            "momentum_score",
            "low_vol_score",
            "small_cap_score",
            "small_cap_relative_score",
        ):
            if field in candidate:
                _require_number(candidate.get(field), f"candidates[{index}].{field}")
        if "score_mode" in candidate:
            _require_non_empty_string(candidate.get("score_mode"), f"candidates[{index}].score_mode")
        if "momentum_raw" in candidate:
            _require_number(candidate.get("momentum_raw"), f"candidates[{index}].momentum_raw")
        if "absolute_quality_score" in candidate:
            _require_number(
                candidate.get("absolute_quality_score"),
                f"candidates[{index}].absolute_quality_score",
            )
        if "absolute_quality_reason" in candidate:
            _require_non_empty_string(
                candidate.get("absolute_quality_reason"),
                f"candidates[{index}].absolute_quality_reason",
            )

    if "candidate_quality" in payload:
        quality = _require_mapping(payload.get("candidate_quality"), "candidate_quality")
        status = _require_non_empty_string(quality.get("quality_status"), "candidate_quality.quality_status")
        if status not in ALLOWED_QUALITY_STATUSES:
            _fail(
                "candidate_quality.quality_status must be one of: "
                + ", ".join(sorted(ALLOWED_QUALITY_STATUSES))
            )
        _require_non_empty_string(quality.get("action"), "candidate_quality.action")
        if "metric" in quality:
            _require_non_empty_string(quality.get("metric"), "candidate_quality.metric")
        if "quality_reason" in quality:
            _require_non_empty_string(quality.get("quality_reason"), "candidate_quality.quality_reason")
        _require_optional_number(quality.get("top1_momentum_raw"), "candidate_quality.top1_momentum_raw")
        _require_optional_number(
            quality.get("top5_avg_momentum_raw"),
            "candidate_quality.top5_avg_momentum_raw",
        )
        if "top5_positive_momentum_count" in quality:
            _require_non_negative_int(
                quality.get("top5_positive_momentum_count"),
                "candidate_quality.top5_positive_momentum_count",
            )
        if "evaluated_candidate_count" in quality:
            _require_non_negative_int(
                quality.get("evaluated_candidate_count"),
                "candidate_quality.evaluated_candidate_count",
            )

    for index, row in enumerate(_require_sequence(payload.get("holding_quotes"), "holding_quotes")):
        quote = _require_mapping(row, f"holding_quotes[{index}]")
        missing_quote = sorted(field for field in REQUIRED_HOLDING_QUOTE_FIELDS if field not in quote)
        if missing_quote:
            _fail(f"holding_quotes[{index}] missing required fields: {', '.join(missing_quote)}")
        _validate_symbol(quote.get("symbol"), f"holding_quotes[{index}].symbol")
        close = _require_number(quote.get("close"), f"holding_quotes[{index}].close")
        if close <= 0:
            _fail(f"holding_quotes[{index}].close must be positive")
