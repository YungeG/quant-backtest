# Platform Architecture Target

This project is moving from a repo-local live operations workbench toward a
deliverable, migratable, deployable, multi-strategy, multi-account trading
platform. Full-auto broker execution is intentionally out of scope for the next
phase.

## Layer Model

```text
platform profile
  -> deployment profile
  -> account registry
  -> strategy routes / live plans
  -> operations commands
  -> strategy adapters
  -> trading-domain services
  -> core data/strategy primitives
```

## Current Platform Contract

- Platform manifest: `config/platform/manifest.json`
- Platform loader/checker: `operations/platform_config.py`
- Read-only validation command: `operations/bin/platform-check`
- Environment/dependency validation: `operations/bin/env-check`
- Backup/restore: `operations/bin/backup-state`, `operations/bin/restore-state`
- Runtime diagnostics: `operations/bin/diagnose`
- Live plan authority: `config/live/manifest.json`
- Strategy adapters: `strategies/`
- Trading-domain services: `trading/`
- Data sources: external deployment dependencies; not bundled into source.

## Acceptance Split: Runnable vs Rebuildable

This platform distinguishes two different acceptance targets:

- **Runnable**: the candidate-only workflow can execute end to end (`daily-update`,
  `scheduler-check`). Manual execution/state commands are disabled by default.
- **Rebuildable**: the strategy-owned artifacts consumed by the runnable lane
  can be regenerated and compared from approved upstream inputs

For the current stable/source-owned industry lane, runnable workflows alone are
not enough. `operations/bin/rebuild-industry-source compare`,
`operations/bin/export-industry-overlay check`,
`operations/bin/check-industry-source-top3 check`, and
`operations/bin/check-industry-candidate-pool check` are part of the canonical
acceptance surface because they prove the live artifacts still reflect the
intended strategy logic rather than stale packaged JSON.

## Boundaries

### `operations/`

Owns command orchestration, operational workflows, candidate validation,
traceability, and deployment validation. Legacy plan activation/risk/manual-sync
surfaces remain available only for explicit manual-execution revival. It should
not own strategy logic.

### `config/platform/`

Owns deployable profile metadata: deployments, accounts, strategy routes,
data providers, portable roots, external dependencies, and required commands.

### `config/live/`

Owns live strategy/runtime plan definitions.

It may point to packaged strategy artifacts, but those artifacts are only
production-valid when their canonical builder and validation surface remain
available in `operations/`.

### `strategies/`

Owns strategy adapters that translate strategy-specific logic into the common
signal contract.

### `trading/`

Owns reusable trading-domain services: planning, order intent, manual sync,
state repository, risk gate, broker adapters, and reports.

### `core/`

Owns data access, factor computation, and strategy primitives.

## Canonical Strategy Lineage Rule

Any artifact referenced by a live plan must have an explicit lineage contract:

- upstream inputs
- canonical builder
- rebuild command
- validation/compare command
- promotion gate

If one of those pieces is missing, the artifact should be treated as an
incomplete handoff, not as a sufficient production dependency.

## Data Provider Path

Data provider metadata starts in `config/platform/manifest.json`:

- provider key
- provider type
- market data directory
- fundamentals directory
- static directory
- extended directory
- DuckDB path

Operations workflows should read data dependency paths through platform/config
profiles rather than hard-coding machine paths.

## Multi-Account Path

Account metadata starts in `config/platform/manifest.json`:

- account key
- broker adapter
- capital
- state DB path
- sync input path
- risk output path
- allowed live plans
- default plan

Next safe step: add optional `--account` to operations commands and resolve
their default plan/state paths from the account spec.

## Multi-Strategy Path

Strategy metadata is routed through:

- `strategies/registry.py`
- `strategies/contracts.py`
- `config/live/manifest.json`
- `config/platform/manifest.json` strategy routes

Adding a strategy should require a new adapter plus manifest entries, not edits
to operations workflow code.

## Deployment Path

The platform manifest separates:

- portable roots that should move with source
- strategy-owned processing logic that must stay rebuildable after migration
- mutable runtime roots that need backup/restore
- external data dependencies that must be mounted/provided
- commands that must exist in a deployable environment

`operations/bin/platform-check` is the first validation gate for a new machine
or account profile.
