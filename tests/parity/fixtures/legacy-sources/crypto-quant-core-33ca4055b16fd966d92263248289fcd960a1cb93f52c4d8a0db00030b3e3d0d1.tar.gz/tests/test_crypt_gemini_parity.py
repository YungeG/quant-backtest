from __future__ import annotations

import importlib.util
from pathlib import Path

import pandas as pd
import pytest

from crypto_quant_core.portfolio import build_position_matrix


LEGACY_MODULE = (
    Path(__file__).resolve().parents[2]
    / "crypt-gemini"
    / "core"
    / "portfolio_sizing.py"
)


@pytest.mark.skipif(not LEGACY_MODULE.exists(), reason="crypt-gemini sibling is unavailable")
def test_position_sizing_is_parity_compatible_with_crypt_gemini() -> None:
    spec = importlib.util.spec_from_file_location("crypt_gemini_portfolio_sizing", LEGACY_MODULE)
    assert spec is not None and spec.loader is not None
    legacy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)

    index = pd.date_range("2024-01-01", periods=4, freq="1h")
    signals = pd.DataFrame(
        [[1, 0, -1], [1, 1, -1], [0, 1, -1], [-1, 1, 0]],
        index=index,
        columns=["BTC", "ETH", "SOL"],
        dtype=float,
    )
    volatility = pd.DataFrame(
        [[1, 2, 4], [1, 2, 4], [1, float("nan"), 4], [2, 2, 2]],
        index=index,
        columns=signals.columns,
        dtype=float,
    )
    expected = legacy.build_position_matrix(
        signals,
        volatility,
        target_gross=2.0,
        max_exposure=1.0,
        hold_entry_weight=True,
    )
    actual = build_position_matrix(
        signals,
        volatility,
        target_gross=2.0,
        max_exposure=1.0,
        hold_entry_weight=True,
    )
    pd.testing.assert_frame_equal(actual, expected)

