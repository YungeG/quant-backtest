from __future__ import annotations

from decimal import Decimal

import pandas as pd
import pytest

from crypto_quant_core import (
    Candle,
    DataIntegrityError,
    Fill,
    FundingPayment,
    assert_monotonic_timestamps,
    assert_no_lookahead,
    build_position_matrix,
    calculate_closed_trade,
    normalize_order,
    snapshot_from_exchange_info,
)
from crypto_quant_core.adapters import HummingbotControllerSpec


def exchange_info() -> dict[str, object]:
    return {
        "symbols": [{
            "symbol": "ETHUSDT",
            "filters": [
                {"filterType": "PRICE_FILTER", "tickSize": "0.10", "minPrice": "0.10", "maxPrice": "1000000"},
                {"filterType": "LOT_SIZE", "stepSize": "0.001", "minQty": "0.001", "maxQty": "1000"},
                {"filterType": "MIN_NOTIONAL", "minNotional": "5"},
            ],
        }]
    }


def test_portfolio_sizing_matches_crypt_gemini_reference_case() -> None:
    index = pd.date_range("2021-01-01", periods=1, freq="12h")
    signals = pd.DataFrame([[1.0, 1.0]], index=index, columns=["A", "B"])
    volatility = pd.DataFrame([[1.0, 3.0]], index=index, columns=["A", "B"])
    positions = build_position_matrix(
        signals,
        volatility,
        target_gross=2.0,
        max_exposure=2.0,
        hold_entry_weight=True,
    )
    assert positions.iloc[0].to_dict() == {"A": 1.5, "B": 0.5}


def test_binance_rules_normalize_fail_closed() -> None:
    rules = snapshot_from_exchange_info(exchange_info(), symbol="ethusdt", fetched_at_ms=100)
    order = normalize_order(rules, side="buy", price=Decimal("2000.19"), quantity=Decimal("0.0039"))
    assert order.price == Decimal("2000.10")
    assert order.quantity == Decimal("0.003")
    assert order.notional == Decimal("6.00030")
    with pytest.raises(DataIntegrityError, match="minimum notional"):
        normalize_order(rules, side="buy", price=Decimal("100"), quantity=Decimal("0.001"))


def test_closed_trade_accounts_for_fees_and_funding() -> None:
    entry = Fill(100, "buy", Decimal("100"), Decimal("2"), Decimal("0.10"))
    exit = Fill(200, "sell", Decimal("105"), Decimal("2"), Decimal("0.11"))
    result = calculate_closed_trade(
        entry,
        exit,
        funding=(FundingPayment(150, Decimal("-0.20")),),
    )
    assert result.gross_price_pnl == Decimal("10")
    assert result.net_pnl == Decimal("9.59")


def test_causality_guards_future_and_duplicate_time() -> None:
    assert_no_lookahead(decision_time_ms=100, observed_through_ms=100)
    with pytest.raises(DataIntegrityError, match="future"):
        assert_no_lookahead(decision_time_ms=100, observed_through_ms=101)
    with pytest.raises(DataIntegrityError, match="monotonic"):
        assert_monotonic_timestamps([1, 1])


def test_normalized_market_contracts_and_hummingbot_dto() -> None:
    candle = Candle(
        "ETHUSDT", "1m", 0, 59_999,
        Decimal("100"), Decimal("102"), Decimal("99"), Decimal("101"), Decimal("12"),
    )
    assert candle.close == Decimal("101")
    config = HummingbotControllerSpec(
        "example_v1", "binance_perpetual", "ETH-USDT", Decimal("1000")
    ).to_config()
    assert config["paper_trade"] is True
    assert config["config_version"] == 1

