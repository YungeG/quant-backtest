"""Inverse-volatility sizing extracted from crypt-gemini/core/portfolio_sizing.py."""

from __future__ import annotations

import numpy as np
import pandas as pd


def realized_vol(close: pd.DataFrame, window: int) -> pd.DataFrame:
    if window <= 0:
        raise ValueError("window must be positive")
    log_returns = np.log(close / close.shift(1))
    return log_returns.rolling(window=window, min_periods=window).std()


def inverse_vol_weights(
    inv_vol: pd.Series, gross_budget: float, max_exposure: float
) -> pd.Series:
    if max_exposure < 0:
        raise ValueError("max_exposure must be non-negative")
    if inv_vol.empty or gross_budget <= 0:
        return inv_vol * 0.0
    total = inv_vol.sum()
    if total <= 0:
        return inv_vol * 0.0
    exposure = inv_vol / total * gross_budget
    return exposure.clip(upper=max_exposure)


def build_position_matrix(
    signals: pd.DataFrame,
    volatility: pd.DataFrame,
    *,
    target_gross: float,
    max_exposure: float,
    hold_entry_weight: bool = True,
) -> pd.DataFrame:
    if not signals.index.equals(volatility.index) or list(signals.columns) != list(volatility.columns):
        raise ValueError("signals and volatility must have identical axes")
    if target_gross < 0 or max_exposure < 0:
        raise ValueError("gross and exposure limits must be non-negative")

    columns = list(signals.columns)
    positions = pd.DataFrame(0.0, index=signals.index, columns=columns)
    prev = pd.Series(0.0, index=columns)

    for ts in signals.index:
        sig = signals.loc[ts].fillna(0.0)
        vol = volatility.loc[ts]
        valid = vol.notna() & (vol > 0.0)
        sig = sig.where(valid, 0.0)
        out = pd.Series(0.0, index=columns)

        if hold_entry_weight:
            held = {
                symbol: prev[symbol]
                for symbol in columns
                if prev[symbol] != 0.0
                and np.sign(prev[symbol]) == np.sign(sig[symbol])
                and sig[symbol] != 0.0
            }
            for symbol, value in held.items():
                out[symbol] = value
            remaining = max(0.0, target_gross - sum(abs(value) for value in held.values()))
            new_active = [s for s in columns if sig[s] != 0.0 and s not in held]
            if new_active and remaining > 0.0:
                exposure = inverse_vol_weights(1.0 / vol[new_active], remaining, max_exposure)
                for symbol in new_active:
                    out[symbol] = exposure[symbol] * np.sign(sig[symbol])
        else:
            active = [symbol for symbol in columns if sig[symbol] != 0.0]
            if active:
                exposure = inverse_vol_weights(1.0 / vol[active], target_gross, max_exposure)
                for symbol in active:
                    out[symbol] = exposure[symbol] * np.sign(sig[symbol])

        positions.loc[ts] = out
        prev = out

    return positions

