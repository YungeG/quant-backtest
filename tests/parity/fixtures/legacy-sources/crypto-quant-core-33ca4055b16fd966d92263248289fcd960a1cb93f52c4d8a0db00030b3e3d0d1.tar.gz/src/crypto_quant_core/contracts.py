from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from decimal import Decimal
from hashlib import sha256
import json
from typing import Mapping, Sequence


class DataIntegrityError(ValueError):
    """Input data cannot safely be used for research or execution."""


def _positive_decimal(name: str, value: Decimal) -> None:
    if type(value) is not Decimal or not value.is_finite() or value <= 0:
        raise DataIntegrityError(f"{name} must be a finite positive Decimal")


@dataclass(frozen=True)
class Candle:
    symbol: str
    interval: str
    open_time_ms: int
    close_time_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal

    def __post_init__(self) -> None:
        if not self.symbol or self.symbol != self.symbol.strip().upper():
            raise DataIntegrityError("symbol must be normalized uppercase text")
        if not self.interval:
            raise DataIntegrityError("interval must be non-empty")
        if self.open_time_ms < 0 or self.close_time_ms <= self.open_time_ms:
            raise DataIntegrityError("candle timestamps are invalid")
        for name in ("open", "high", "low", "close"):
            _positive_decimal(name, getattr(self, name))
        if type(self.volume) is not Decimal or not self.volume.is_finite() or self.volume < 0:
            raise DataIntegrityError("volume must be a finite non-negative Decimal")
        if self.low > min(self.open, self.close) or self.high < max(self.open, self.close):
            raise DataIntegrityError("OHLC values are inconsistent")


@dataclass(frozen=True)
class FundingRate:
    symbol: str
    funding_time_ms: int
    rate: Decimal

    def __post_init__(self) -> None:
        if not self.symbol or self.symbol != self.symbol.strip().upper():
            raise DataIntegrityError("symbol must be normalized uppercase text")
        if self.funding_time_ms < 0:
            raise DataIntegrityError("funding_time_ms must be non-negative")
        if type(self.rate) is not Decimal or not self.rate.is_finite():
            raise DataIntegrityError("funding rate must be a finite Decimal")


@dataclass(frozen=True)
class BookTicker:
    symbol: str
    event_time_ms: int
    bid_price: Decimal
    bid_quantity: Decimal
    ask_price: Decimal
    ask_quantity: Decimal

    def __post_init__(self) -> None:
        if not self.symbol or self.symbol != self.symbol.strip().upper():
            raise DataIntegrityError("symbol must be normalized uppercase text")
        if self.event_time_ms < 0:
            raise DataIntegrityError("event_time_ms must be non-negative")
        for name in ("bid_price", "bid_quantity", "ask_price", "ask_quantity"):
            _positive_decimal(name, getattr(self, name))
        if self.bid_price >= self.ask_price:
            raise DataIntegrityError("book must have a positive spread")


def _jsonable(value: object) -> object:
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise TypeError("non-finite Decimal is not canonical")
        return format(value, "f")
    if isinstance(value, float):
        raise TypeError("float values are not canonical")
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonable(asdict(value))
    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise TypeError("canonical mappings require string keys")
        return {key: _jsonable(value[key]) for key in sorted(value)}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_jsonable(item) for item in value]
    if value is None or isinstance(value, (str, int, bool)):
        return value
    raise TypeError(f"unsupported canonical type: {type(value).__name__}")


def canonical_json(value: object) -> str:
    return json.dumps(_jsonable(value), sort_keys=True, separators=(",", ":"))


def canonical_sha256(value: object) -> str:
    return sha256(canonical_json(value).encode("utf-8")).hexdigest()

