from __future__ import annotations

from collections.abc import Iterable

from .contracts import DataIntegrityError


def assert_monotonic_timestamps(timestamps_ms: Iterable[int], *, strictly: bool = True) -> None:
    previous: int | None = None
    for current in timestamps_ms:
        if type(current) is not int or current < 0:
            raise DataIntegrityError("timestamps must be non-negative integers")
        if previous is not None and (current <= previous if strictly else current < previous):
            raise DataIntegrityError("timestamps are not monotonic")
        previous = current


def assert_no_lookahead(*, decision_time_ms: int, observed_through_ms: int) -> None:
    if type(decision_time_ms) is not int or type(observed_through_ms) is not int:
        raise DataIntegrityError("timestamps must be integers")
    if decision_time_ms < 0 or observed_through_ms < 0:
        raise DataIntegrityError("timestamps must be non-negative")
    if observed_through_ms > decision_time_ms:
        raise DataIntegrityError("decision consumed future data")

