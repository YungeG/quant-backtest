from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_UP
from hashlib import sha256
from typing import Mapping

from .contracts import DataIntegrityError, canonical_json


@dataclass(frozen=True)
class ExchangeRuleSnapshot:
    symbol: str
    fetched_at_ms: int
    tick_size: Decimal
    min_price: Decimal
    max_price: Decimal
    step_size: Decimal
    min_quantity: Decimal
    max_quantity: Decimal
    min_notional: Decimal
    max_notional: Decimal | None
    source_sha256: str


@dataclass(frozen=True)
class NormalizedOrder:
    symbol: str
    side: str
    price: Decimal
    quantity: Decimal
    notional: Decimal


def _filter_map(row: Mapping[str, object]) -> dict[str, Mapping[str, object]]:
    raw = row.get("filters")
    if not isinstance(raw, list):
        raise DataIntegrityError("exchange filters must be a list")
    result: dict[str, Mapping[str, object]] = {}
    for item in raw:
        if not isinstance(item, Mapping) or not isinstance(item.get("filterType"), str):
            raise DataIntegrityError("invalid exchange filter")
        name = str(item["filterType"])
        if name in result:
            raise DataIntegrityError(f"duplicate exchange filter: {name}")
        result[name] = item
    return result


def snapshot_from_exchange_info(
    payload: Mapping[str, object], *, symbol: str, fetched_at_ms: int
) -> ExchangeRuleSnapshot:
    normalized_symbol = symbol.strip().upper()
    if not normalized_symbol or fetched_at_ms < 0:
        raise DataIntegrityError("invalid snapshot identity")
    rows = payload.get("symbols")
    if not isinstance(rows, list):
        raise DataIntegrityError("symbols must be a list")
    matches = [row for row in rows if isinstance(row, Mapping) and row.get("symbol") == normalized_symbol]
    if len(matches) != 1:
        raise DataIntegrityError(f"expected exactly one rule row for {normalized_symbol}")
    try:
        filters = _filter_map(matches[0])
        price = filters["PRICE_FILTER"]
        lot = filters["LOT_SIZE"]
        notional = filters.get("NOTIONAL", filters.get("MIN_NOTIONAL"))
        if notional is None:
            raise KeyError("NOTIONAL")
        snapshot = ExchangeRuleSnapshot(
            symbol=normalized_symbol,
            fetched_at_ms=fetched_at_ms,
            tick_size=Decimal(str(price["tickSize"])),
            min_price=Decimal(str(price["minPrice"])),
            max_price=Decimal(str(price["maxPrice"])),
            step_size=Decimal(str(lot["stepSize"])),
            min_quantity=Decimal(str(lot["minQty"])),
            max_quantity=Decimal(str(lot["maxQty"])),
            min_notional=Decimal(str(notional["minNotional"])),
            max_notional=Decimal(str(notional["maxNotional"])) if "maxNotional" in notional else None,
            source_sha256=sha256(canonical_json(payload).encode("utf-8")).hexdigest(),
        )
    except (InvalidOperation, KeyError, TypeError, ValueError) as exc:
        raise DataIntegrityError(f"invalid exchange rules for {normalized_symbol}") from exc
    _validate_snapshot(snapshot)
    return snapshot


def _validate_snapshot(rules: ExchangeRuleSnapshot) -> None:
    required_positive = (
        rules.tick_size,
        rules.step_size,
        rules.min_quantity,
        rules.max_quantity,
        rules.min_notional,
    )
    if any(not value.is_finite() or value <= 0 for value in required_positive):
        raise DataIntegrityError("exchange rules contain non-positive limits")
    if rules.max_quantity < rules.min_quantity:
        raise DataIntegrityError("maximum quantity is below minimum quantity")
    if rules.max_price > 0 and rules.max_price < rules.min_price:
        raise DataIntegrityError("maximum price is below minimum price")
    if rules.max_notional is not None and rules.max_notional < rules.min_notional:
        raise DataIntegrityError("maximum notional is below minimum notional")


def _quantize(value: Decimal, step: Decimal, rounding: str) -> Decimal:
    return (value / step).to_integral_value(rounding=rounding) * step


def normalize_order(
    rules: ExchangeRuleSnapshot,
    *,
    side: str,
    price: Decimal,
    quantity: Decimal,
) -> NormalizedOrder:
    normalized_side = side.lower()
    if normalized_side not in {"buy", "sell"}:
        raise DataIntegrityError("side must be buy or sell")
    if not price.is_finite() or not quantity.is_finite() or price <= 0 or quantity <= 0:
        raise DataIntegrityError("order price and quantity must be finite and positive")
    price_rounding = ROUND_DOWN if normalized_side == "buy" else ROUND_UP
    normalized_price = _quantize(price, rules.tick_size, price_rounding)
    normalized_quantity = _quantize(quantity, rules.step_size, ROUND_DOWN)
    notional = normalized_price * normalized_quantity
    if normalized_price < rules.min_price or (rules.max_price > 0 and normalized_price > rules.max_price):
        raise DataIntegrityError("normalized price violates exchange limits")
    if normalized_quantity < rules.min_quantity or normalized_quantity > rules.max_quantity:
        raise DataIntegrityError("normalized quantity violates exchange limits")
    if notional < rules.min_notional:
        raise DataIntegrityError("normalized order violates minimum notional")
    if rules.max_notional is not None and notional > rules.max_notional:
        raise DataIntegrityError("normalized order violates maximum notional")
    return NormalizedOrder(rules.symbol, normalized_side, normalized_price, normalized_quantity, notional)

