"""Stable public surface for shared crypto-quant contracts."""

from .accounting import Fill, FundingPayment, PnlBreakdown, calculate_closed_trade
from .causality import assert_monotonic_timestamps, assert_no_lookahead
from .contracts import BookTicker, Candle, DataIntegrityError, FundingRate
from .exchange_rules import (
    ExchangeRuleSnapshot,
    NormalizedOrder,
    normalize_order,
    snapshot_from_exchange_info,
)
from .portfolio import build_position_matrix, inverse_vol_weights, realized_vol

__all__ = [
    "BookTicker",
    "Candle",
    "DataIntegrityError",
    "ExchangeRuleSnapshot",
    "Fill",
    "FundingPayment",
    "FundingRate",
    "NormalizedOrder",
    "PnlBreakdown",
    "assert_monotonic_timestamps",
    "assert_no_lookahead",
    "build_position_matrix",
    "calculate_closed_trade",
    "inverse_vol_weights",
    "normalize_order",
    "realized_vol",
    "snapshot_from_exchange_info",
]

