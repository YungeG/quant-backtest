from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal

from ..contracts import DataIntegrityError


@dataclass(frozen=True)
class HummingbotControllerSpec:
    controller_name: str
    connector_name: str
    trading_pair: str
    total_amount_quote: Decimal
    paper_trade: bool = True

    def __post_init__(self) -> None:
        if not self.controller_name or not self.connector_name:
            raise DataIntegrityError("controller and connector names are required")
        if "-" not in self.trading_pair or self.trading_pair != self.trading_pair.upper():
            raise DataIntegrityError("trading_pair must be normalized BASE-QUOTE text")
        if type(self.total_amount_quote) is not Decimal or not self.total_amount_quote.is_finite() or self.total_amount_quote <= 0:
            raise DataIntegrityError("total_amount_quote must be a finite positive Decimal")

    def to_config(self) -> dict[str, object]:
        payload = asdict(self)
        payload["total_amount_quote"] = format(self.total_amount_quote, "f")
        payload["config_version"] = 1
        return payload

