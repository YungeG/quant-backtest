from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .contracts import DataIntegrityError


@dataclass(frozen=True)
class Fill:
    timestamp_ms: int
    side: str
    price: Decimal
    quantity: Decimal
    fee_quote: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        if self.timestamp_ms < 0 or self.side not in {"buy", "sell"}:
            raise DataIntegrityError("invalid fill identity")
        if any(type(v) is not Decimal or not v.is_finite() for v in (self.price, self.quantity, self.fee_quote)):
            raise DataIntegrityError("fill amounts must be finite Decimal values")
        if self.price <= 0 or self.quantity <= 0 or self.fee_quote < 0:
            raise DataIntegrityError("invalid fill amounts")


@dataclass(frozen=True)
class FundingPayment:
    timestamp_ms: int
    amount_quote: Decimal

    def __post_init__(self) -> None:
        if self.timestamp_ms < 0 or type(self.amount_quote) is not Decimal or not self.amount_quote.is_finite():
            raise DataIntegrityError("invalid funding payment")


@dataclass(frozen=True)
class PnlBreakdown:
    gross_price_pnl: Decimal
    fees: Decimal
    funding: Decimal
    net_pnl: Decimal


def calculate_closed_trade(
    entry: Fill,
    exit: Fill,
    *,
    funding: tuple[FundingPayment, ...] = (),
) -> PnlBreakdown:
    if entry.side == exit.side:
        raise DataIntegrityError("entry and exit sides must be opposite")
    if entry.quantity != exit.quantity:
        raise DataIntegrityError("partial close accounting requires explicit lot matching")
    if exit.timestamp_ms <= entry.timestamp_ms:
        raise DataIntegrityError("exit must occur after entry")
    if any(not entry.timestamp_ms < item.timestamp_ms <= exit.timestamp_ms for item in funding):
        raise DataIntegrityError("funding payment lies outside the trade interval")
    direction = Decimal("1") if entry.side == "buy" else Decimal("-1")
    gross = direction * (exit.price - entry.price) * entry.quantity
    fees = entry.fee_quote + exit.fee_quote
    funding_total = sum((item.amount_quote for item in funding), Decimal("0"))
    return PnlBreakdown(gross, fees, funding_total, gross - fees + funding_total)

