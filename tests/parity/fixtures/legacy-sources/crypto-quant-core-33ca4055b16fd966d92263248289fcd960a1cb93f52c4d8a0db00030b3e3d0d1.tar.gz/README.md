# crypto-quant-core

Small, deterministic contracts extracted from `crypt-gemini` for reuse by crypto
research and trading repositories. The package deliberately excludes strategies,
deployment scripts, credentials, and generated research artifacts.

Public modules:

- `contracts`: normalized candle, funding, and top-of-book records.
- `portfolio`: inverse-volatility sizing compatible with `crypt-gemini`.
- `exchange_rules`: Binance filter snapshots and fail-closed order normalization.
- `accounting`: deterministic closed-trade PnL accounting.
- `causality`: monotonic-time and no-lookahead guards.
- `adapters.hummingbot`: dependency-free Hummingbot controller configuration DTO.

Run tests with `python -m pytest` from this directory.

